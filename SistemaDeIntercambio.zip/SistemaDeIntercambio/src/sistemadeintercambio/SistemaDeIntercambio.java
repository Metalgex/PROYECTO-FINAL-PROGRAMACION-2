package sistemadeintercambio;
import java.util.*;
import Servicios.Belleza;
import Servicios.Deportes;
import Servicios.Educativo;
import Servicios.Entretenimiento;
import Servicios.Eventos;
import Servicios.MYR;
import Servicios.Produccion;
import Servicios.Salud;
import sistemadeintercambio.Servicios;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class SistemaDeIntercambio {
    public static String correo, contraseña, nombre, app, apm, calle, numero, ciudad, estado, cp, usuario,
                    descripcion, coordenadas, complejidad, horario, recomendaciones,
                    material, comentarios, opiniones, fecha_opinion, relacionados, identificacion, telefono,
                    nombreServicio, ciudadServicio, tipoUser, edad, calleServicio, estadoServicio, numeroServicio, cpServicio,
                    tipo, tipoBelleza, materialBelleza, lugarBelleza, tipoDeporte, materialDeporte, nivelDeporte, lugarDeporte,
                    materia, nivelEducativo, modalidad, materialEducativo, nivelAcademico, tipoShow, RequisitosShow, materialShow, tipoEvento,
                    capacidadEvento, lugarEvento, paquetesEvento, tipomyr, garantia, materialmyr, proyecto, formato, requisitosProdu, usocomercial, copyright,
                    tipoSalud, requisitosSalud, ubicacionSalud, fechareseña, usuarioR, correoR;
    public static double precio, calificacion, monto;
    public static boolean existe=true;
    public static int opcion, i;
    public static Usuario useractual;
    public static Servicios servicioactual;
    public static Scanner Lector = new Scanner (System.in);
    
    
    //METODO PARA MODIFICAR LOS ATRIBUTOS ESPECIFICOS DE LOS SERVICIOS DE CATEGORIAS
    public static void categorias(Servicios servicioactual) {
        int op, op2;
            switch(tipo) {
                case "Belleza":
                    tipo="Belleza";
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗧𝗜𝗣𝗢 𝗗𝗘 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    tipoBelleza=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗠𝗔𝗧𝗘𝗥𝗜𝗔𝗟: ");
                    materialBelleza=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗟𝗨𝗚𝗔𝗥 𝗗𝗘𝗟 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    lugarBelleza=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof Belleza) {
                        Belleza actual = (Belleza) servicioactual;
                        actual.modificacionBelleza(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, tipoBelleza, materialBelleza, lugarBelleza);     
                    }
                    break;
                case "Deportes":
                    tipo="Deportes";
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗧𝗜𝗣𝗢 𝗗𝗘 𝗗𝗘𝗣𝗢𝗥𝗧𝗘: ");
                    tipoDeporte=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗠𝗔𝗧𝗘𝗥𝗜𝗔𝗟: ");
                    materialDeporte=Lector.nextLine();
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                                         𝗗𝗜𝗙𝗜𝗖𝗨𝗟𝗧𝗔𝗗");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                      1- Principiante");
                        System.out.println("                                       2- Intermedio");
                        System.out.println("                                        3- Avanzado");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                  ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch(op2) {
                            case 1:
                                nivelDeporte="Principiante";
                                break;
                            case 2:
                                nivelDeporte="Intermedio";
                                break;
                            case 3:
                                nivelDeporte="Avanzado";
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2<1||op2>3);
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗟𝗨𝗚𝗔𝗥 𝗗𝗘𝗟 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    lugarDeporte=Lector.nextLine();
                    Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof Deportes) {
                        Deportes actual = (Deportes) servicioactual;
                        actual.modificacionDeportes(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, tipoDeporte, materialDeporte, nivelDeporte, lugarDeporte);
                    }
                    break;
                case "Educativo":
                    tipo="Educativo";
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗠𝗔𝗧𝗘𝗥𝗜𝗔: ");
                    materia=Lector.nextLine();
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                                         𝗗𝗜𝗙𝗜𝗖𝗨𝗟𝗧𝗔𝗗");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                      1- Principiante");
                        System.out.println("                                       2- Intermedio");
                        System.out.println("                                        3- Avanzado");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                  ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch(op2) {
                            case 1:
                                nivelEducativo="Principiante";
                                break;
                            case 2:
                                nivelEducativo="Intermedio";
                                break;
                            case 3:
                                nivelEducativo="Avanzado";
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2<1||op2>3);
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                                         𝗠𝗢𝗗𝗔𝗟𝗜𝗗𝗔𝗗");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                       1- Presencial");
                        System.out.println("                                        2- Hibrida");
                        System.out.println("                                        3- En linea");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                  ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                modalidad="Presencial";
                                break;
                            case 2:
                                modalidad="Hibrida";
                                break;
                            case 3:
                                modalidad="En linea";
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2<1||op2>3);
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                                        𝗡𝗜𝗩𝗘𝗟 𝗔𝗖𝗔𝗗𝗘𝗠𝗜𝗖𝗢");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                              1- Preescolar     4- Preparatoria");
                        System.out.println("                               2- Primaria       5- Pregrado");
                        System.out.println("                               3- Secundaria     6- Posgrado");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                  ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                nivelAcademico="Preescolar";
                                break;
                            case 2:
                                nivelAcademico="Primaria";
                                break;
                            case 3:
                                nivelAcademico="Secundaria";
                                break;
                            case 4:
                                nivelAcademico="Preparatoria";
                                break;
                            case 5:
                                nivelAcademico="Pregrado";
                                break;
                            case 6:
                                nivelAcademico="Posgrado";
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2<1||op2>6);
                    Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗠𝗔𝗧𝗘𝗥𝗜𝗔𝗟: ");
                    materialEducativo=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof Educativo) {
                        Educativo actual = (Educativo) servicioactual;
                        actual.modificacionEducativo(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, materia, nivelEducativo, modalidad, materialEducativo, nivelAcademico);
                    }
                    break;
                case "Entretenimiento":
                    tipo="Entretenimiento";
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    tipoShow=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗥𝗘𝗤𝗨𝗜𝗦𝗜𝗧𝗢𝗦: ");
                    RequisitosShow=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗠𝗔𝗧𝗘𝗥𝗜𝗔𝗟: ");
                    materialShow=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof Entretenimiento) {
                        Entretenimiento actual = (Entretenimiento) servicioactual;
                        actual.modificacionShows(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, tipoShow, RequisitosShow, materialShow);
                    }
                    break;
                case "Eventos":
                    tipo="Eventos";
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗧𝗜𝗣𝗢 𝗗𝗘 𝗘𝗩𝗘𝗡𝗧𝗢: ");
                    tipoEvento=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗖𝗔𝗣𝗔𝗖𝗜𝗗𝗔𝗗 𝗠𝗔𝗫𝗜𝗠𝗔: ");
                    capacidadEvento=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗟𝗨𝗚𝗔𝗥 𝗗𝗘𝗟 𝗘𝗩𝗘𝗡𝗧𝗢: ");
                    lugarEvento=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗣𝗔𝗤𝗨𝗘𝗧𝗘𝗦 𝗗𝗘𝗟 𝗘𝗩𝗘𝗡𝗧𝗢: ");
                    paquetesEvento=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof Eventos) {
                        Eventos actual = (Eventos) servicioactual;
                        actual.modificacionEventos(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, tipoEvento, capacidadEvento, lugarEvento, paquetesEvento);
                    }
                    break;
                case "Mantenimiento y reparacion":
                    tipo="Mantenimiento y reparacion";
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    tipomyr=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗚𝗔𝗥𝗔𝗡𝗧𝗜𝗔: ");
                    garantia=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗠𝗔𝗧𝗘𝗥𝗜𝗔𝗟: ");
                    materialmyr=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof MYR) {
                        MYR actual = (MYR) servicioactual;
                        actual.modificacionMYR(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, tipomyr, garantia, materialmyr);
                    }
                    break;
                case "Produccion y creativos":
                    tipo="Produccion y creativos";
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    proyecto=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗙𝗢𝗥𝗠𝗔𝗧𝗢 𝗗𝗘 𝗘𝗡𝗧𝗥𝗘𝗚𝗔: ");
                    formato=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗥𝗘𝗤𝗨𝗜𝗦𝗜𝗧𝗢𝗦: ");
                    requisitosProdu=Lector.nextLine();
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                                         𝗨𝗦𝗢 𝗖𝗢𝗠𝗘𝗥𝗖𝗜𝗔𝗟");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                        1- Si    2- No");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                     ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                usocomercial="Si";
                                break;
                            case 2:
                                usocomercial="No";
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2<1||op2>2);
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                                        𝗗𝗘𝗥𝗘𝗖𝗛𝗢𝗦 𝗗𝗘 𝗔𝗨𝗧𝗢𝗥");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                     1- Derechos reservados");
                        System.out.println("                                      2- Creative commons");
                        System.out.println("                                      3- Dominio publico");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                    ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                copyright="Derechos reservados";
                                break;
                            case 2:
                                copyright="Creative commons";
                                break;
                            case 3:
                                copyright="Dominio publico";
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2<1||op2>3);
                    Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof Produccion) {
                        Produccion actual = (Produccion) servicioactual;
                        actual.modificacionProdu(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, proyecto, formato, requisitosProdu, usocomercial, copyright);
                    }
                    break;
                case "Salud y bienestar":
                    tipo="Salud y bienestar";
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    tipoSalud=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗥𝗘𝗤𝗨𝗜𝗦𝗜𝗧𝗢𝗦: ");
                    requisitosSalud=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗟𝗨𝗚𝗔𝗥 𝗗𝗘𝗟 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    ubicacionSalud=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof Salud) {
                        Salud actual = (Salud) servicioactual;
                        actual.modificacionSalud(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, tipoSalud, requisitosSalud, ubicacionSalud);
                    }
                    break;
                default:
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                    break;
            }
    }
    //METODO PARA MODIFICAR LOS ATRIBUTOS EN COMUN DE LOS SERVICIOS
    public static void modificar(Servicios servicioactual) {
        int op, op2;
        Lector.nextLine();
        System.out.print("𝗡𝗢𝗠𝗕𝗥𝗘 𝗗𝗘𝗟 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
        nombreServicio=Lector.nextLine();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗗𝗘𝗦𝗖𝗥𝗜𝗣𝗖𝗜𝗢𝗡: ");
        descripcion=Lector.nextLine();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗣𝗥𝗘𝗖𝗜𝗢 𝗣𝗢𝗥 𝗛𝗢𝗥𝗔: ");
        precio=Lector.nextDouble();
        Lector.nextLine();
        servicioactual.modificacion(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
    }
    
    //METODO PARA CONSULTAR SERVICIOS
    public static void consultadeservicios() {
        int op, op2;
        do {
            System.out.println("-----------------------------------------------------------------------------------------------");
            System.out.println("                           𝟭- 𝗠𝗢𝗦𝗧𝗥𝗔𝗥 𝗧𝗢𝗗𝗢𝗦 𝗟𝗢𝗦 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
            System.out.println("                             𝟮- 𝗠𝗢𝗦𝗧𝗥𝗔𝗥 𝗟𝗢𝗦 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗣𝗢𝗥 𝗖𝗔𝗧𝗘𝗚𝗢𝗥𝗜𝗔");
            System.out.println("-----------------------------------------------------------------------------------------------");
            System.out.print("                                  ¿Que opcion desea elegir? ");
            op=Lector.nextInt();
            switch(op){
                case 1:
                    System.out.println(Servicios.viewServicios());
                    break;
                case 2:
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                                           𝗖𝗔𝗧𝗘𝗚𝗢𝗥𝗜𝗔𝗦");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                          1- Belleza            5- Eventos");
                        System.out.println("                          2- Deportes           6- Mantenimiento y reparacion");
                        System.out.println("                          3- Educativo          7- Produccion y creativos");
                        System.out.println("                          4- Entretenimiento    8- Salud y bienestar");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                             ¿Que categoria de servicios desea ver? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                System.out.println("===============================================================================================");
                                System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println(Belleza.viewBelleza());
                                break;
                            case 2:
                                System.out.println("===============================================================================================");
                                System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println(Deportes.viewDeporte());
                                break;
                            case 3:
                                System.out.println("===============================================================================================");
                                System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println(Educativo.viewEducativo());
                                break;
                            case 4:
                                System.out.println("===============================================================================================");
                                System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println(Entretenimiento.viewShows());
                                break;
                            case 5:
                                System.out.println("===============================================================================================");
                                System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println(Eventos.viewEventos());
                                break;
                            case 6:
                                System.out.println("===============================================================================================");
                                System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println(MYR.viewMYR());
                                break;
                            case 7:
                                System.out.println("===============================================================================================");
                                System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println(Produccion.viewProdu());
                                break;
                            case 8:
                                System.out.println("===============================================================================================");
                                System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println(Salud.viewSalud());
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2<1||op2>8);
                    break;
                default:
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                    break;
            }
        } while (op<1||op>2);
    }
    
    
    //METODO PARA PUBLICAR LAS DIRECCIONES DE UN SERVICIO
    public static void direcciones() {
        System.out.println("===============================================================================================");
        System.out.println("                                          𝗨𝗕𝗜𝗖𝗔𝗖𝗜𝗢𝗡");
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗖𝗔𝗟𝗟𝗘: ");
        calleServicio=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗡𝗨𝗠𝗘𝗥𝗢 𝗘𝗫𝗧𝗘𝗥𝗜𝗢𝗥: ");
        numeroServicio=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗖𝗜𝗨𝗗𝗔𝗗: ");
        ciudadServicio=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗘𝗦𝗧𝗔𝗗𝗢: ");
        estadoServicio=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗖𝗢𝗗𝗜𝗚𝗢 𝗣𝗢𝗦𝗧𝗔𝗟: ");
        cpServicio=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗖𝗢𝗢𝗥𝗗𝗘𝗡𝗔𝗗𝗔𝗦: ");
        coordenadas=Lector.next();
    }
    
    
    //METODO PARA PUBLICAR LAS RECOMENDACIONES DE UN SERVICIO
    public static void Recomendaciones() {
        int op;
        Lector.nextLine();
        System.out.println("===============================================================================================");
        System.out.println("                                   𝗥𝗘𝗖𝗢𝗠𝗘𝗡𝗗𝗔𝗖𝗜𝗢𝗡𝗘𝗦 𝗚𝗘𝗡𝗘𝗥𝗔𝗟𝗘𝗦");
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("Recomendaciones: ");
        recomendaciones=Lector.nextLine();
        do {
            System.out.println("===============================================================================================");
            System.out.println("                                       𝗘𝗗𝗔𝗗 𝗥𝗘𝗖𝗢𝗠𝗘𝗡𝗗𝗔𝗗𝗔");
            System.out.println("-----------------------------------------------------------------------------------------------");
            System.out.println("                                     1- 0-10      6- 51-60");
            System.out.println("                                     2- 11-20     7- 61-70");
            System.out.println("                                     3- 21-30     8- 71-80");
            System.out.println("                                     4- 31-40     9- 81-90");
            System.out.println("                                     5- 41-50    10- 91-100");
            System.out.println("-----------------------------------------------------------------------------------------------");
            System.out.print("                                  ¿Que opcion desea elejir? ");
            op=Lector.nextInt();
            switch(op) {
                case 1:
                    edad="1-10 años";
                    break;
                case 2:
                    edad="11-20 años";
                    break;
                case 3:
                    edad="21-30 años";
                    break;
                case 4:
                    edad="31-40 años";
                    break;
                case 5:
                    edad="41-50 años";
                    break;
                case 6:
                    edad="51-60 años";
                    break;
                case 7:
                    edad="61-70 años";
                    break;
                case 8:
                    edad="71-80 años";
                    break;
                case 9:
                    edad="81-90 años";
                    break;
                case 10:
                    edad="91-100 años";
                    break;
                default:
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                    break;
            }
        } while (op<1||op>10);
        do {
            System.out.println("===============================================================================================");
            System.out.println("                                      𝗛𝗢𝗥𝗔𝗥𝗜𝗢 𝗥𝗘𝗖𝗢𝗠𝗘𝗡𝗗𝗔𝗗𝗢");
            System.out.println("-----------------------------------------------------------------------------------------------");
            System.out.println("                                           1- Mañana");
            System.out.println("                                          2- Mediodia");
            System.out.println("                                           3- Tarde");
            System.out.println("-----------------------------------------------------------------------------------------------");
            System.out.print("                                   ¿Que opcion desea elejir? ");
            op=Lector.nextInt();
            switch(op){
                case 1:
                    horario="Mañana";
                    break;
                case 2:
                    horario="Mediodia";
                    break;
                case 3:
                    horario="Tarde";
                    break;
                case 4:
                    horario="Noche";
                    break;
                default:
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                    break;
            }
        } while (op<1||op>4);
    }
    
    
    //METODO PARA PUBLICAR UN SERVICIO
    public static void publicarservicio() {
        int op, op2;
        Lector.nextLine();
        System.out.println("                                   ----𝗣𝗨𝗕𝗟𝗜𝗖𝗔𝗥 𝗨𝗡 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢----");
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗡𝗢𝗠𝗕𝗥𝗘 𝗗𝗘𝗟 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
        nombreServicio=Lector.nextLine();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗗𝗘𝗦𝗖𝗥𝗜𝗣𝗖𝗜𝗢𝗡: ");
        descripcion=Lector.nextLine();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗣𝗥𝗘𝗖𝗜𝗢 𝗣𝗢𝗥 𝗛𝗢𝗥𝗔: ");
        precio=Lector.nextDouble();
        Lector.nextLine();
        do {
            System.out.println("===============================================================================================");
            System.out.println("                                          𝗖𝗔𝗧𝗘𝗚𝗢𝗥𝗜𝗔");
            System.out.println("-----------------------------------------------------------------------------------------------");
            System.out.println("                          1- Belleza            5- Eventos");
            System.out.println("                          2- Deportes           6- Mantenimiento y reparacion");
            System.out.println("                          3- Educativo          7- Produccion y creativos");
            System.out.println("                          4- Entretenimiento    8- Salud y bienestar");
            System.out.println("-----------------------------------------------------------------------------------------------");
            System.out.print("                               ¿Que categoria es su servicio? ");
            op=Lector.nextInt();
            switch(op) {
                case 1:
                    tipo="Belleza";
                    Lector.nextLine();
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗧𝗜𝗣𝗢 𝗗𝗘 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    tipoBelleza=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗠𝗔𝗧𝗘𝗥𝗜𝗔𝗟: ");
                    materialBelleza=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗟𝗨𝗚𝗔𝗥 𝗗𝗘𝗟 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    lugarBelleza=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    Belleza service1 = new Belleza(tipoBelleza, materialBelleza, lugarBelleza, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    Belleza.aggBelleza(service1);
                    Servicios.generales.add(service1);
                    useractual.getPublicados().add(service1);
                    System.out.println("===============================================================================================");
                    System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗣𝗨𝗕𝗟𝗜𝗖𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                    System.out.println("===============================================================================================");
                    break;
                case 2:
                    tipo="Deportes";
                    Lector.nextLine();
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗧𝗜𝗣𝗢 𝗗𝗘 𝗗𝗘𝗣𝗢𝗥𝗧𝗘: ");
                    tipoDeporte=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗠𝗔𝗧𝗘𝗥𝗜𝗔𝗟: ");
                    materialDeporte=Lector.nextLine();
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                                         𝗗𝗜𝗙𝗜𝗖𝗨𝗟𝗧𝗔𝗗");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                      1- Principiante");
                        System.out.println("                                       2- Intermedio");
                        System.out.println("                                        3- Avanzado");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                  ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch(op2) {
                            case 1:
                                nivelDeporte="Principiante";
                                break;
                            case 2:
                                nivelDeporte="Intermedio";
                                break;
                            case 3:
                                nivelDeporte="Avanzado";
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2<1||op2>3);
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    Lector.nextLine();
                    System.out.print("𝗟𝗨𝗚𝗔𝗥 𝗗𝗘𝗟 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    lugarDeporte=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    Deportes service2 = new Deportes(tipoDeporte, materialDeporte, nivelDeporte, lugarDeporte, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    Deportes.aggDeportes(service2);
                    Servicios.generales.add(service2);
                    useractual.getPublicados().add(service2);
                    System.out.println("===============================================================================================");
                    System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗣𝗨𝗕𝗟𝗜𝗖𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                    System.out.println("===============================================================================================");
                    break;
                case 3:
                    tipo="Educativo";
                    Lector.nextLine();
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗠𝗔𝗧𝗘𝗥𝗜𝗔: ");
                    materia=Lector.nextLine();
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                                         𝗗𝗜𝗙𝗜𝗖𝗨𝗟𝗧𝗔𝗗");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                      1- Principiante");
                        System.out.println("                                       2- Intermedio");
                        System.out.println("                                        3- Avanzado");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                  ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch(op2) {
                            case 1:
                                nivelEducativo="Principiante";
                                break;
                            case 2:
                                nivelEducativo="Intermedio";
                                break;
                            case 3:
                                nivelEducativo="Avanzado";
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2<1||op2>3);
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                                         𝗠𝗢𝗗𝗔𝗟𝗜𝗗𝗔𝗗");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                       1- Presencial");
                        System.out.println("                                        2- Hibrida");
                        System.out.println("                                        3- En linea");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                  ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                modalidad="Presencial";
                                break;
                            case 2:
                                modalidad="Hibrida";
                                break;
                            case 3:
                                modalidad="En linea";
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2<1||op2>3);
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                                        𝗡𝗜𝗩𝗘𝗟 𝗔𝗖𝗔𝗗𝗘𝗠𝗜𝗖𝗢");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                              1- Preescolar     4- Preparatoria");
                        System.out.println("                               2- Primaria       5- Pregrado");
                        System.out.println("                               3- Secundaria     6- Posgrado");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                  ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                nivelAcademico="Preescolar";
                                break;
                            case 2:
                                nivelAcademico="Primaria";
                                break;
                            case 3:
                                nivelAcademico="Secundaria";
                                break;
                            case 4:
                                nivelAcademico="Preparatoria";
                                break;
                            case 5:
                                nivelAcademico="Pregrado";
                                break;
                            case 6:
                                nivelAcademico="Posgrado";
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2<1||op2>6);
                    Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗠𝗔𝗧𝗘𝗥𝗜𝗔𝗟: ");
                    materialEducativo=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    Educativo service3 = new Educativo(materia, nivelEducativo, modalidad, materialEducativo, nivelAcademico, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    Educativo.aggEducativos(service3);
                    Servicios.generales.add(service3);
                    useractual.getPublicados().add(service3);
                    System.out.println("===============================================================================================");
                    System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗣𝗨𝗕𝗟𝗜𝗖𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                    System.out.println("===============================================================================================");
                    break;
                case 4:
                    tipo="Entretenimiento";
                    Lector.nextLine();
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    tipoShow=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗥𝗘𝗤𝗨𝗜𝗦𝗜𝗧𝗢𝗦: ");
                    RequisitosShow=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗠𝗔𝗧𝗘𝗥𝗜𝗔𝗟: ");
                    materialShow=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    Entretenimiento service4 = new Entretenimiento(tipoShow, RequisitosShow, materialShow, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    Entretenimiento.aggShows(service4);
                    Servicios.generales.add(service4);
                    useractual.getPublicados().add(service4);
                    System.out.println("===============================================================================================");
                    System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗣𝗨𝗕𝗟𝗜𝗖𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                    System.out.println("===============================================================================================");
                    break;
                case 5:
                    tipo="Eventos";
                    Lector.nextLine();
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗧𝗜𝗣𝗢 𝗗𝗘 𝗘𝗩𝗘𝗡𝗧𝗢: ");
                    tipoEvento=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗖𝗔𝗣𝗔𝗖𝗜𝗗𝗔𝗗 𝗠𝗔𝗫𝗜𝗠𝗔: ");
                    capacidadEvento=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗟𝗨𝗚𝗔𝗥 𝗗𝗘𝗟 𝗘𝗩𝗘𝗡𝗧𝗢: ");
                    lugarEvento=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗣𝗔𝗤𝗨𝗘𝗧𝗘𝗦 𝗗𝗘𝗟 𝗘𝗩𝗘𝗡𝗧𝗢: ");
                    paquetesEvento=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    Eventos service5 = new Eventos(tipoEvento, capacidadEvento, lugarEvento, paquetesEvento, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    Eventos.aggEventos(service5);
                    Servicios.generales.add(service5);
                    useractual.getPublicados().add(service5);
                    System.out.println("===============================================================================================");
                    System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗣𝗨𝗕𝗟𝗜𝗖𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                    System.out.println("===============================================================================================");
                    break;
                case 6:
                    tipo="Mantenimiento y Reparacion";
                    Lector.nextLine();
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    tipomyr=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗚𝗔𝗥𝗔𝗡𝗧𝗜𝗔: ");
                    garantia=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗠𝗔𝗧𝗘𝗥𝗜𝗔𝗟: ");
                    materialmyr=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    MYR service6 = new MYR(tipomyr, garantia, materialmyr, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    MYR.aggMyr(service6);
                    Servicios.generales.add(service6);
                    useractual.getPublicados().add(service6);
                    System.out.println("===============================================================================================");
                    System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗣𝗨𝗕𝗟𝗜𝗖𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                    System.out.println("===============================================================================================");
                    break;
                case 7:
                    tipo="Produccion y Creativos";
                    Lector.nextLine();
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    proyecto=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗙𝗢𝗥𝗠𝗔𝗧𝗢 𝗗𝗘 𝗘𝗡𝗧𝗥𝗘𝗚𝗔: ");
                    formato=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗥𝗘𝗤𝗨𝗜𝗦𝗜𝗧𝗢𝗦: ");
                    requisitosProdu=Lector.nextLine();
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                                         𝗨𝗦𝗢 𝗖𝗢𝗠𝗘𝗥𝗖𝗜𝗔𝗟");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                        1- Si    2- No");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                     ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                usocomercial="Si";
                                break;
                            case 2:
                                usocomercial="No";
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2<1||op2>2);
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                                        𝗗𝗘𝗥𝗘𝗖𝗛𝗢𝗦 𝗗𝗘 𝗔𝗨𝗧𝗢𝗥");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                     1- Derechos reservados");
                        System.out.println("                                      2- Creative commons");
                        System.out.println("                                      3- Dominio publico");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                    ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                copyright="Derechos reservados";
                                break;
                            case 2:
                                copyright="Creative commons";
                                break;
                            case 3:
                                copyright="Dominio publico";
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2<1||op2>3);
                    Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    Produccion service7 = new Produccion(proyecto, formato, requisitosProdu, usocomercial, copyright, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    Produccion.aggProducciones(service7);
                    Servicios.generales.add(service7);
                    useractual.getPublicados().add(service7);
                    System.out.println("===============================================================================================");
                    System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗣𝗨𝗕𝗟𝗜𝗖𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                    System.out.println("===============================================================================================");
                    break;
                case 8:
                    tipo="Salud y Bienestar";
                    Lector.nextLine();
                    System.out.println("===============================================================================================");
                    System.out.println("                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    tipoSalud=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗥𝗘𝗤𝗨𝗜𝗦𝗜𝗧𝗢𝗦: ");
                    requisitosSalud=Lector.nextLine();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("𝗟𝗨𝗚𝗔𝗥 𝗗𝗘𝗟 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: ");
                    ubicacionSalud=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    Salud service8 = new Salud(tipoSalud, requisitosSalud, ubicacionSalud, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    Salud.aggSalud(service8);
                    Servicios.generales.add(service8);
                    useractual.getPublicados().add(service8);
                    System.out.println("===============================================================================================");
                    System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗣𝗨𝗕𝗟𝗜𝗖𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                    System.out.println("===============================================================================================");
                    break;
                default:
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                    break;
            }
        } while (op<1||op>8);
    }
    
    //MENU USUARIO
    public static void menuUsuario() {
        int op, op2, op3;
        do {
            System.out.println("                                        ¡𝗛𝗢𝗟𝗔 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢!");
            System.out.println("===============================================================================================");
            System.out.println("                                    𝟭- 𝗣𝗨𝗕𝗟𝗜𝗖𝗔𝗥 𝗨𝗡 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢");
            System.out.println("                                    𝟮- 𝗖𝗢𝗠𝗣𝗥𝗔𝗥 𝗨𝗡 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢");
            System.out.println("                                    𝟯- 𝗖𝗔𝗥𝗥𝗜𝗧𝗢 𝗗𝗘 𝗖𝗢𝗠𝗣𝗥𝗔𝗦");
            System.out.println("                                    𝟰- 𝗠𝗢𝗡𝗘𝗗𝗘𝗥𝗢 𝗘𝗟𝗘𝗖𝗧𝗥𝗢𝗡𝗜𝗖𝗢");
            System.out.println("                                  𝟱- 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗗𝗘 𝗟𝗔 𝗖𝗨𝗘𝗡𝗧𝗔");
            System.out.println("                                        𝟲- 𝗖𝗘𝗥𝗥𝗔𝗥 𝗦𝗘𝗦𝗜𝗢𝗡");
            System.out.println("-----------------------------------------------------------------------------------------------");
            System.out.print("                                ¿Que opcion desea elegir? ");
            op=Lector.nextInt();
            switch(op) {
                case 1:
                    System.out.println("===============================================================================================");
                    publicarservicio();
                    break;
                case 2:
                    System.out.println("===============================================================================================");
                    System.out.println("                                ----𝗖𝗢𝗠𝗣𝗥𝗔𝗥 𝗨𝗡 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢----");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.println("                          1- Belleza            5- Eventos");
                    System.out.println("                          2- Deportes           6- Mantenimiento y reparacion");
                    System.out.println("                          3- Educativo          7- Produccion y creativos");
                    System.out.println("                          4- Entretenimiento    8- Salud y bienestar");
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    System.out.print("                              ¿En que categoria desea comprar? ");
                    op2=Lector.nextInt();
                    System.out.println("-----------------------------------------------------------------------------------------------");
                    switch(op2) {
                        case 1:
                            System.out.println(Belleza.viewBelleza());
                            if (Belleza.viewBelleza().contains("No hay servicios registrados")) {
                                System.out.println("===============================================================================================");
                            } else {
                                System.out.print("                                ¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual=Belleza.getBellezas().get(op3);
                                System.out.println(Belleza.getBellezas().get(op3).InfoBelleza());
                                System.out.println(servicioactual.InfoReseñas());
                                System.out.println("===============================================================================================");
                                System.out.println("                                   𝟭- 𝗔𝗚𝗥𝗘𝗚𝗔𝗥 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢");
                                System.out.println("                                     𝟮- 𝗖𝗢𝗠𝗣𝗥𝗔𝗥 𝗔𝗛𝗢𝗥𝗔");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("                                  ¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                switch(op4) {
                                    case 1://AGREGAR AL CARRITO
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine(); 
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita);
                                            System.out.println("===============================================================================================");
                                            System.out.println("                             ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗔𝗚𝗥𝗘𝗚𝗔𝗗𝗢 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                            System.out.println("===============================================================================================");
                                            
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    case 2://COMPRAR AHORA
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine();
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
                                            Citas cita = new Citas(servicioactual, fechahora, horas);
                                            double total=cita.getSubtotal();
                                            String compra=useractual.comprar(total, cita);
                                            System.out.println("===============================================================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita);
                                            }
                                        }catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    default:
                                        System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                        System.out.println("===============================================================================================");
                                        break;
                                }
                            }
                            break;
                        case 2:
                            System.out.println(Deportes.viewDeporte());
                            if (Deportes.viewDeporte().contains("No hay servicios registrados")) {
                                System.out.println("===============================================================================================");
                            } else {
                                System.out.print("                                ¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual=Deportes.getDeportes().get(op3);
                                System.out.println(Deportes.getDeportes().get(op3).InfoDeportes());
                                System.out.println(servicioactual.InfoReseñas());
                                System.out.println("===============================================================================================");
                                System.out.println("                                   𝟭- 𝗔𝗚𝗥𝗘𝗚𝗔𝗥 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢");
                                System.out.println("                                     𝟮- 𝗖𝗢𝗠𝗣𝗥𝗔𝗥 𝗔𝗛𝗢𝗥𝗔");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("                                  ¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                switch(op4) {
                                    case 1:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine(); 
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita2 = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita2);
                                            System.out.println("===============================================================================================");
                                            System.out.println("                             ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗔𝗚𝗥𝗘𝗚𝗔𝗗𝗢 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                            System.out.println("===============================================================================================");
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    case 2:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            Citas cita2 = new Citas(servicioactual, fechahora, horas);
                                            double total=cita2.getSubtotal();
                                            String compra=useractual.comprar(total, cita2);
                                            System.out.println("===============================================================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita2);
                                            }
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    default:
                                        System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                        System.out.println("===============================================================================================");
                                        break;
                                }
                            }
                            break;
                        case 3:
                            System.out.println(Educativo.viewEducativo());
                            if (Educativo.viewEducativo().contains("No hay servicios registrados")) {
                                System.out.println("===============================================================================================");
                            } else {
                                System.out.print("                                ¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual=Educativo.getEducativos().get(op3);
                                System.out.println(Educativo.getEducativos().get(op3).InfoEducacion());
                                System.out.println(servicioactual.InfoReseñas());
                                System.out.println("===============================================================================================");
                                System.out.println("                                   𝟭- 𝗔𝗚𝗥𝗘𝗚𝗔𝗥 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢");
                                System.out.println("                                     𝟮- 𝗖𝗢𝗠𝗣𝗥𝗔𝗥 𝗔𝗛𝗢𝗥𝗔");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("                                  ¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                switch(op4) {
                                    case 1:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine();
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine(); 
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita3 = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita3);
                                            System.out.println("===============================================================================================");
                                            System.out.println("                             ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗔𝗚𝗥𝗘𝗚𝗔𝗗𝗢 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                            System.out.println("===============================================================================================");
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    case 2:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
                                            Citas cita3 = new Citas(servicioactual, fechahora, horas);
                                            double total=cita3.getSubtotal();
                                            String compra=useractual.comprar(total, cita3);
                                            System.out.println("===============================================================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita3);
                                            }
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    default:
                                        System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                        System.out.println("===============================================================================================");
                                        break;
                                }
                            }
                            break;
                        case 4:
                            System.out.println(Entretenimiento.viewShows());
                            if (Entretenimiento.viewShows().contains("No hay servicios registrados")) {
                                System.out.println("===============================================================================================");
                            } else {
                                System.out.print("                                ¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual=Entretenimiento.getShows().get(op3);
                                System.out.println(Entretenimiento.getShows().get(op3).InfoShows());
                                System.out.println(servicioactual.InfoReseñas());
                                System.out.println("===============================================================================================");
                                System.out.println("                                   𝟭- 𝗔𝗚𝗥𝗘𝗚𝗔𝗥 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢");
                                System.out.println("                                     𝟮- 𝗖𝗢𝗠𝗣𝗥𝗔𝗥 𝗔𝗛𝗢𝗥𝗔");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("                                  ¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                switch(op4) {
                                    case 1:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita4 = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita4);
                                            System.out.println("===============================================================================================");
                                            System.out.println("                             ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗔𝗚𝗥𝗘𝗚𝗔𝗗𝗢 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                            System.out.println("===============================================================================================");
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    case 2:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
                                            Citas cita4 = new Citas(servicioactual, fechahora, horas);
                                            double total=cita4.getSubtotal();
                                            String compra = useractual.comprar(total, cita4);
                                            System.out.println("===============================================================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita4);
                                            }
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    default:
                                        System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                        System.out.println("===============================================================================================");
                                        break;
                                }
                            }
                            break;
                        case 5:
                            System.out.println(Eventos.viewEventos());
                            if (Eventos.viewEventos().contains("No hay servicios registrados")) {
                                System.out.println("===============================================================================================");
                            } else {
                                System.out.print("                                ¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual=Eventos.getEventos().get(op3);
                                System.out.println(Eventos.getEventos().get(op3).InfoEventos());
                                System.out.println(servicioactual.InfoReseñas());
                                System.out.println("===============================================================================================");
                                System.out.println("                                   𝟭- 𝗔𝗚𝗥𝗘𝗚𝗔𝗥 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢");
                                System.out.println("                                     𝟮- 𝗖𝗢𝗠𝗣𝗥𝗔𝗥 𝗔𝗛𝗢𝗥𝗔");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("                                  ¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                switch(op4) {
                                    case 1:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita5 = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita5);
                                            System.out.println("===============================================================================================");
                                            System.out.println("                             ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗔𝗚𝗥𝗘𝗚𝗔𝗗𝗢 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                            System.out.println("===============================================================================================");
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    case 2:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
                                            Citas cita5 = new Citas(servicioactual, fechahora, horas);
                                            double total=cita5.getSubtotal();
                                            String compra=useractual.comprar(total, cita5);
                                            System.out.println("===============================================================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita5);
                                            }
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    default:
                                        System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                        System.out.println("===============================================================================================");
                                        break;
                                }
                            }
                            break;
                        case 6:
                            System.out.println(MYR.viewMYR());
                            if (MYR.viewMYR().contains("No hay servicios registrados")) {
                                System.out.println("===============================================================================================");
                            } else {
                                System.out.print("                                ¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual = MYR.getMyr().get(op3);
                                System.out.println(MYR.getMyr().get(op3).InfoMYR());
                                System.out.println(servicioactual.InfoReseñas());
                                System.out.println("===============================================================================================");
                                System.out.println("                                   𝟭- 𝗔𝗚𝗥𝗘𝗚𝗔𝗥 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢");
                                System.out.println("                                     𝟮- 𝗖𝗢𝗠𝗣𝗥𝗔𝗥 𝗔𝗛𝗢𝗥𝗔");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("                                  ¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                switch(op4) {
                                    case 1:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita6 = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita6);
                                            System.out.println("===============================================================================================");
                                            System.out.println("                             ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗔𝗚𝗥𝗘𝗚𝗔𝗗𝗢 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                            System.out.println("===============================================================================================");
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    case 2:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
                                            Citas cita6 = new Citas(servicioactual, fechahora, horas);
                                            double total=cita6.getSubtotal();
                                            String compra=useractual.comprar(monto, cita6);
                                            System.out.println("===============================================================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita6);
                                            }
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    default:
                                        System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                        System.out.println("===============================================================================================");
                                        break;
                                }
                            }
                            break;
                        case 7:
                            System.out.println(Produccion.viewProdu());
                            if (Produccion.viewProdu().contains("No hay servicios registrados")) {
                                System.out.println("===============================================================================================");
                            } else {
                                System.out.print("                                ¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual=Produccion.getProducciones().get(op3);
                                System.out.println(Produccion.getProducciones().get(op3).InfoProduccion());
                                System.out.println(servicioactual.InfoReseñas());
                                System.out.println("===============================================================================================");
                                System.out.println("                                   𝟭- 𝗔𝗚𝗥𝗘𝗚𝗔𝗥 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢");
                                System.out.println("                                     𝟮- 𝗖𝗢𝗠𝗣𝗥𝗔𝗥 𝗔𝗛𝗢𝗥𝗔");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("                                  ¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                switch(op4) {
                                    case 1:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita7 = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita7);
                                            System.out.println("===============================================================================================");
                                            System.out.println("                             ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗔𝗚𝗥𝗘𝗚𝗔𝗗𝗢 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                            System.out.println("===============================================================================================");
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    case 2:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
                                            Citas cita7 = new Citas(servicioactual, fechahora, horas);
                                            double total=cita7.getSubtotal();
                                            String compra = useractual.comprar(total, cita7);
                                            System.out.println("===============================================================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita7);
                                            }
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    default:
                                        System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                        System.out.println("===============================================================================================");
                                        break;
                                }
                            }
                            break;
                        case 8:
                            System.out.println(Salud.viewSalud());
                            if (Salud.viewSalud().contains("No hay servicios registrados")) {
                                System.out.println("===============================================================================================");
                            } else {
                                System.out.print("                                ¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual=Salud.getSalud().get(op3);
                                System.out.println(Salud.getSalud().get(op3).InfoSalud());
                                System.out.println(servicioactual.InfoReseñas());
                                System.out.println("===============================================================================================");
                                System.out.println("                                   𝟭- 𝗔𝗚𝗥𝗘𝗚𝗔𝗥 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢");
                                System.out.println("                                     𝟮- 𝗖𝗢𝗠𝗣𝗥𝗔𝗥 𝗔𝗛𝗢𝗥𝗔");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("                                  ¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                switch(op4) {
                                    case 1:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita8 = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita8);
                                            System.out.println("===============================================================================================");
                                            System.out.println("                             ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗔𝗚𝗥𝗘𝗚𝗔𝗗𝗢 𝗔𝗟 𝗖𝗔𝗥𝗥𝗜𝗧𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                            System.out.println("===============================================================================================");
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    case 2:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
                                            Citas cita8 = new Citas(servicioactual, fechahora, horas);
                                            double total=cita8.getSubtotal();
                                            String compra=useractual.comprar(total, cita8);
                                            System.out.println("===============================================================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita8);
                                            }
                                        } catch (Exception e) {
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                     𝗙𝗘𝗖𝗛𝗔 𝗬 𝗛𝗢𝗥𝗔 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔𝗦");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    default:
                                        System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                        System.out.println("===============================================================================================");
                                        break;
                                }
                            }
                            break;
                        default:
                            System.out.println("===============================================================================================");
                            System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                            System.out.println("===============================================================================================");
                            break;
                    }
                    break;
                case 3:
                    System.out.println("===============================================================================================");
                    System.out.println(useractual.getCarritos().viewcarrito());
                    System.out.println("===============================================================================================");
                    if (useractual.getCarritos().viewcarrito().contains("¡EL CARRITO ESTA VACIO!")) {
                        
                    } else {
                        System.out.print("¿Desea proceder al pago del carrito? 1- Si 2- No ");
                        int op4=Lector.nextInt();
                        if (op4==1) {
                            System.out.println(useractual.getCarritos().pagarcarrito(useractual));
                        }
                    }
                    break;
                case 4:
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                                  ----𝗠𝗢𝗡𝗘𝗗𝗘𝗥𝗢 𝗘𝗟𝗘𝗖𝗧𝗥𝗢𝗡𝗜𝗖𝗢----");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                      𝟭- 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔𝗥 𝗦𝗔𝗟𝗗𝗢");
                        System.out.println("                                       𝟮- 𝗔𝗚𝗥𝗘𝗚𝗔𝗥 𝗦𝗔𝗟𝗗𝗢");
                        System.out.println("                                  𝟯- 𝗩𝗢𝗟𝗩𝗘𝗥 𝗔𝗟 𝗠𝗘𝗡𝗨 𝗣𝗥𝗜𝗡𝗖𝗜𝗣𝗔𝗟");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                  ¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        switch (op2) {
                            case 1:
                                System.out.println(useractual.consultaSaldo());
                                break;
                            case 2:
                                System.out.print("¿𝗖𝗨𝗔𝗡𝗧𝗢 𝗗𝗘𝗦𝗘𝗔 𝗔𝗚𝗥𝗘𝗚𝗔𝗥? ");
                                monto=Lector.nextDouble();
                                useractual.aggSaldo(monto);
                                System.out.println("===============================================================================================");
                                System.out.println("                                 ¡𝗗𝗘𝗣𝗢𝗦𝗜𝗧𝗢 𝗥𝗘𝗔𝗟𝗜𝗭𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                System.out.println("===============================================================================================");
                                System.out.println(useractual.consultaSaldo());
                                break;
                            case 3:
                                break;
                            default:                   
                                System.out.println("                             ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2!=3);
                    break;
                case 5:
                    do {
                        System.out.println("===============================================================================================");
                        System.out.println("                              ----𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗗𝗘 𝗟𝗔 𝗖𝗨𝗘𝗡𝗧𝗔----");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                     𝟭- 𝗠𝗜𝗦 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦");
                        System.out.println("                                   𝟮- 𝗗𝗔𝗧𝗢𝗦 𝗣𝗘𝗥𝗦𝗢𝗡𝗔𝗟𝗘𝗦");
                        System.out.println("                                𝟯- 𝗩𝗢𝗟𝗩𝗘𝗥 𝗔𝗟 𝗠𝗘𝗡𝗨 𝗣𝗥𝗜𝗡𝗖𝗜𝗣𝗔𝗟");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                  ¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        switch(op2) {
                            case 1:
                                do {
                                    System.out.println("                                     𝗠𝗜𝗦 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦");
                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                    System.out.println("                                𝟭- 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗣𝗨𝗕𝗟𝗜𝗖𝗔𝗗𝗢𝗦");
                                    System.out.println("                                𝟮- 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗖𝗢𝗠𝗣𝗥𝗔𝗗𝗢𝗦");
                                    System.out.println("                                      𝟯- 𝗥𝗘𝗦𝗘𝗡̃𝗔𝗦");
                                    System.out.println("                                      𝟰- 𝗩𝗢𝗟𝗩𝗘𝗥");
                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                      System.out.print("                              ¿Que opcion desea elegir? ");
                                    op3=Lector.nextInt();
                                    switch(op3) {
                                        case 1:
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                    𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗣𝗨𝗕𝗟𝗜𝗖𝗔𝗗𝗢𝗦");
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println(useractual.viewPublicados());
                                            break;
                                        case 2:
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                    𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗖𝗢𝗠𝗣𝗥𝗔𝗗𝗢𝗦");
                                            System.out.println(useractual.viewComprados());
                                            break;
                                        case 3:
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                           𝗥𝗘𝗦𝗘𝗡̃𝗔𝗦");
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println("                                     𝟭- 𝗘𝗦𝗖𝗥𝗜𝗕𝗜𝗥 𝗥𝗘𝗦𝗘𝗡̃𝗔𝗦");
                                            System.out.println("                               𝟮- 𝗠𝗢𝗦𝗧𝗥𝗔𝗥 𝗠𝗜𝗦 𝗥𝗘𝗦𝗘𝗡̃𝗔𝗦 𝗘𝗦𝗖𝗥𝗜𝗧𝗔𝗦");
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                              System.out.print("                                 ¿Que opcion desea elegir? ");
                                            int op4=Lector.nextInt();
                                            switch(op4) {
                                                case 1:
                                                    System.out.println("===============================================================================================");
                                                    System.out.println("                                    𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗖𝗢𝗠𝗣𝗥𝗔𝗗𝗢𝗦");
                                                    System.out.println(useractual.viewComprados());
                                                    System.out.print("                         ¿En que servicio desea escribir una reseña? ");
                                                    int op5=Lector.nextInt()-1;
                                                    Citas cita = useractual.getComprados().get(op5);
                                                    Servicios service = cita.getServicio();
                                                    usuarioR=useractual.nombrecompleto();
                                                    correoR=useractual.getCorreo();
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.print("𝗖𝗔𝗟𝗜𝗙𝗜𝗖𝗔𝗖𝗜𝗢𝗡 (𝟭-𝟭𝟬): ");
                                                    calificacion = Lector.nextDouble();
                                                    Lector.nextLine();
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.print("𝗘𝗦𝗖𝗥𝗜𝗕𝗘 𝗧𝗨 𝗥𝗘𝗦𝗘𝗡̃𝗔: ");
                                                    comentarios=Lector.nextLine();
                                                    DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy HH:mm", new Locale("es", "ES"));
                                                    fechareseña = LocalDateTime.now().format(formato);
                                                    Reseñas nuevas = new Reseñas(usuarioR, correoR, comentarios, calificacion, fechareseña);
                                                    service.getReseñas().add(nuevas);
                                                    useractual.aggReseña(nuevas);
                                                    System.out.println("===============================================================================================");
                                                    System.out.println("                                      ¡𝗥𝗘𝗦𝗘𝗡̃𝗔 𝗣𝗨𝗕𝗟𝗜𝗖𝗔𝗗𝗔!");
                                                    System.out.println("===============================================================================================");
                                                    break;
                                                case 2:
                                                    System.out.println("===============================================================================================");
                                                    System.out.println("                                     𝗠𝗜𝗦 𝗥𝗘𝗦𝗘𝗡̃𝗔𝗦 𝗘𝗦𝗖𝗥𝗜𝗧𝗔𝗦");
                                                    System.out.println(useractual.viewReseñas());
                                                    break;
                                                default:
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                                    System.out.println("===============================================================================================");
                                                    break;
                                            }
                                            break;
                                        case 4:
                                            break;
                                        default:
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                            System.out.println("===============================================================================================");
                                            break;
                                    }
                                } while (op3!=4);
                                break;
                            case 2:
                                do {
                                    System.out.println("                                     𝗗𝗔𝗧𝗢𝗦 𝗣𝗘𝗥𝗦𝗢𝗡𝗔𝗟𝗘𝗦");
                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                    System.out.println("                                   𝟭- 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗖𝗧𝗨𝗔𝗟");
                                    System.out.println("                                   𝟮- 𝗘𝗗𝗜𝗧𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡");
                                    System.out.println("                                        𝟯- 𝗩𝗢𝗟𝗩𝗘𝗥");
                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                      System.out.print("                                 ¿Que opcion desea elegir? ");
                                    op3=Lector.nextInt();
                                    switch(op3) {
                                        case 1:
                                            Usuario.getUsuarios();
                                            Usuario obj5 = Usuario.getUsuarios().get(i);
                                            System.out.println(obj5.InfoAllUsuario());  
                                            break;
                                        case 2:
                                            int op0;
                                            String contra;
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.print("𝗡𝗢𝗠𝗕𝗥𝗘: ");
                                            nombre=Lector.next();
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.print("𝗔𝗣𝗘𝗟𝗟𝗜𝗗𝗢 𝗣𝗔𝗧𝗘𝗥𝗡𝗢: ");
                                            app=Lector.next();
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.print("𝗔𝗣𝗘𝗟𝗟𝗜𝗗𝗢 𝗠𝗔𝗧𝗘𝗥𝗡𝗢: ");
                                            apm=Lector.next();
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.print("𝗧𝗘𝗟𝗘𝗙𝗢𝗡𝗢 𝗗𝗘 𝗖𝗢𝗡𝗧𝗔𝗖𝗧𝗢: ");
                                            telefono=Lector.next();
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.print("𝗖𝗔𝗟𝗟𝗘: ");
                                            calle=Lector.next();
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.print("𝗡𝗨𝗠𝗘𝗥𝗢 𝗘𝗫𝗧𝗘𝗥𝗜𝗢𝗥: ");
                                            numero=Lector.next();
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.print("𝗖𝗜𝗨𝗗𝗔𝗗: ");
                                            ciudad=Lector.next();
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.print("𝗘𝗦𝗧𝗔𝗗𝗢: ");
                                            estado=Lector.next();
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.print("𝗖𝗢𝗗𝗜𝗚𝗢 𝗣𝗢𝗦𝗧𝗔𝗟: ");
                                            cp=Lector.next();
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                       𝗖𝗔𝗠𝗕𝗜𝗔𝗥 𝗖𝗢𝗡𝗧𝗥𝗔𝗦𝗘𝗡̃𝗔");
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println("                                         1- Si    2- No");
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.print("                                 ¿Desea cambiar la contraseña? ");
                                            op0=Lector.nextInt();
                                            switch (op0) {
                                                case 1:
                                                    do {
                                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                                        System.out.print("𝗜𝗡𝗚𝗥𝗘𝗦𝗘 𝗟𝗔 𝗖𝗢𝗡𝗧𝗥𝗔𝗦𝗘𝗡̃𝗔 𝗔𝗖𝗧𝗨𝗔𝗟: ");
                                                        contra=Lector.next();
                                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                                        if (!Usuario.getUsuarios().get(i).getContraseña().equals(contra)) {
                                                            System.out.println("                                        𝗖𝗢𝗡𝗧𝗥𝗔𝗦𝗘𝗡̃𝗔 𝗜𝗡𝗖𝗢𝗥𝗥𝗘𝗖𝗧𝗔");
                                                        }
                                                    } while (!Usuario.getUsuarios().get(i).getContraseña().equals(contra));
                                                    System.out.print("𝗜𝗡𝗚𝗥𝗘𝗦𝗘 𝗟𝗔 𝗡𝗨𝗘𝗩𝗔 𝗖𝗢𝗡𝗧𝗥𝗔𝗦𝗘𝗡̃𝗔: ");
                                                    contraseña=Lector.next();
                                                    break;
                                                case 2:
                                                    break;
                                                default:
                                                    System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                                    break;
                                            }
                                            Usuario obj10 = Usuario.getUsuarios().get(i);
                                            obj10.InfoUser(nombre, app, apm, telefono, contraseña, calle, numero, ciudad, estado, cp);
                                            System.out.println(obj10.InfoAllUsuario());
                                            break;
                                        case 3:
                                            break;
                                        default:
                                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                            break;
                                    }
                                } while (op3!=3);
                                break;
                            case 3:
                                break;
                            default:
                                System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op2!=3);
                    break;
                case 6:
                    return;
                default:
                    System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                    break;
            }
        } while (true);
    }
    
    
    //MENU ADMINISTRADOR
    public static void menuAdmin() {
        int op, op2, op3, op4, op5;
        do {
            System.out.println("                                       ¡𝗛𝗢𝗟𝗔 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢!");
            System.out.println("===============================================================================================");
            System.out.println("                                   𝟭- 𝗔𝗗𝗠𝗜𝗡𝗜𝗦𝗧𝗥𝗔𝗥 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦");
            System.out.println("                                   𝟮- 𝗔𝗗𝗠𝗜𝗡𝗜𝗦𝗧𝗥𝗔𝗥 𝗨𝗦𝗨𝗔𝗥𝗜𝗢𝗦");
            System.out.println("                                   𝟯- 𝗔𝗗𝗠𝗜𝗡𝗜𝗦𝗧𝗥𝗔𝗥 𝗥𝗘𝗣𝗢𝗥𝗧𝗘𝗦");
            System.out.println("                                 𝟰- 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗗𝗘 𝗟𝗔 𝗖𝗨𝗘𝗡𝗧𝗔");
            System.out.println("                                      𝟱- 𝗖𝗘𝗥𝗥𝗔𝗥 𝗦𝗘𝗦𝗜𝗢𝗡");
            System.out.println("-----------------------------------------------------------------------------------------------");
            System.out.print("                                  ¿Que opcion desea elegir? ");
            op=Lector.nextInt();
            System.out.println("===============================================================================================");
            switch(op) {
                case 1:
                    do {
                        System.out.println("                               ----𝗔𝗗𝗠𝗜𝗡𝗜𝗦𝗧𝗥𝗔𝗖𝗜𝗢𝗡 𝗗𝗘 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦----");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                     𝟭- 𝗔𝗟𝗧𝗔 𝗗𝗘 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦");
                        System.out.println("                                     𝟮- 𝗕𝗔𝗝𝗔 𝗗𝗘 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦");
                        System.out.println("                                    𝟯- 𝗘𝗗𝗜𝗖𝗜𝗢𝗡 𝗗𝗘 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦");
                        System.out.println("                                   𝟰- 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦");
                        System.out.println("                                  𝟱- 𝗩𝗢𝗟𝗩𝗘𝗥 𝗔𝗟 𝗠𝗘𝗡𝗨 𝗣𝗥𝗜𝗡𝗖𝗜𝗣𝗔𝗟");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                  ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                publicarservicio();
                                break;
                            case 2:
                                do {
                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                    System.out.println("                           𝟭- 𝗠𝗢𝗦𝗧𝗥𝗔𝗥 𝗧𝗢𝗗𝗢𝗦 𝗟𝗢𝗦 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                    System.out.println("                             𝟮- 𝗠𝗢𝗦𝗧𝗥𝗔𝗥 𝗟𝗢𝗦 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗣𝗢𝗥 𝗖𝗔𝗧𝗘𝗚𝗢𝗥𝗜𝗔");
                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                    System.out.print("                                  ¿Que opcion desea elegir? ");
                                    op3=Lector.nextInt();
                                    switch(op3) {
                                        case 1:
                                            System.out.println(Servicios.viewServicios());
                                            if (Servicios.viewServicios().contains("No hay servicios registrados")) {
                                                System.out.println("===============================================================================================");
                                                System.out.println("                                No hay servicios para eliminar");
                                                System.out.println("===============================================================================================");
                                            }
                                            else {
                                                System.out.print("                                ¿Que servicio desea eliminar? ");
                                                op4=Lector.nextInt();
                                                Servicios deleted = Servicios.getServiciosGenerales().get(op4-1);
                                                Servicios.deleteservice(deleted);
                                                System.out.println("===============================================================================================");
                                                System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗘𝗟𝗜𝗠𝗜𝗡𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                                System.out.println("===============================================================================================");
                                            }
                                            break;
                                        case 2:
                                            do {
                                                System.out.println("===============================================================================================");
                                                System.out.println("                                           𝗖𝗔𝗧𝗘𝗚𝗢𝗥𝗜𝗔𝗦");
                                                System.out.println("-----------------------------------------------------------------------------------------------");
                                                System.out.println("                          1- Belleza            5- Eventos");
                                                System.out.println("                          2- Deportes           6- Mantenimiento y reparacion");
                                                System.out.println("                          3- Educativo          7- Produccion y creativos");
                                                System.out.println("                          4- Entretenimiento    8- Salud y bienestar");
                                                System.out.println("-----------------------------------------------------------------------------------------------");
                                                System.out.print("                             ¿Que categoria de servicios desea ver? ");
                                                op4=Lector.nextInt();
                                                System.out.println("===============================================================================================");
                                                System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                                System.out.println("-----------------------------------------------------------------------------------------------");
                                                switch(op4){
                                                    case 1:
                                                        System.out.println(Belleza.viewBelleza());
                                                        if (Belleza.viewBelleza().contains("No hay servicios registrados")) {
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                No hay servicios para eliminar");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        else {
                                                            System.out.print("                                ¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            Belleza deleted = Belleza.getBellezas().get(op5-1);
                                                            Belleza.deleteservice(deleted);
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗘𝗟𝗜𝗠𝗜𝗡𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        break;
                                                    case 2:
                                                        System.out.println(Deportes.viewDeporte());
                                                        if (Deportes.viewDeporte().contains("No hay servicios registrados")) {
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                No hay servicios para eliminar");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        else {
                                                            System.out.print("                                ¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            Deportes deleted = Deportes.getDeportes().get(op5-1);
                                                            Deportes.deleteservice(deleted);
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗘𝗟𝗜𝗠𝗜𝗡𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        break;
                                                    case 3:
                                                        System.out.println(Educativo.viewEducativo());
                                                        if (Educativo.viewEducativo().contains("No hay servicios registrados")) {
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                No hay servicios para eliminar");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        else {
                                                            System.out.print("                                ¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            Educativo deleted = Educativo.getEducativos().get(op5-1);
                                                            Educativo.deleteservice(deleted);
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗘𝗟𝗜𝗠𝗜𝗡𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        break;
                                                    case 4:
                                                        System.out.println(Entretenimiento.viewShows());
                                                        if (Entretenimiento.viewShows().contains("No hay servicios registrados")) {
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                No hay servicios para eliminar");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        else {
                                                            System.out.print("                                ¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            Entretenimiento deleted = Entretenimiento.getShows().get(op5-1);
                                                            Entretenimiento.deleteservice(deleted);
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗘𝗟𝗜𝗠𝗜𝗡𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        break;
                                                    case 5:
                                                        System.out.println(Eventos.viewEventos());
                                                        if (Eventos.viewEventos().contains("No hay servicios registrados")) {
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                No hay servicios para eliminar");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        else {
                                                            System.out.print("                                ¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            Eventos deleted = Eventos.getEventos().get(op5-1);
                                                            Eventos.deleteservice(deleted);
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗘𝗟𝗜𝗠𝗜𝗡𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        break;
                                                    case 6:
                                                        System.out.println(MYR.viewMYR());
                                                        if (MYR.viewMYR().contains("No hay servicios registrados")) {
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                No hay servicios para eliminar");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        else {
                                                            System.out.print("                                ¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            MYR deleted = MYR.getMyr().get(op5-1);
                                                            MYR.deleteservice(deleted);
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗘𝗟𝗜𝗠𝗜𝗡𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        break;
                                                    case 7:
                                                        System.out.println(Produccion.viewProdu());
                                                        if (Produccion.viewProdu().contains("No hay servicios registrados")) {
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                No hay servicios para eliminar");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        else {
                                                            System.out.print("                                ¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            Produccion deleted = Produccion.getProducciones().get(op5-1);
                                                            Produccion.deleteservice(deleted);
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗘𝗟𝗜𝗠𝗜𝗡𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        break;
                                                    case 8:
                                                        System.out.println(Salud.viewSalud());
                                                        if (Salud.viewSalud().contains("No hay servicios registrados")) {
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                No hay servicios para eliminar");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        else {
                                                            System.out.print("                                ¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            Salud deleted = Salud.getSalud().get(op5-1);
                                                            Salud.deleteservice(deleted);
                                                            System.out.println("===============================================================================================");
                                                            System.out.println("                                 ¡𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢 𝗘𝗟𝗜𝗠𝗜𝗡𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                                            System.out.println("===============================================================================================");
                                                        }
                                                        break;
                                                    default:
                                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                                        System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                                        System.out.println("===============================================================================================");
                                                        break;
                                                }
                                            } while (op4<1||op4>8);
                                            break;
                                        default:
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                            System.out.println("===============================================================================================");
                                            break;
                                    }
                                } while (op3<1&&op3>2);
                                break;
                            case 3://MODIFICAR SERVICIOS
                                 do {
                                    System.out.println("===============================================================================================");
                                    System.out.println("                                           𝗖𝗔𝗧𝗘𝗚𝗢𝗥𝗜𝗔𝗦");
                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                    System.out.println("                          1- Belleza            5- Eventos");
                                    System.out.println("                          2- Deportes           6- Mantenimiento y reparacion");
                                    System.out.println("                          3- Educativo          7- Produccion y creativos");
                                    System.out.println("                          4- Entretenimiento    8- Salud y bienestar");
                                    System.out.println("                                          9- Volver");
                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                    System.out.print("                             ¿Que categoria de servicios desea ver? ");
                                    op4=Lector.nextInt();
                                    switch(op4){
                                        case 1:
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println(Belleza.viewBelleza());
                                            if (Belleza.viewBelleza().contains("No hay servicios registrados")) {
                                            System.out.println("===============================================================================================");
                                            }
                                            else {
                                                System.out.print("                                 ¿Que servicio desea elejir? ");
                                                op4=Lector.nextInt()-1;
                                                do {
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.println("                               𝟭- 𝗠𝗢𝗦𝗧𝗥𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗖𝗧𝗨𝗔𝗟");
                                                    System.out.println("                                   𝟮- 𝗘𝗗𝗜𝗧𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡");
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.print("                                 ¿Que opcion desea elejir? ");
                                                    op5=Lector.nextInt();
                                                    switch (op5) {
                                                        case 1:
                                                            System.out.println(Belleza.getBellezas().get(op4).InfoBelleza());
                                                            break;
                                                        case 2://MODIFICAR SERVICIOS
                                                            servicioactual=Belleza.getBellezas().get(op4);
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            tipo=servicioactual.getTipo();
                                                            modificar(servicioactual);
                                                            categorias(servicioactual);
                                                            System.out.println(Belleza.getBellezas().get(op4).InfoBelleza());
                                                            break;
                                                        default:
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                                            System.out.println("===============================================================================================");
                                                            break;
                                                    }
                                                } while (op5<1||op5>2);
                                            }
                                            break;
                                        case 2:
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println(Deportes.viewDeporte());
                                            if (Deportes.viewDeporte().contains("No hay servicios registrados")) {
                                            System.out.println("===============================================================================================");
                                            }
                                            else {
                                                System.out.print("                                 ¿Que servicio desea elejir? ");
                                                op4=Lector.nextInt()-1;
                                                do {
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.println("                               𝟭- 𝗠𝗢𝗦𝗧𝗥𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗖𝗧𝗨𝗔𝗟");
                                                    System.out.println("                                   𝟮- 𝗘𝗗𝗜𝗧𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡");
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.print("                                 ¿Que opcion desea elejir? ");
                                                    op5=Lector.nextInt();
                                                    switch (op5) {
                                                        case 1:
                                                            System.out.println(Deportes.getDeportes().get(op4).InfoDeportes());
                                                            break;
                                                        case 2://MODIFICAR SERVICIOS
                                                            servicioactual=Deportes.getDeportes().get(op4);
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            tipo=servicioactual.getTipo();
                                                            modificar(servicioactual);
                                                            categorias(servicioactual);
                                                            System.out.println(Deportes.getDeportes().get(op4).InfoDeportes());
                                                            break;
                                                        default:
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                                            System.out.println("===============================================================================================");
                                                            break;
                                                    }
                                                } while (op5<1||op5>2);
                                            }
                                            break;
                                        case 3:
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println(Educativo.viewEducativo());
                                            if (Educativo.viewEducativo().contains("No hay servicios registrados")) {
                                            System.out.println("===============================================================================================");
                                            }
                                            else {
                                                System.out.print("                                 ¿Que servicio desea elejir? ");
                                                op4=Lector.nextInt()-1;
                                                do {
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.println("                               𝟭- 𝗠𝗢𝗦𝗧𝗥𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗖𝗧𝗨𝗔𝗟");
                                                    System.out.println("                                   𝟮- 𝗘𝗗𝗜𝗧𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡");
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.print("                                 ¿Que opcion desea elejir? ");
                                                    op5=Lector.nextInt();
                                                    switch (op5) {
                                                        case 1:
                                                            System.out.println(Educativo.getEducativos().get(op4).InfoEducacion());
                                                            break;
                                                        case 2://MODIFICAR SERVICIOS
                                                            servicioactual=Educativo.getEducativos().get(op4);
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            tipo=servicioactual.getTipo();
                                                            modificar(servicioactual);
                                                            categorias(servicioactual);
                                                            System.out.println(Educativo.getEducativos().get(op4).InfoEducacion());
                                                            break;
                                                        default:
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                                            System.out.println("===============================================================================================");
                                                            break;
                                                    }
                                                } while (op5<1||op5>2);
                                            }
                                            break;
                                        case 4:
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println(Entretenimiento.viewShows());
                                            if (Entretenimiento.viewShows().contains("No hay servicios registrados")) {
                                            System.out.println("===============================================================================================");
                                            }
                                            else {
                                                System.out.print("                                 ¿Que servicio desea elejir? ");
                                                op4=Lector.nextInt()-1;
                                                do {
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.println("                               𝟭- 𝗠𝗢𝗦𝗧𝗥𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗖𝗧𝗨𝗔𝗟");
                                                    System.out.println("                                   𝟮- 𝗘𝗗𝗜𝗧𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡");
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.print("                                 ¿Que opcion desea elejir? ");
                                                    op5=Lector.nextInt();
                                                    switch (op5) {
                                                        case 1:
                                                            System.out.println(Entretenimiento.getShows().get(op4).InfoShows());
                                                            break;
                                                        case 2://MODIFICAR SERVICIOS
                                                            servicioactual=Entretenimiento.getShows().get(op4);
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            tipo=servicioactual.getTipo();
                                                            modificar(servicioactual);
                                                            categorias(servicioactual);
                                                            System.out.println(Entretenimiento.getShows().get(op4).InfoShows());
                                                            break;
                                                        default:
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                                            System.out.println("===============================================================================================");
                                                            break;
                                                    }
                                                } while (op5<1||op5>2);
                                            }
                                            break;
                                        case 5:
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println(Eventos.viewEventos());
                                            if (Eventos.viewEventos().contains("No hay servicios registrados")) {
                                            System.out.println("===============================================================================================");
                                            }
                                            else {
                                                System.out.print("                                 ¿Que servicio desea elejir? ");
                                                op4=Lector.nextInt()-1;
                                                do {
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.println("                               𝟭- 𝗠𝗢𝗦𝗧𝗥𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗖𝗧𝗨𝗔𝗟");
                                                    System.out.println("                                   𝟮- 𝗘𝗗𝗜𝗧𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡");
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.print("                                 ¿Que opcion desea elejir? ");
                                                    op5=Lector.nextInt();
                                                    switch (op5) {
                                                        case 1:
                                                            System.out.println(Eventos.getEventos().get(op4).InfoEventos());
                                                            break;
                                                        case 2://MODIFICAR SERVICIOS
                                                            servicioactual=Eventos.getEventos().get(op4);
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            tipo=servicioactual.getTipo();
                                                            modificar(servicioactual);
                                                            categorias(servicioactual);
                                                            System.out.println(Eventos.getEventos().get(op4).InfoEventos());
                                                            break;
                                                        default:
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                                            System.out.println("===============================================================================================");
                                                            break;
                                                    }
                                                } while (op5<1||op5>2);
                                            }
                                            break;
                                        case 6:
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println(MYR.viewMYR());
                                            if (MYR.viewMYR().contains("No hay servicios registrados")) {
                                            System.out.println("===============================================================================================");
                                            }
                                            else {
                                                System.out.print("                                 ¿Que servicio desea elejir? ");
                                                op4=Lector.nextInt()-1;
                                                do {
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.println("                               𝟭- 𝗠𝗢𝗦𝗧𝗥𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗖𝗧𝗨𝗔𝗟");
                                                    System.out.println("                                   𝟮- 𝗘𝗗𝗜𝗧𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡");
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.print("                                 ¿Que opcion desea elejir? ");
                                                    op5=Lector.nextInt();
                                                    switch (op5) {
                                                        case 1:
                                                            System.out.println(MYR.getMyr().get(op4).InfoMYR());
                                                            break;
                                                        case 2://MODIFICAR SERVICIOS
                                                            servicioactual=MYR.getMyr().get(op4);
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            tipo=servicioactual.getTipo();
                                                            modificar(servicioactual);
                                                            categorias(servicioactual);
                                                            System.out.println(MYR.getMyr().get(op4).InfoMYR());
                                                            break;
                                                        default:
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                                            System.out.println("===============================================================================================");
                                                            break;
                                                    }
                                                } while (op5<1||op5>2);
                                            }
                                            break;
                                        case 7:
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println(Produccion.viewProdu());
                                            if (Produccion.viewProdu().contains("No hay servicios registrados")) {
                                            System.out.println("===============================================================================================");
                                            }
                                            else {
                                                System.out.print("                                 ¿Que servicio desea elejir? ");
                                                op4=Lector.nextInt()-1;
                                                do {
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.println("                               𝟭- 𝗠𝗢𝗦𝗧𝗥𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗖𝗧𝗨𝗔𝗟");
                                                    System.out.println("                                   𝟮- 𝗘𝗗𝗜𝗧𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡");
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.print("                                 ¿Que opcion desea elejir? ");
                                                    op5=Lector.nextInt();
                                                    switch (op5) {
                                                        case 1:
                                                            System.out.println(Produccion.getProducciones().get(op4).InfoProduccion());
                                                            break;
                                                        case 2://MODIFICAR SERVICIOS
                                                            servicioactual=Produccion.getProducciones().get(op4);
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            tipo=servicioactual.getTipo();
                                                            modificar(servicioactual);
                                                            categorias(servicioactual);
                                                            System.out.println(Produccion.getProducciones().get(op4).InfoProduccion());
                                                            break;
                                                        default:
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                                            System.out.println("===============================================================================================");
                                                            break;
                                                    }
                                                } while (op5<1||op5>2);
                                            }
                                            break;
                                        case 8:
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                      𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦 𝗗𝗜𝗦𝗣𝗢𝗡𝗜𝗕𝗟𝗘𝗦");
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println(Salud.viewSalud());
                                            if (Salud.viewSalud().contains("No hay servicios registrados")) {
                                            System.out.println("===============================================================================================");
                                            }
                                            else {
                                                System.out.print("                                 ¿Que servicio desea elejir? ");
                                                op4=Lector.nextInt()-1;
                                                do {
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.println("                               𝟭- 𝗠𝗢𝗦𝗧𝗥𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗖𝗧𝗨𝗔𝗟");
                                                    System.out.println("                                   𝟮- 𝗘𝗗𝗜𝗧𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡");
                                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                                    System.out.print("                                 ¿Que opcion desea elejir? ");
                                                    op5=Lector.nextInt();
                                                    switch (op5) {
                                                        case 1:
                                                            System.out.println(Salud.getSalud().get(op4).InfoSalud());
                                                            break;
                                                        case 2://MODIFICAR SERVICIOS
                                                            servicioactual=Salud.getSalud().get(op4);
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            tipo=servicioactual.getTipo();
                                                            modificar(servicioactual);
                                                            categorias(servicioactual);
                                                            System.out.println(Salud.getSalud().get(op4).InfoSalud());
                                                            break;
                                                        default:
                                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                                            System.out.println("===============================================================================================");
                                                            break;
                                                    }
                                                } while (op5<1||op5>2);
                                            }
                                            break;
                                        case 9:
                                            System.out.println("===============================================================================================");
                                            break;
                                        default:
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                            break;
                                    }
                                } while (op4!=9);
                                break;
                            case 4:
                                consultadeservicios();
                                break;
                            case 5:
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                System.out.println("===============================================================================================");
                                break;
                        }
                    } while (op2!=5);
                    break;
                case 2:
                    do {
                        System.out.println("                              ----𝗔𝗗𝗠𝗜𝗡𝗜𝗦𝗧𝗥𝗔𝗖𝗜𝗢𝗡 𝗗𝗘 𝗨𝗦𝗨𝗔𝗥𝗜𝗢𝗦----");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                  𝟭- 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗨𝗦𝗨𝗔𝗥𝗜𝗢𝗦");
                        System.out.println("                                    𝟮- 𝗔𝗟𝗧𝗔 𝗗𝗘 𝗨𝗦𝗨𝗔𝗥𝗜𝗢𝗦");
                        System.out.println("                                    𝟯- 𝗕𝗔𝗝𝗔 𝗗𝗘 𝗨𝗦𝗨𝗔𝗥𝗜𝗢𝗦");
                        System.out.println("                                 𝟰- 𝗩𝗢𝗟𝗩𝗘𝗥 𝗔𝗟 𝗠𝗘𝗡𝗨 𝗣𝗥𝗜𝗡𝗖𝗜𝗣𝗔𝗟");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                 ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch (op2) {
                            case 1:
                                System.out.println("===============================================================================================");
                                System.out.println("                                 𝗟𝗜𝗦𝗧𝗔 𝗗𝗘 𝗨𝗦𝗨𝗔𝗥𝗜𝗢𝗦 𝗥𝗘𝗚𝗜𝗦𝗧𝗥𝗔𝗗𝗢𝗦");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                                         𝟭- 𝗨𝗦𝗨𝗔𝗥𝗜𝗢𝗦");
                                System.out.println("                                      𝟮- 𝗔𝗗𝗠𝗜𝗡𝗜𝗦𝗧𝗥𝗔𝗗𝗢𝗥𝗘𝗦");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("                            ¿Que tipo de usuario quiere consultar? ");
                                op3=Lector.nextInt();
                                switch(op3){
                                    case 1:
                                        System.out.println(Usuario.ListaUsuarios());
                                        break;
                                    case 2:
                                        System.out.println(Administrador.ListaAdmins());
                                        break;
                                    default:
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                        System.out.println("===============================================================================================");
                                        break;
                                }
                                break;
                            case 2:
                                System.out.println("===============================================================================================");
                                System.out.println("                                        𝗔𝗟𝗧𝗔 𝗗𝗘 𝗨𝗦𝗨𝗔𝗥𝗜𝗢𝗦");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                                          𝟭- 𝗨𝗦𝗨𝗔𝗥𝗜𝗢");
                                System.out.println("                                        𝟮- 𝗔𝗗𝗠𝗜𝗡𝗜𝗦𝗧𝗥𝗔𝗗𝗢𝗥");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("                              ¿Que tipo de usuario quiere registrar? ");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                op3=Lector.nextInt();
                                switch(op3) {
                                    case 1:
                                        tipoUser="Usuario";
                                        registro();
                                        break;
                                    case 2:
                                        tipoUser="Administrador";
                                        registro();
                                        break;
                                    default:
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                        System.out.println("===============================================================================================");
                                        break;
                                }
                                break;
                            case 3:
                                System.out.println("===============================================================================================");
                                System.out.println("                                        𝗕𝗔𝗝𝗔 𝗗𝗘 𝗨𝗦𝗨𝗔𝗥𝗜𝗢𝗦");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                                          𝟭- 𝗨𝗦𝗨𝗔𝗥𝗜𝗢");
                                System.out.println("                                        𝟮- 𝗔𝗗𝗠𝗜𝗡𝗜𝗦𝗧𝗥𝗔𝗗𝗢𝗥");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("                               ¿Que tipo de usuario quiere eliminar? ");
                                op3=Lector.nextInt();
                                switch(op3) {
                                    case 1:
                                        System.out.println(Usuario.ListaUsuarios());
                                        System.out.print("                                   ¿Que usuario desea eliminar? ");
                                        op4=Lector.nextInt()-1;
                                        if (op4>=0&&op4<Usuario.getUsuarios().size()) {
                                            Usuario.getUsuarios().remove(op4);
                                            System.out.println("===============================================================================================");
                                            System.out.println("                                ¡𝗨𝗦𝗨𝗔𝗥𝗜𝗢 𝗘𝗟𝗜𝗠𝗜𝗡𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                            System.out.println("===============================================================================================");
                                        }
                                        else {
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    case 2:
                                        System.out.println(Administrador.ListaAdmins());
                                        System.out.print("                                ¿Que administrador desea eliminar? ");
                                        op4=Lector.nextInt()-1;
                                        if (op4>=0&&op4<Administrador.getAdministradores().size()) {
                                            Administrador.getAdministradores().remove(op4);
                                            System.out.println("===============================================================================================");
                                            System.out.println("                              ¡𝗔𝗗𝗠𝗜𝗡𝗜𝗦𝗧𝗥𝗔𝗗𝗢𝗥 𝗘𝗟𝗜𝗠𝗜𝗡𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!");
                                            System.out.println("===============================================================================================");
                                        }
                                        else {
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                            System.out.println("===============================================================================================");
                                        }
                                        break;
                                    default:
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                        System.out.println("===============================================================================================");
                                        break;
                                }
                                break;
                            case 4:
                                break;
                            default:
                            System.out.println("-----------------------------------------------------------------------------------------------");
                            System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                            System.out.println("===============================================================================================");
                            break;
                        }
                    } while (op2!=4);
                    break;
                case 3:
                    do {
                        System.out.println("                               ----𝗔𝗗𝗠𝗜𝗡𝗜𝗦𝗧𝗥𝗔𝗖𝗜𝗢𝗡 𝗗𝗘 𝗥𝗘𝗣𝗢𝗥𝗧𝗘𝗦----");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                     𝟭- 𝗚𝗘𝗡𝗘𝗥𝗔𝗥 𝗥𝗘𝗣𝗢𝗥𝗧𝗘");
                        System.out.println("                                   𝟮- 𝗖𝗢𝗡𝗦𝗨𝗟𝗧𝗔 𝗗𝗘 𝗥𝗘𝗣𝗢𝗥𝗧𝗘𝗦");
                        System.out.println("                                  𝟯- 𝗩𝗢𝗟𝗩𝗘𝗥 𝗔𝗟 𝗠𝗘𝗡𝗨 𝗣𝗥𝗜𝗡𝗖𝗜𝗣𝗔𝗟");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                 ¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        switch (op2) {
                            case 1:
                                //generar reporteS
                                System.out.println("===============================================================================================");
                                System.out.println("                                  𝗧𝗜𝗣𝗢 𝗗𝗘 𝗥𝗘𝗣𝗢𝗥𝗧𝗘 𝗔 𝗚𝗘𝗡𝗘𝗥𝗔𝗥");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                                     𝟭- 𝗧𝗜𝗣𝗢 𝗗𝗘 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢");
                                System.out.println("                                    𝟮- 𝗣𝗥𝗘𝗖𝗜𝗢 𝗗𝗘 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢");
                                System.out.println("                                    𝟯- 𝗖𝗜𝗨𝗗𝗔𝗗 𝗗𝗘 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢");
                                System.out.println("                                  𝟰- 𝗖𝗔𝗟𝗜𝗙𝗜𝗖𝗔𝗖𝗜𝗢𝗡 𝗗𝗘 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("                                  ¿Que opcion desea elegir? ");
                                op3=Lector.nextInt();
                                switch(op3) {
                                    case 1:
                                        System.out.println("===============================================================================================");
                                        System.out.println(Reportes.serviciostipo(Servicios.generales));
                                        System.out.println("===============================================================================================");
                                        break;
                                    case 2:
                                        System.out.println("===============================================================================================");
                                        System.out.println("                                      𝟭- 𝗠𝗘𝗡𝗢𝗥 𝗔 𝗠𝗔𝗬𝗢𝗥");
                                        System.out.println("                                      𝟮- 𝗠𝗔𝗬𝗢𝗥 𝗔 𝗠𝗘𝗡𝗢𝗥");
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("                                  ¿Que opcion desea elegir? ");
                                        op4=Lector.nextInt();
                                        switch(op4) {
                                            case 1:
                                                System.out.println("===============================================================================================");
                                                System.out.println(Reportes.serviciosprecio(Servicios.generales));
                                                System.out.println("===============================================================================================");
                                                break;
                                            case 2:
                                                System.out.println("===============================================================================================");
                                                System.out.println(Reportes.serviciosprecio2(Servicios.generales));
                                                System.out.println("===============================================================================================");
                                                break;
                                            default:
                                                System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                                break;
                                        }
                                        break;
                                    case 3:
                                        System.out.println("===============================================================================================");
                                        System.out.println(Reportes.serviciosciudad(Servicios.generales));
                                        System.out.println("===============================================================================================");
                                        break;
                                    case 4:
                                        System.out.println("===============================================================================================");
                                        System.out.println("                                      𝟭- 𝗠𝗘𝗡𝗢𝗥 𝗔 𝗠𝗔𝗬𝗢𝗥");
                                        System.out.println("                                      𝟮- 𝗠𝗔𝗬𝗢𝗥 𝗔 𝗠𝗘𝗡𝗢𝗥");
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.print("                                  ¿Que opcion desea elegir? ");
                                        op4=Lector.nextInt();
                                        switch(op4) {
                                            case 1:
                                                System.out.println("===============================================================================================");
                                                System.out.println(Reportes.serviciocalificacion2(Servicios.generales));
                                                System.out.println("===============================================================================================");
                                                break;
                                            case 2:
                                                System.out.println("===============================================================================================");
                                                System.out.println(Reportes.servicioscalificacion(Servicios.generales));
                                                System.out.println("===============================================================================================");
                                                break;
                                            default:
                                                System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                                break;
                                        }
                                        break;
                                    default:
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                        break;
                                }
                                break;
                            case 2:
                                System.out.println(Reportes.viewhistorial());
                                System.out.print("                                 ¿Que opcion deseas elegir? ");
                                op4=Lector.nextInt()-1;
                                System.out.println("===============================================================================================");
                                System.out.println(Reportes.viewreporte(op4));
                                System.out.println("===============================================================================================");
                                break;
                            case 3:
                                break;
                            default:
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                            ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                System.out.println("===============================================================================================");
                                break;
                        }
                    } while (op2!=3);
                    break;
                case 4:
                    do {
                        System.out.println("                                    ----𝗗𝗔𝗧𝗢𝗦 𝗣𝗘𝗥𝗦𝗢𝗡𝗔𝗟𝗘𝗦----");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.println("                                     𝟭- 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗖𝗧𝗨𝗔𝗟");
                        System.out.println("                                     𝟮- 𝗘𝗗𝗜𝗧𝗔𝗥 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡");
                        System.out.println("                                   𝟯- 𝗩𝗢𝗟𝗩𝗘𝗥 𝗔𝗟 𝗠𝗘𝗡𝗨 𝗣𝗥𝗜𝗡𝗖𝗜𝗣𝗔𝗟");
                        System.out.println("-----------------------------------------------------------------------------------------------");
                        System.out.print("                                    ¿Que opcion desea elegir? ");
                        op3=Lector.nextInt();
                        switch(op3) {
                            case 1:
                                Administrador.predeterminadosA();
                                Administrador obj6 = Administrador.getAdministradores().get(i);
                                System.out.println(obj6.InfoAllUsuario());
                                break;
                            case 2:
                                int op0;
                                String contra;
                                System.out.println("===============================================================================================");
                                System.out.println("                                   𝗘𝗗𝗜𝗖𝗜𝗢𝗡 𝗗𝗘 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("𝗡𝗢𝗠𝗕𝗥𝗘: ");
                                nombre=Lector.next();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("𝗔𝗣𝗘𝗟𝗟𝗜𝗗𝗢 𝗣𝗔𝗧𝗘𝗥𝗡𝗢: ");
                                app=Lector.next();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("𝗔𝗣𝗘𝗟𝗟𝗜𝗗𝗢 𝗠𝗔𝗧𝗘𝗥𝗡𝗢: ");
                                apm=Lector.next();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("𝗧𝗘𝗟𝗘𝗙𝗢𝗡𝗢 𝗗𝗘 𝗖𝗢𝗡𝗧𝗔𝗖𝗧𝗢: ");
                                telefono=Lector.next();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                do {
                                    System.out.print("𝗖𝗢𝗥𝗥𝗘𝗢 𝗘𝗟𝗘𝗖𝗧𝗥𝗢𝗡𝗜𝗖𝗢: ");
                                    correo=Lector.next();
                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                    existe=true;
                                    if (!correo.contains("@")||!correo.contains(".")) {
                                        System.out.println("                                      ¡𝗖𝗢𝗥𝗥𝗘𝗢 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗢!");
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                        existe=false;
                                        continue;
                                    }
                                    for (int i = 0; i < Usuario.getUsuarios().size(); i++) {
                                        if (Usuario.getUsuarios().get(i).getCorreo().equals(correo)) {
                                            existe=false;
                                        }
                                    }
                                    for (int i = 0; i < Administrador.getAdministradores().size(); i++) {
                                        if (Administrador.getAdministradores().get(i).getCorreo().equals(correo)) {
                                            existe=false;
                                        }
                                    }
                                    if (existe==false) {
                                        System.out.println("                            ¡𝗘𝗟 𝗖𝗢𝗥𝗥𝗘𝗢 𝗬𝗔 𝗘𝗦𝗧𝗔 𝗘𝗡 𝗨𝗦𝗢, 𝗘𝗟𝗜𝗝𝗔 𝗢𝗧𝗥𝗢!");
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                    }
                                } while (existe==false);
                                do {
                                    System.out.print("𝗨𝗦𝗨𝗔𝗥𝗜𝗢: ");
                                    usuario=Lector.next();
                                    System.out.println("-----------------------------------------------------------------------------------------------");
                                    existe=true;
                                    for (int i = 0; i < Usuario.getUsuarios().size(); i++) {
                                        if (Usuario.getUsuarios().get(i).getUsuario().equals(usuario)) {
                                            existe=false;
                                        }
                                    }
                                    for (int i = 0; i < Administrador.getAdministradores().size(); i++) {
                                        if (Administrador.getAdministradores().get(i).getUsuario().equals(usuario)) {
                                            existe=false;
                                        }
                                    }
                                    if (existe==false) {
                                        System.out.println("                           ¡𝗘𝗟 𝗨𝗦𝗨𝗔𝗥𝗜𝗢 𝗬𝗔 𝗘𝗦𝗧𝗔 𝗘𝗡 𝗨𝗦𝗢, 𝗘𝗟𝗜𝗝𝗔 𝗢𝗧𝗥𝗢!");
                                        System.out.println("-----------------------------------------------------------------------------------------------");
                                    }
                                } while (existe==false);
                                System.out.print("𝗖𝗔𝗟𝗟𝗘: ");
                                calle=Lector.next();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("𝗡𝗨𝗠𝗘𝗥𝗢 𝗘𝗫𝗧𝗘𝗥𝗜𝗢𝗥: ");
                                numero=Lector.next();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("𝗖𝗜𝗨𝗗𝗔𝗗: ");
                                ciudad=Lector.next();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("𝗘𝗦𝗧𝗔𝗗𝗢: ");
                                estado=Lector.next();
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("𝗖𝗢𝗗𝗜𝗚𝗢 𝗣𝗢𝗦𝗧𝗔𝗟: ");
                                cp=Lector.next();
                                System.out.println("===============================================================================================");
                                System.out.println("                                       𝗖𝗔𝗠𝗕𝗜𝗔𝗥 𝗖𝗢𝗡𝗧𝗥𝗔𝗦𝗘𝗡̃𝗔");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.println("                                         1- Si    2- No");
                                System.out.println("-----------------------------------------------------------------------------------------------");
                                System.out.print("                                 ¿Desea cambiar la contraseña? ");
                                op0=Lector.nextInt();
                                switch (op0) {
                                    case 1:
                                        do {
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            System.out.print("𝗜𝗡𝗚𝗥𝗘𝗦𝗘 𝗟𝗔 𝗖𝗢𝗡𝗧𝗥𝗔𝗦𝗘𝗡̃𝗔 𝗔𝗖𝗧𝗨𝗔𝗟: ");
                                            contra=Lector.next();
                                            System.out.println("-----------------------------------------------------------------------------------------------");
                                            if (!Administrador.getAdministradores().get(i).getContraseña().equals(contra)) {
                                                System.out.println("                                        𝗖𝗢𝗡𝗧𝗥𝗔𝗦𝗘𝗡̃𝗔 𝗜𝗡𝗖𝗢𝗥𝗥𝗘𝗖𝗧𝗔");
                                            }
                                        } while (!Administrador.getAdministradores().get(i).getContraseña().equals(contra));
                                        System.out.print("𝗜𝗡𝗚𝗥𝗘𝗦𝗘 𝗟𝗔 𝗡𝗨𝗘𝗩𝗔 𝗖𝗢𝗡𝗧𝗥𝗔𝗦𝗘𝗡̃𝗔: ");
                                        contraseña=Lector.next();
                                        break;
                                    case 2:
                                        break;
                                    default:
                                        System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                        break;
                                }
                                Administrador obj11 = Administrador.getAdministradores().get(i);
                                obj11.infoAdmin(nombre, app, apm, usuario, telefono, correo, contraseña, calle, numero, ciudad, estado, cp);
                                System.out.println(obj11.InfoAllUsuario());
                                break;
                            case 3:
                                break;
                            default:
                                System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                                break;
                        }
                    } while (op3!=3);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                    break;
            }
        } while (true);
    }
    
    
    //METODO ACCESO
    public static void acceso() {
        System.out.println("    ▀█▀ ░█▄─░█ ▀█▀ ░█▀▀█ ▀█▀ ░█▀▀▀█ 　 ░█▀▀▄ ░█▀▀▀ 　 ░█▀▀▀█ ░█▀▀▀ ░█▀▀▀█ ▀█▀ ░█▀▀▀█ ░█▄─░█ \n" +
"    ░█─ ░█░█░█ ░█─ ░█─── ░█─ ░█──░█ 　 ░█─░█ ░█▀▀▀ 　 ─▀▀▀▄▄ ░█▀▀▀ ─▀▀▀▄▄ ░█─ ░█──░█ ░█░█░█ \n" +
"    ▄█▄ ░█──▀█ ▄█▄ ░█▄▄█ ▄█▄ ░█▄▄▄█ 　 ░█▄▄▀ ░█▄▄▄ 　 ░█▄▄▄█ ░█▄▄▄ ░█▄▄▄█ ▄█▄ ░█▄▄▄█ ░█──▀█");
        System.out.println("===============================================================================================");
        System.out.print("                           𝗖𝗢𝗥𝗥𝗘𝗢 𝗘𝗟𝗘𝗖𝗧𝗥𝗢𝗡𝗜𝗖𝗢: ");
        correo=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("                           𝗖𝗢𝗡𝗧𝗥𝗔𝗦𝗘𝗡̃𝗔: ");
        contraseña=Lector.next();
        for (int i = 0; i < Administrador.getAdministradores().size(); i++) {
            Administrador admin = Administrador.getAdministradores().get(i);
            if (admin.getCorreo().equals(correo)&&admin.getContraseña().equals(contraseña)) {
                useractual=admin;
                System.out.println("===============================================================================================");
                System.out.println("                  ░█▀▀█ ▀█▀ ░█▀▀▀ ░█▄─░█ ░█──░█ ░█▀▀▀ ░█▄─░█ ▀█▀ ░█▀▀▄ ░█▀▀▀█ \n" +
"                  ░█▀▀▄ ░█─ ░█▀▀▀ ░█░█░█ ─░█░█─ ░█▀▀▀ ░█░█░█ ░█─ ░█─░█ ░█──░█ \n" +
"                  ░█▄▄█ ▄█▄ ░█▄▄▄ ░█──▀█ ──▀▄▀─ ░█▄▄▄ ░█──▀█ ▄█▄ ░█▄▄▀ ░█▄▄▄█");
                System.out.println("                                  ¡"+admin.nombrecompleto()+"!");
                menuAdmin();
                return;
            }
        }
        for (int i = 0; i < Usuario.getUsuarios().size(); i++) {
            Usuario user = Usuario.getUsuarios().get(i);
            if (user.getCorreo().equals(correo)&&user.getContraseña().equals(contraseña)) {
                useractual=user;
                System.out.println("===============================================================================================");
                System.out.println("                  ░█▀▀█ ▀█▀ ░█▀▀▀ ░█▄─░█ ░█──░█ ░█▀▀▀ ░█▄─░█ ▀█▀ ░█▀▀▄ ░█▀▀▀█ \n" +
"                  ░█▀▀▄ ░█─ ░█▀▀▀ ░█░█░█ ─░█░█─ ░█▀▀▀ ░█░█░█ ░█─ ░█─░█ ░█──░█ \n" +
"                  ░█▄▄█ ▄█▄ ░█▄▄▄ ░█──▀█ ──▀▄▀─ ░█▄▄▄ ░█──▀█ ▄█▄ ░█▄▄▀ ░█▄▄▄█");
                System.out.println("                                  ¡"+user.nombrecompleto()+"!");
                menuUsuario();
                return;
            }
        }
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.println("                              𝗖𝗢𝗥𝗥𝗘𝗢 𝗢 𝗖𝗢𝗡𝗧𝗥𝗔𝗦𝗘𝗡̃𝗔 𝗜𝗡𝗖𝗢𝗥𝗥𝗘𝗖𝗧𝗢𝗦");
    }
    
    
    //METODO REGISTRO
    public static void registro() {
        System.out.print("𝗡𝗢𝗠𝗕𝗥𝗘: ");
        nombre=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        Lector.nextLine();
        System.out.print("𝗔𝗣𝗘𝗟𝗟𝗜𝗗𝗢 𝗣𝗔𝗧𝗘𝗥𝗡𝗢: ");
        app=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗔𝗣𝗘𝗟𝗟𝗜𝗗𝗢 𝗠𝗔𝗧𝗘𝗥𝗡𝗢: ");
        apm=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        do {
            System.out.print("𝗖𝗥𝗘𝗔𝗥 𝗨𝗦𝗨𝗔𝗥𝗜𝗢: ");
            usuario=Lector.next();
            System.out.println("-----------------------------------------------------------------------------------------------");
            existe=true;
            for (int i = 0; i < Usuario.getUsuarios().size(); i++) {
                if (Usuario.getUsuarios().get(i).getUsuario().equals(usuario)) {
                    existe=false;
                }
            }
            for (int i = 0; i < Administrador.getAdministradores().size(); i++) {
                if (Administrador.getAdministradores().get(i).getUsuario().equals(usuario)) {
                    existe=false;
                }
            }
            if (existe==false) {
                System.out.println("                           ¡𝗘𝗟 𝗨𝗦𝗨𝗔𝗥𝗜𝗢 𝗬𝗔 𝗘𝗦𝗧𝗔 𝗘𝗡 𝗨𝗦𝗢, 𝗘𝗟𝗜𝗝𝗔 𝗢𝗧𝗥𝗢!");
                System.out.println("-----------------------------------------------------------------------------------------------");
            }
        } while (existe==false);
        System.out.print("𝗜𝗗𝗘𝗡𝗧𝗜𝗙𝗜𝗖𝗔𝗖𝗜𝗢𝗡: ");
        identificacion=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗧𝗘𝗟𝗘𝗙𝗢𝗡𝗢: ");
        telefono=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        Lector.nextLine();
        do {
            System.out.print("𝗖𝗢𝗥𝗥𝗘𝗢 𝗘𝗟𝗘𝗖𝗧𝗥𝗢𝗡𝗜𝗖𝗢: ");
            correo=Lector.next();
            System.out.println("-----------------------------------------------------------------------------------------------");
            existe=true;
            if (!correo.contains("@")||!correo.contains(".")) {
                System.out.println("                                      ¡𝗖𝗢𝗥𝗥𝗘𝗢 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗢!");
                System.out.println("-----------------------------------------------------------------------------------------------");
                existe=false;
                continue;
            }
            for (int i = 0; i < Usuario.getUsuarios().size(); i++) {
                if (Usuario.getUsuarios().get(i).getCorreo().equals(correo)) {
                    existe=false;
                }
            }
            for (int i = 0; i < Administrador.getAdministradores().size(); i++) {
                if (Administrador.getAdministradores().get(i).getCorreo().equals(correo)) {
                    existe=false;
                }
            }
            if (existe==false) {
                System.out.println("                           ¡𝗘𝗟 𝗖𝗢𝗥𝗥𝗘𝗢 𝗬𝗔 𝗘𝗦𝗧𝗔 𝗘𝗡 𝗨𝗦𝗢, 𝗘𝗟𝗜𝗝𝗔 𝗢𝗧𝗥𝗢!");
                System.out.println("-----------------------------------------------------------------------------------------------");
            }
        } while (existe==false);
        System.out.print("𝗖𝗥𝗘𝗔𝗥 𝗖𝗢𝗡𝗧𝗥𝗔𝗦𝗘𝗡̃𝗔: ");
        contraseña=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗖𝗔𝗟𝗟𝗘: ");
        calle=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗡𝗨𝗠𝗘𝗥𝗢 𝗘𝗫𝗧𝗘𝗥𝗜𝗢𝗥: ");
        numero=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗖𝗢𝗗𝗜𝗚𝗢 𝗣𝗢𝗦𝗧𝗔𝗟: ");
        cp=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗖𝗜𝗨𝗗𝗔𝗗 𝗗𝗘 𝗥𝗘𝗦𝗜𝗗𝗘𝗡𝗖𝗜𝗔: ");
        ciudad=Lector.next();
        System.out.println("-----------------------------------------------------------------------------------------------");
        System.out.print("𝗘𝗦𝗧𝗔𝗗𝗢: ");
        estado=Lector.next();
        System.out.println("===============================================================================================");
        if (tipoUser.equals("Usuario")) {
            Usuario obj1 = new Usuario(usuario, contraseña, nombre, app, apm, calle, numero, ciudad, estado, cp, telefono, correo, identificacion, tipoUser);
            Usuario.aggUsuario(obj1);
        }
        else if (tipoUser.equals("Administrador")) {
            Administrador obj2 = new Administrador(usuario, contraseña, nombre, app, apm, calle, numero, ciudad, estado, cp, telefono, correo, identificacion, tipoUser);
            Administrador.aggAdmin(obj2);
        }
        System.out.println("                                      ¡𝗥𝗘𝗚𝗜𝗦𝗧𝗥𝗢 𝗘𝗫𝗜𝗧𝗢𝗦𝗢!");
        System.out.println("===============================================================================================");
    }
    
    //MAIN
    public static void main(String[] args) {
        Scanner Lector = new Scanner (System.in);
        Administrador.predeterminadosA();
        Belleza.predeterminados();
        Usuario.predeterminadosU();
        Deportes.predeterminados();
        Educativo.predeterminados();
        Entretenimiento.predeterminados();
        Eventos.Predeterinados();
        MYR.Predeterminados();
        Produccion.Predeterminados();
        Salud.Predeterminados();
        int op;
        do {
            System.out.println("===============================================================================================");
            System.out.println("████████╗██████╗░░█████╗░██████╗░███████╗  ███╗░░░███╗░█████╗░██████╗░██╗░░██╗███████╗████████╗\n" +
"╚══██╔══╝██╔══██╗██╔══██╗██╔══██╗██╔════╝  ████╗░████║██╔══██╗██╔══██╗██║░██╔╝██╔════╝╚══██╔══╝\n" +
"░░░██║░░░██████╔╝███████║██║░░██║█████╗░░  ██╔████╔██║███████║██████╔╝█████═╝░█████╗░░░░░██║░░░\n" +
"░░░██║░░░██╔══██╗██╔══██║██║░░██║██╔══╝░░  ██║╚██╔╝██║██╔══██║██╔══██╗██╔═██╗░██╔══╝░░░░░██║░░░\n" +
"░░░██║░░░██║░░██║██║░░██║██████╔╝███████╗  ██║░╚═╝░██║██║░░██║██║░░██║██║░╚██╗███████╗░░░██║░░░\n" +
"░░░╚═╝░░░╚═╝░░╚═╝╚═╝░░╚═╝╚═════╝░╚══════╝  ╚═╝░░░░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚═╝╚══════╝░░░╚═╝░░░");
            System.out.println("                                       𝐭𝐫𝐚𝐝𝐞𝐦𝐚𝐫𝐤𝐞𝐭.𝐜𝐨𝐦");
            System.out.println("===============================================================================================");
            System.out.println("                                      𝟭- 𝗜𝗡𝗜𝗖𝗜𝗔𝗥 𝗦𝗘𝗦𝗜𝗢𝗡");
            System.out.println("                                       𝟮- 𝗥𝗘𝗚𝗜𝗦𝗧𝗥𝗔𝗥𝗦𝗘");
            System.out.println("                                          𝟯- 𝗦𝗔𝗟𝗜𝗥");
            System.out.println("-----------------------------------------------------------------------------------------------");
            System.out.print("                                 ¿Que opcion desea elejir? ");
            op=Lector.nextInt();
            System.out.println("===============================================================================================");
            switch (op) {
                case 1:
                    acceso();
                    break;
                case 2:
                    System.out.println("             ░█▀▀█ ░█▀▀█ ░█▀▀▀ ─█▀▀█ ░█▀▀█ 　 ░█▀▀█ ░█─░█ ░█▀▀▀ ░█▄─░█ ▀▀█▀▀ ─█▀▀█ \n" +
"             ░█─── ░█▄▄▀ ░█▀▀▀ ░█▄▄█ ░█▄▄▀ 　 ░█─── ░█─░█ ░█▀▀▀ ░█░█░█ ─░█── ░█▄▄█ \n" +
"             ░█▄▄█ ░█─░█ ░█▄▄▄ ░█─░█ ░█─░█ 　 ░█▄▄█ ─▀▄▄▀ ░█▄▄▄ ░█──▀█ ─░█── ░█─░█");
                    System.out.println("===============================================================================================");
                    tipoUser="Usuario";
                    registro();
                    acceso();
                    break;
                case 3:
                    System.out.println("       ░█──░█ ░█─░█ ░█▀▀▀ ░█─── ░█──░█ ░█▀▀▀ 　 ░█▀▀█ ░█▀▀█ ░█▀▀▀█ ░█▄─░█ ▀▀█▀▀ ░█▀▀▀█ █ \n" +
"       ─░█░█─ ░█─░█ ░█▀▀▀ ░█─── ─░█░█─ ░█▀▀▀ 　 ░█▄▄█ ░█▄▄▀ ░█──░█ ░█░█░█ ─░█── ░█──░█ ▀ \n" +
"       ──▀▄▀─ ─▀▄▄▀ ░█▄▄▄ ░█▄▄█ ──▀▄▀─ ░█▄▄▄ 　 ░█─── ░█─░█ ░█▄▄▄█ ░█──▀█ ─░█── ░█▄▄▄█ ▄");
                    System.out.println("                                      𝐭𝐫𝐚𝐝𝐞𝐦𝐚𝐫𝐤𝐞𝐭.𝐜𝐨𝐦");
                    System.out.println("===============================================================================================");
                    return;
                default:
                    System.out.println("                           ¡𝗨𝗣𝗦! 𝗢𝗣𝗖𝗜𝗢𝗡 𝗜𝗡𝗩𝗔𝗟𝗜𝗗𝗔, 𝗜𝗡𝗧𝗘𝗡𝗧𝗘 𝗗𝗘 𝗡𝗨𝗘𝗩𝗢");
                    break;   
            }
        } while (true);
    }   
}
