package sistemadeintercambio;
import java.util.*;
import Servicios.Belleza;
import Servicios.Deportes;
import Servicios.Educativo;
import Servicios.Entretenimiento;
import Servicios.Eventos;
import Servicios.MYR;
import Servicios.Produccion;
import Servicios.Salud;
import sistemadeintercambio.Servicios;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class SistemaDeIntercambio {
    public static String correo, contraseña, nombre, app, apm, calle, numero, ciudad, estado, cp, usuario,
                    descripcion, coordenadas, complejidad, horario, recomendaciones,
                    material, comentarios, opiniones, fecha_opinion, relacionados, identificacion, telefono,
                    nombreServicio, ciudadServicio, tipoUser, edad, calleServicio, estadoServicio, numeroServicio, cpServicio,
                    tipo, tipoBelleza, materialBelleza, lugarBelleza, tipoDeporte, materialDeporte, nivelDeporte, lugarDeporte,
                    materia, nivelEducativo, modalidad, materialEducativo, nivelAcademico, tipoShow, RequisitosShow, materialShow, tipoEvento,
                    capacidadEvento, lugarEvento, paquetesEvento, tipomyr, garantia, materialmyr, proyecto, formato, requisitosProdu, usocomercial, copyright,
                    tipoSalud, requisitosSalud, ubicacionSalud, fechareseña, usuarioR, correoR;
    public static double precio, calificacion, monto;
    public static boolean existe=true;
    public static int opcion, i;
    public static Usuario useractual;
    public static Servicios servicioactual;
    public static Scanner Lector = new Scanner (System.in);
    
    //METODO PARA MODIFICAR SERVICIOS CATEGORIAS
    public static void categorias(Servicios servicioactual) {
        int op, op2;
        do {
            System.out.println("=====================CATEGORIA======================");
            System.out.println("1- Belleza            5- Eventos");
            System.out.println("2- Deportes           6- Mantenimiento y reparacion");
            System.out.println("3- Educativo          7- Produccion y creativos");
            System.out.println("4- Entretenimiento    8- Salud y bienestar");
            System.out.print("¿Que categoria es su servicio? ");
            op=Lector.nextInt();
            switch(op) {
                case 1:
                    tipo="Belleza";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Tipo de servicio: ");
                    tipoBelleza=Lector.nextLine();
                    System.out.print("Material: ");
                    materialBelleza=Lector.nextLine();
                    System.out.print("Lugar del servicio: ");
                    lugarBelleza=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof Belleza) {
                        Belleza actual =(Belleza) servicioactual;
                        actual.modificacionBelleza(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, tipoBelleza, materialBelleza, lugarBelleza);     
                    }
                    break;
                case 2:
                    tipo="Deportes";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Tipo de deporte: ");
                    tipoDeporte=Lector.nextLine();
                    System.out.print("Material: ");
                    materialDeporte=Lector.nextLine();
                    do {
                        System.out.println("=====================DIFICULTAD=====================");
                        System.out.println("1- Principiante");
                        System.out.println("2- Intermedio");
                        System.out.println("3- Avanzado");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        switch(op2) {
                            case 1:
                                nivelDeporte="Principiante";
                                break;
                            case 2:
                                nivelDeporte="Intermedio";
                                break;
                            case 3:
                                nivelDeporte="Avanzado";
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2<1||op2>3);
                    System.out.print("Lugar del servicio: ");
                    lugarDeporte=Lector.nextLine();
                    Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof Deportes) {
                        Deportes actual = (Deportes) servicioactual;
                        actual.modificacionDeportes(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, tipoDeporte, materialDeporte, nivelDeporte, lugarDeporte);
                    }
                    break;
                case 3:
                    tipo="Educativo";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Materia: ");
                    materia=Lector.nextLine();
                    do {
                        System.out.println("=====================DIFICULTAD=====================");
                        System.out.println("1- Principiante");
                        System.out.println("2- Intermedio");
                        System.out.println("3- Avanzado");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        switch(op2) {
                            case 1:
                                nivelEducativo="Principiante";
                                break;
                            case 2:
                                nivelEducativo="Intermedio";
                                break;
                            case 3:
                                nivelEducativo="Avanzado";
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2<1||op2>3);
                    do {
                        System.out.println("=====================MODALIDAD======================");
                        System.out.println("1- Presencial");
                        System.out.println("2- Hibrida");
                        System.out.println("3- En linea");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                modalidad="Presencial";
                                break;
                            case 2:
                                modalidad="Hibrida";
                                break;
                            case 3:
                                modalidad="En linea";
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2<1||op2>3);
                    do {
                        System.out.println("==================NIVEL ACADEMICO===================");
                        System.out.println("1- Preescolar     4- Preparatoria");
                        System.out.println("2- Primaria       5- Pregrado");
                        System.out.println("3- Secundaria     6- Posgrado");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                nivelAcademico="Preescolar";
                                break;
                            case 2:
                                nivelAcademico="Primaria";
                                break;
                            case 3:
                                nivelAcademico="Secundaria";
                                break;
                            case 4:
                                nivelAcademico="Preparatoria";
                                break;
                            case 5:
                                nivelAcademico="Pregrado";
                                break;
                            case 6:
                                nivelAcademico="Posgrado";
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2<1||op2>6);
                    Lector.nextLine();
                    System.out.print("Material: ");
                    materialEducativo=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof Educativo) {
                        Educativo actual = (Educativo) servicioactual;
                        actual.modificacionEducativo(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, materia, nivelEducativo, modalidad, materialEducativo, nivelAcademico);
                    }
                    break;
                case 4:
                    tipo="Entretenimiento";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Servicio: ");
                    tipoShow=Lector.nextLine();
                    System.out.print("Requisitos: ");
                    RequisitosShow=Lector.nextLine();
                    System.out.print("Material: ");
                    materialShow=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof Entretenimiento) {
                        Entretenimiento actual = (Entretenimiento) servicioactual;
                        actual.modificacionShows(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, tipoShow, RequisitosShow, materialShow);
                    }
                    break;
                case 5:
                    tipo="Eventos";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Tipo de evento: ");
                    tipoEvento=Lector.nextLine();
                    System.out.print("Capacidad maxima: ");
                    capacidadEvento=Lector.nextLine();
                    System.out.print("Lugar del evento: ");
                    lugarEvento=Lector.nextLine();
                    System.out.print("Paquetes del evento: ");
                    paquetesEvento=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof Eventos) {
                        Eventos actual = (Eventos) servicioactual;
                        actual.modificacionEventos(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, tipoEvento, capacidadEvento, lugarEvento, paquetesEvento);
                    }
                    break;
                case 6:
                    tipo="Mantenimiento y Reparacion";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Servicio: ");
                    tipomyr=Lector.nextLine();
                    System.out.print("Garantia: ");
                    garantia=Lector.nextLine();
                    System.out.print("Material: ");
                    materialmyr=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof MYR) {
                        MYR actual = (MYR) servicioactual;
                        actual.modificacionMYR(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, tipomyr, garantia, materialmyr);
                    }
                    break;
                case 7:
                    tipo="Produccion y Creativos";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Servicio: ");
                    proyecto=Lector.nextLine();
                    System.out.print("Formato de entrega: ");
                    formato=Lector.nextLine();
                    System.out.print("Requisitos: ");
                    requisitosProdu=Lector.nextLine();
                    System.out.println("=================DERECHOS DE AUTOR==================");
                    do {
                        System.out.println("===================USO COMERCIAL====================");
                        System.out.println("1- Si    2- No");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                usocomercial="Si";
                                break;
                            case 2:
                                usocomercial="No";
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2<1||op2>2);
                    do {
                        System.out.println("=================LICENCIA DE AUTOR==================");
                        System.out.println("1- Derechos reservados");
                        System.out.println("2- Creative commons");
                        System.out.println("3- Dominio publico");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                copyright="Derechos reservados";
                                break;
                            case 2:
                                copyright="Creative commons";
                                break;
                            case 3:
                                copyright="Dominio publico";
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2<1||op2>3);
                    Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof Produccion) {
                        Produccion actual = (Produccion) servicioactual;
                        actual.modificacionProdu(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, proyecto, formato, requisitosProdu, usocomercial, copyright);
                    }
                    break;
                case 8:
                    tipo="Salud y Bienestar";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Servicio: ");
                    tipoSalud=Lector.nextLine();
                    System.out.print("Requisitos: ");
                    requisitosSalud=Lector.nextLine();
                    System.out.print("Lugar del servicio: ");
                    ubicacionSalud=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    if (servicioactual instanceof Salud) {
                        Salud actual = (Salud) servicioactual;
                        actual.modificacionSalud(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, tipoSalud, requisitosSalud, ubicacionSalud);
                    }
                    break;
                default:
                    System.out.println("Opcion invalida");
                    break;
            }
        } while (op<1||op>8);
    }
    //METODO PARA MODIFICAR SERVICIOS
    public static void modificar(Servicios servicioactual) {
        int op, op2;
        Lector.nextLine();
        System.out.print("Nombre del servicio: ");
        nombreServicio=Lector.nextLine();
        System.out.print("Descripcion: ");
        descripcion=Lector.nextLine();
        System.out.print("Precio por hora: ");
        precio=Lector.nextDouble();
        Lector.nextLine();
        servicioactual.modificacion(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
    }
    //METODO PARA CONSULTAR SERVICIOS
    public static void consultadeservicios() {
        int op, op2;
        do {
            System.out.println("===============BUSQUEDA DE SERVICIOS================");
            System.out.println("1- Mostrar todos los servicios disponibles");
            System.out.println("2- Mostrar los servicios por categoria");
            System.out.print("¿Que opcion desea elejir? ");
            op=Lector.nextInt();
            switch(op){
                case 1:
                    System.out.println(Servicios.viewServicios());
                    break;
                case 2:
                    do {
                        System.out.println("===============CATEGORIAS DISPONIBLES===============");
                        System.out.println("1- Belleza            5- Eventos");
                        System.out.println("2- Deportes           6- Mantenimiento y reparacion");
                        System.out.println("3- Educativo          7- Produccion y creativos");
                        System.out.println("4- Entretenimiento    8- Salud y bienestar");
                        System.out.print("¿Que categoria de servicios desea ver? ");
                        op2=Lector.nextInt();
                        System.out.println("===============SERVICIOS DISPONIBLES================");
                        switch(op2){
                            case 1:
                                System.out.println(Belleza.viewBelleza());
                                break;
                            case 2:
                                System.out.println(Deportes.viewDeporte());
                                break;
                            case 3:
                                System.out.println(Educativo.viewEducativo());
                                break;
                            case 4:
                                System.out.println(Entretenimiento.viewShows());
                                break;
                            case 5:
                                System.out.println(Eventos.viewEventos());
                                break;
                            case 6:
                                System.out.println(MYR.viewMYR());
                                break;
                            case 7:
                                System.out.println(Produccion.viewProdu());
                                break;
                            case 8:
                                System.out.println(Salud.viewSalud());
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2<1||op2>8);
                    break;
                default:
                    System.out.println("Opcion invalida");
                    break;
            }
        } while (op<1||op>2);
    }
    //METODO PARA PUBLICAR LAS DIRECCIONES DE UN SERVICIO
    public static void direcciones() {
        System.out.println("======================UBICACION=====================");
        System.out.print("Calle: ");
        calleServicio=Lector.next();
        System.out.print("Numero exterior: ");
        numeroServicio=Lector.next();
        System.out.print("Ciudad: ");
        ciudadServicio=Lector.next();
        System.out.print("Estado: ");
        estadoServicio=Lector.next();
        System.out.print("Codigo postal: ");
        cpServicio=Lector.next();
        System.out.print("Coordenadas: ");
        coordenadas=Lector.next();
    }
    //METODO PARA PUBLICAR LAS RECOMENDACIONES DE UN SERVICIO
    public static void Recomendaciones() {
        int op;
        Lector.nextLine();
        System.out.println("==============RECOMENDACIONES GENERALES=============");
        System.out.print("Recomendaciones: ");
        recomendaciones=Lector.nextLine();
        do {
            System.out.println("================EDAD RECOMENDADA====================");
            System.out.println("1- 0-10      6- 51-60");
            System.out.println("2- 11-20     7- 61-70");
            System.out.println("3- 21-30     8- 71-80");
            System.out.println("4- 31-40     9- 81-90");
            System.out.println("5- 41-50    10- 91-100");
            System.out.print("¿Que opcion desea elejir? ");
            op=Lector.nextInt();
            switch(op) {
                case 1:
                    edad="1-10 años";
                    break;
                case 2:
                    edad="11-20 años";
                    break;
                case 3:
                    edad="21-30 años";
                    break;
                case 4:
                    edad="31-40 años";
                    break;
                case 5:
                    edad="41-50 años";
                    break;
                case 6:
                    edad="51-60 años";
                    break;
                case 7:
                    edad="61-70 años";
                    break;
                case 8:
                    edad="71-80 años";
                    break;
                case 9:
                    edad="81-90 años";
                    break;
                case 10:
                    edad="91-100 años";
                    break;
                default:
                    System.out.println("Opcion invalida");
                    break;
            }
        } while (op<1||op>10);
        do {
            System.out.println("===============HORARIO RECOMENDADO==================");
            System.out.println("1- Mañana");
            System.out.println("2- Mediodia");
            System.out.println("3- Tarde");
            System.out.println("4- Noche");
            System.out.print("¿Que opcion desea elejir? ");
            op=Lector.nextInt();
            switch(op){
                case 1:
                    horario="Mañana";
                    break;
                case 2:
                    horario="Mediodia";
                    break;
                case 3:
                    horario="Tarde";
                    break;
                case 4:
                    horario="Noche";
                    break;
                default:
                    System.out.println("Opcion invalida");
                    break;
            }
        } while (op<1||op>4);
    }
    
    //METODO PARA PUBLICAR UN SERVICIO
    public static void publicarservicio() {
        int op, op2;
        Lector.nextLine();
        System.out.print("Nombre del servicio: ");
        nombreServicio=Lector.nextLine();
        System.out.print("Descripcion: ");
        descripcion=Lector.nextLine();
        System.out.print("Precio por hora: ");
        precio=Lector.nextDouble();
        Lector.nextLine();
        do {
            System.out.println("=====================CATEGORIA======================");
            System.out.println("1- Belleza            5- Eventos");
            System.out.println("2- Deportes           6- Mantenimiento y reparacion");
            System.out.println("3- Educativo          7- Produccion y creativos");
            System.out.println("4- Entretenimiento    8- Salud y bienestar");
            System.out.print("¿Que categoria es su servicio? ");
            op=Lector.nextInt();
            switch(op) {
                case 1:
                    tipo="Belleza";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Tipo de servicio: ");
                    tipoBelleza=Lector.nextLine();
                    System.out.print("Material: ");
                    materialBelleza=Lector.nextLine();
                    System.out.print("Lugar del servicio: ");
                    lugarBelleza=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    Belleza service1 = new Belleza(tipoBelleza, materialBelleza, lugarBelleza, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    Belleza.aggBelleza(service1);
                    Servicios.generales.add(service1);
                    useractual.getPublicados().add(service1);
                    System.out.println("====================================================");
                    System.out.println("           ¡Servicio agregado con exito!");
                    break;
                case 2:
                    tipo="Deportes";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Tipo de deporte: ");
                    tipoDeporte=Lector.nextLine();
                    System.out.print("Material: ");
                    materialDeporte=Lector.nextLine();
                    do {
                        System.out.println("=====================DIFICULTAD=====================");
                        System.out.println("1- Principiante");
                        System.out.println("2- Intermedio");
                        System.out.println("3- Avanzado");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        switch(op2) {
                            case 1:
                                nivelDeporte="Principiante";
                                break;
                            case 2:
                                nivelDeporte="Intermedio";
                                break;
                            case 3:
                                nivelDeporte="Avanzado";
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2<1||op2>3);
                    System.out.print("Lugar del servicio: ");
                    lugarDeporte=Lector.nextLine();
                    Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    Deportes service2 = new Deportes(tipoDeporte, materialDeporte, nivelDeporte, lugarDeporte, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    Deportes.aggDeportes(service2);
                    Servicios.generales.add(service2);
                    useractual.getPublicados().add(service2);
                    System.out.println("====================================================");
                    System.out.println("           ¡Servicio agregado con exito!");
                    break;
                case 3:
                    tipo="Educativo";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Materia: ");
                    materia=Lector.nextLine();
                    do {
                        System.out.println("=====================DIFICULTAD=====================");
                        System.out.println("1- Principiante");
                        System.out.println("2- Intermedio");
                        System.out.println("3- Avanzado");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        switch(op2) {
                            case 1:
                                nivelEducativo="Principiante";
                                break;
                            case 2:
                                nivelEducativo="Intermedio";
                                break;
                            case 3:
                                nivelEducativo="Avanzado";
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2<1||op2>3);
                    do {
                        System.out.println("=====================MODALIDAD======================");
                        System.out.println("1- Presencial");
                        System.out.println("2- Hibrida");
                        System.out.println("3- En linea");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                modalidad="Presencial";
                                break;
                            case 2:
                                modalidad="Hibrida";
                                break;
                            case 3:
                                modalidad="En linea";
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2<1||op2>3);
                    do {
                        System.out.println("==================NIVEL ACADEMICO===================");
                        System.out.println("1- Preescolar     4- Preparatoria");
                        System.out.println("2- Primaria       5- Pregrado");
                        System.out.println("3- Secundaria     6- Posgrado");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                nivelAcademico="Preescolar";
                                break;
                            case 2:
                                nivelAcademico="Primaria";
                                break;
                            case 3:
                                nivelAcademico="Secundaria";
                                break;
                            case 4:
                                nivelAcademico="Preparatoria";
                                break;
                            case 5:
                                nivelAcademico="Pregrado";
                                break;
                            case 6:
                                nivelAcademico="Posgrado";
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2<1||op2>6);
                    Lector.nextLine();
                    System.out.print("Material: ");
                    materialEducativo=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    Educativo service3 = new Educativo(materia, nivelEducativo, modalidad, materialEducativo, nivelAcademico, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    Educativo.aggEducativos(service3);
                    Servicios.generales.add(service3);
                    useractual.getPublicados().add(service3);
                    System.out.println("====================================================");
                    System.out.println("           ¡Servicio agregado con exito!");
                    break;
                case 4:
                    tipo="Entretenimiento";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Servicio: ");
                    tipoShow=Lector.nextLine();
                    System.out.print("Requisitos: ");
                    RequisitosShow=Lector.nextLine();
                    System.out.print("Material: ");
                    materialShow=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    Entretenimiento service4 = new Entretenimiento(tipoShow, RequisitosShow, materialShow, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    Entretenimiento.aggShows(service4);
                    Servicios.generales.add(service4);
                    useractual.getPublicados().add(service4);
                    System.out.println("====================================================");
                    System.out.println("           ¡Servicio agregado con exito!");
                    break;
                case 5:
                    tipo="Eventos";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Tipo de evento: ");
                    tipoEvento=Lector.nextLine();
                    System.out.print("Capacidad maxima: ");
                    capacidadEvento=Lector.nextLine();
                    System.out.print("Lugar del evento: ");
                    lugarEvento=Lector.nextLine();
                    System.out.print("Paquetes del evento: ");
                    paquetesEvento=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    Eventos service5 = new Eventos(tipoEvento, capacidadEvento, lugarEvento, paquetesEvento, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    Eventos.aggEventos(service5);
                    Servicios.generales.add(service5);
                    useractual.getPublicados().add(service5);
                    System.out.println("====================================================");
                    System.out.println("           ¡Servicio agregado con exito!");
                    break;
                case 6:
                    tipo="Mantenimiento y Reparacion";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Servicio: ");
                    tipomyr=Lector.nextLine();
                    System.out.print("Garantia: ");
                    garantia=Lector.nextLine();
                    System.out.print("Material: ");
                    materialmyr=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    MYR service6 = new MYR(tipomyr, garantia, materialmyr, precio, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    MYR.aggMyr(service6);
                    Servicios.generales.add(service6);
                    useractual.getPublicados().add(service6);
                    System.out.println("====================================================");
                    System.out.println("           ¡Servicio agregado con exito!");
                    break;
                case 7:
                    tipo="Produccion y Creativos";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Servicio: ");
                    proyecto=Lector.nextLine();
                    System.out.print("Formato de entrega: ");
                    formato=Lector.nextLine();
                    System.out.print("Requisitos: ");
                    requisitosProdu=Lector.nextLine();
                    System.out.println("=================DERECHOS DE AUTOR==================");
                    do {
                        System.out.println("===================USO COMERCIAL====================");
                        System.out.println("1- Si    2- No");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                usocomercial="Si";
                                break;
                            case 2:
                                usocomercial="No";
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2<1||op2>2);
                    do {
                        System.out.println("=================LICENCIA DE AUTOR==================");
                        System.out.println("1- Derechos reservados");
                        System.out.println("2- Creative commons");
                        System.out.println("3- Dominio publico");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        switch(op2){
                            case 1:
                                copyright="Derechos reservados";
                                break;
                            case 2:
                                copyright="Creative commons";
                                break;
                            case 3:
                                copyright="Dominio publico";
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2<1||op2>3);
                    Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    Produccion service7 = new Produccion(proyecto, formato, requisitosProdu, usocomercial, copyright, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    Produccion.aggProducciones(service7);
                    Servicios.generales.add(service7);
                    useractual.getPublicados().add(service7);
                    System.out.println("====================================================");
                    System.out.println("           ¡Servicio agregado con exito!");
                    break;
                case 8:
                    tipo="Salud y Bienestar";
                    Lector.nextLine();
                    System.out.println("===============INFORMACION ADICIONAL================");
                    System.out.print("Servicio: ");
                    tipoSalud=Lector.nextLine();
                    System.out.print("Requisitos: ");
                    requisitosSalud=Lector.nextLine();
                    System.out.print("Lugar del servicio: ");
                    ubicacionSalud=Lector.nextLine();
                    direcciones();
                    Recomendaciones();
                    Salud service8 = new Salud(tipoSalud, requisitosSalud, ubicacionSalud, nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
                    Salud.aggSalud(service8);
                    Servicios.generales.add(service8);
                    useractual.getPublicados().add(service8);
                    System.out.println("====================================================");
                    System.out.println("           ¡Servicio agregado con exito!");
                    break;
                default:
                    System.out.println("Opcion invalida");
                    break;
            }
        } while (op<1||op>8);
    }
    //MENU USUARIO
    public static void menuUsuario() {
        int op, op2, op3;
        do {
            System.out.println("========================MENU========================");
            System.out.println("1- Publicar un servicio");
            System.out.println("2- Comprar un servicio");
            System.out.println("3- Carrito de compras");
            System.out.println("4- Monedero electronico");
            System.out.println("5- Informacion de la cuenta");
            System.out.println("6- Cerrar sesion");
            System.out.print("¿Que opcion desea elegir? ");
            op=Lector.nextInt();
            System.out.println("====================================================");
            switch(op) {
                case 1:
                    publicarservicio();
                    break;
                case 2://COMPRAR SERVICIOS O AGREGARLOS AL CARRITO
                    System.out.println("===============BUSQUEDA DE SERVICIOS================");
                    System.out.println("1- Belleza            5- Eventos");
                    System.out.println("2- Deportes           6- Mantenimiento y reparacion");
                    System.out.println("3- Educativo          7- Produccion y creativos");
                    System.out.println("4- Entretenimiento    8- Salud y bienestar");
                    System.out.print("¿En que categoria desea comprar? ");
                    op2=Lector.nextInt();
                    System.out.println("====================================================");
                    switch(op2) {
                        case 1:
                            System.out.println(Belleza.viewBelleza());
                            if (Belleza.viewBelleza().contains("No hay servicios registrados")) {
                                System.out.println("====================================================");
                            } else {
                                System.out.print("¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual=Belleza.getBellezas().get(op3);
                                System.out.println(Belleza.getBellezas().get(op3).InfoBelleza());
                                System.out.println(servicioactual.InfoReseñas());
                                //AQUI MOSTRAREMOS LAS RESEÑAS DE CADA SERVICIO
                                System.out.println("====================================================");
                                System.out.println("1- Agregar al carrito");
                                System.out.println("2- Comprar ahora");
                                System.out.print("¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("====================================================");
                                switch(op4) {
                                    case 1://AGREGAR AL CARRITO
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine(); 
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita);
                                            System.out.println("====================================================");
                                            System.out.println("      ¡SERVICIO AGREGADO AL CARRITO CON EXITO!");
                                            
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora inválidas");
                                        }
                                        break;
                                    case 2://COMPRAR AHORA
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
                                            Citas cita = new Citas(servicioactual, fechahora, horas);
                                            double total=cita.getSubtotal();
                                            String compra=useractual.comprar(total, cita);
                                            System.out.println("====================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita);
                                            }
                                        }catch (Exception e) {
                                            System.out.println("Fecha y hora inválidas");
                                        }
                                        break;
                                    default:
                                        System.out.println("Opcion invalida");
                                        break;
                                }
                            }
                            break;
                        case 2:
                            System.out.println(Deportes.viewDeporte());
                            if (Deportes.viewDeporte().contains("No hay servicios registrados")) {
                                System.out.println("====================================================");
                            } else {
                                System.out.print("¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual=Deportes.getDeportes().get(op3);
                                System.out.println(Deportes.getDeportes().get(op3).InfoDeportes());
                                System.out.println(servicioactual.InfoReseñas());
                                 System.out.println("====================================================");
                                System.out.println("1- Agregar al carrito");
                                System.out.println("2- Comprar ahora");
                                System.out.print("¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("====================================================");
                                switch(op4) {
                                    case 1:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine(); 
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita2 = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita2);
                                            System.out.println("====================================================");
                                            System.out.println("      ¡SERVICIO AGREGADO AL CARRITO CON EXITO!");
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora invalidas");
                                        }
                                        break;
                                    case 2:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            Citas cita2 = new Citas(servicioactual, fechahora, horas);
                                            double total=cita2.getSubtotal();
                                            String compra=useractual.comprar(total, cita2);
                                            System.out.println("====================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita2);
                                            }
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora invalidas");
                                        }
                                        break;
                                    default:
                                        System.out.println("Opcion invalida");
                                        break;
                                }
                            }
                            break;
                        case 3:
                            System.out.println(Educativo.viewEducativo());
                            if (Educativo.viewEducativo().contains("No hay servicios registrados")) {
                                System.out.println("====================================================");
                            } else {
                                System.out.print("¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual=Educativo.getEducativos().get(op3);
                                System.out.println(Educativo.getEducativos().get(op3).InfoEducacion());
                                System.out.println(servicioactual.InfoReseñas());
                                System.out.println("====================================================");
                                System.out.println("1- Agregar al carrito");
                                System.out.println("2- Comprar ahora");
                                System.out.print("¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("====================================================");
                                switch(op4) {
                                    case 1:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine();
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine(); 
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita3 = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita3);
                                            System.out.println("====================================================");
                                            System.out.println("      ¡SERVICIO AGREGADO AL CARRITO CON EXITO!");
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora invalidas");
                                        }
                                        break;
                                    case 2:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
                                            Citas cita3 = new Citas(servicioactual, fechahora, horas);
                                            double total=cita3.getSubtotal();
                                            String compra=useractual.comprar(total, cita3);
                                            System.out.println("====================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita3);
                                            }
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora invalidas");
                                        }
                                        break;
                                    default:
                                        System.out.println("Opcion invalida");
                                        break;
                                }
                            }
                            break;
                        case 4:
                            System.out.println(Entretenimiento.viewShows());
                            if (Entretenimiento.viewShows().contains("No hay servicios registrados")) {
                                System.out.println("====================================================");
                            } else {
                                System.out.print("¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual=Entretenimiento.getShows().get(op3);
                                System.out.println(Entretenimiento.getShows().get(op3).InfoShows());
                                System.out.println(servicioactual.InfoReseñas());
                                System.out.println("====================================================");
                                System.out.println("1- Agregar al carrito");
                                System.out.println("2- Comprar ahora");
                                System.out.print("¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("====================================================");
                                switch(op4) {
                                    case 1:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita4 = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita4);
                                            System.out.println("====================================================");
                                            System.out.println("      ¡SERVICIO AGREGADO AL CARRITO CON EXITO!");
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora invalidas");
                                        }
                                        break;
                                    case 2:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
                                            Citas cita4 = new Citas(servicioactual, fechahora, horas);
                                            double total=cita4.getSubtotal();
                                            String compra = useractual.comprar(total, cita4);
                                            System.out.println("====================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita4);
                                            }
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora invalidas");
                                        }
                                        break;
                                    default:
                                        System.out.println("Opcion invalida");
                                        break;
                                }
                            }
                            break;
                        case 5:
                            System.out.println(Eventos.viewEventos());
                            if (Eventos.viewEventos().contains("No hay servicios registrados")) {
                                System.out.println("====================================================");
                            } else {
                                System.out.print("¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual=Eventos.getEventos().get(op3);
                                System.out.println(Eventos.getEventos().get(op3).InfoEventos());
                                System.out.println(servicioactual.InfoReseñas());
                                System.out.println("====================================================");
                                System.out.println("1- Agregar al carrito");
                                System.out.println("2- Comprar ahora");
                                System.out.print("¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("====================================================");
                                switch(op4) {
                                    case 1:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita5 = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita5);
                                            System.out.println("====================================================");
                                            System.out.println("      ¡SERVICIO AGREGADO AL CARRITO CON EXITO!");
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora invalidas");
                                        }
                                        break;
                                    case 2:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
                                            Citas cita5 = new Citas(servicioactual, fechahora, horas);
                                            double total=cita5.getSubtotal();
                                            String compra=useractual.comprar(total, cita5);
                                            System.out.println("====================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita5);
                                            }
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora invalidas");
                                        }
                                        break;
                                    default:
                                        System.out.println("Opcion invalida");
                                        break;
                                }
                            }
                            break;
                        case 6:
                            System.out.println(MYR.viewMYR());
                            if (MYR.viewMYR().contains("No hay servicios registrados")) {
                                System.out.println("====================================================");
                            } else {
                                System.out.print("¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual = MYR.getMyr().get(op3);
                                System.out.println(MYR.getMyr().get(op3).InfoMYR());
                                System.out.println(servicioactual.InfoReseñas());
                                System.out.println("====================================================");
                                System.out.println("1- Agregar al carrito");
                                System.out.println("2- Comprar ahora");
                                System.out.print("¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("====================================================");
                                switch(op4) {
                                    case 1:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita6 = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita6);
                                            System.out.println("====================================================");
                                            System.out.println("      ¡SERVICIO AGREGADO AL CARRITO CON EXITO!");
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora invalidas");
                                        }
                                        break;
                                    case 2:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
                                            Citas cita6 = new Citas(servicioactual, fechahora, horas);
                                            double total=cita6.getSubtotal();
                                            String compra=useractual.comprar(monto, cita6);
                                            System.out.println("====================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita6);
                                            }
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora invalidas");
                                        }
                                        break;
                                    default:
                                        System.out.println("Opcion invalida");
                                        break;
                                }
                            }
                            break;
                        case 7:
                            System.out.println(Produccion.viewProdu());
                            if (Produccion.viewProdu().contains("No hay servicios registrados")) {
                                System.out.println("====================================================");
                            } else {
                                System.out.print("¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual=Produccion.getProducciones().get(op3);
                                System.out.println(Produccion.getProducciones().get(op3).InfoProduccion());
                                System.out.println(servicioactual.InfoReseñas());
                                System.out.println("====================================================");
                                System.out.println("1- Agregar al carrito");
                                System.out.println("2- Comprar ahora");
                                System.out.print("¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("====================================================");
                                switch(op4) {
                                    case 1:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita7 = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita7);
                                            System.out.println("====================================================");
                                            System.out.println("      ¡SERVICIO AGREGADO AL CARRITO CON EXITO!");
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora invalidas");
                                        }
                                        break;
                                    case 2:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
                                            Citas cita7 = new Citas(servicioactual, fechahora, horas);
                                            double total=cita7.getSubtotal();
                                            String compra = useractual.comprar(total, cita7);
                                            System.out.println("====================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita7);
                                            }
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora invalidas");
                                        }
                                        break;
                                    default:
                                        System.out.println("Opcion invalida");
                                        break;
                                }
                            }
                            break;
                        case 8:
                            System.out.println(Salud.viewSalud());
                            if (Salud.viewSalud().contains("No hay servicios registrados")) {
                                System.out.println("====================================================");
                            } else {
                                System.out.print("¿Que servicio desea comprar? ");
                                op3 = Lector.nextInt() - 1;
                                servicioactual=Salud.getSalud().get(op3);
                                System.out.println(Salud.getSalud().get(op3).InfoSalud());
                                System.out.println(servicioactual.InfoReseñas());
                                System.out.println("====================================================");
                                System.out.println("1- Agregar al carrito");
                                System.out.println("2- Comprar ahora");
                                System.out.print("¿Que opcion desea elegir? ");
                                int op4=Lector.nextInt();
                                System.out.println("====================================================");
                                switch(op4) {
                                    case 1:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        int horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        String fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern(
                                                "dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES")
                                            );
                                            String reservacion = fechahora.format(formato);
                                            Citas cita8 = new Citas(servicioactual, fechahora, horas);
                                            useractual.getCarritos().aggcita(cita8);
                                            System.out.println("====================================================");
                                            System.out.println("      ¡SERVICIO AGREGADO AL CARRITO CON EXITO!");
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora invalida");
                                        }
                                        break;
                                    case 2:
                                        System.out.print("¿Cuántas horas desea contratar? ");
                                        horas = Lector.nextInt();
                                        Lector.nextLine(); 
                                        System.out.print("Ingrese la fecha y hora de la cita (YYYY-MM-dd HH:mm): ");
                                        fechahora2 = Lector.nextLine();
                                        try {
                                            LocalDateTime fechahora = LocalDateTime.parse(fechahora2.replace(" ", "T"));
                                            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
                                            Citas cita8 = new Citas(servicioactual, fechahora, horas);
                                            double total=cita8.getSubtotal();
                                            String compra=useractual.comprar(total, cita8);
                                            System.out.println("====================================================");
                                            System.out.println(compra);
                                            if (compra.contains("¡COMPRA EXITOSA!")) {
                                                useractual.getComprados().add(cita8);
                                            }
                                        } catch (Exception e) {
                                            System.out.println("Fecha y hora invalidas");
                                        }
                                        break;
                                    default:
                                        System.out.println("Opcion invalida");
                                        break;
                                }
                            }
                            break;
                        default:
                            System.out.println("Opcion invalida");
                            break;
                    }
                    break;
                case 3:
                    System.out.println("====================================================");
                    System.out.println(useractual.getCarritos().viewcarrito());
                    System.out.println("====================================================");
                    if (useractual.getCarritos().viewcarrito().contains("¡EL CARRITO ESTA VACIO!")) {
                        
                    } else {
                        System.out.print("¿Desea proceder al pago del carrito? 1- Si 2- No ");
                        int op4=Lector.nextInt();
                        if (op4==1) {
                            System.out.println(useractual.getCarritos().pagarcarrito(useractual));
                        }
                    }
                    break;
                case 4:
                    do {
                        System.out.println("================MONEDERO ELECTRONICO================");
                        System.out.println("1- Consultar saldo");
                        System.out.println("2- Agregar saldo");
                        System.out.println("3- Volver al menu principal");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        System.out.println("====================================================");
                        switch (op2) {
                            case 1:
                                System.out.println(useractual.consultaSaldo());
                                break;
                            case 2:
                                System.out.print("¿Cuanto desea agregar? ");
                                monto=Lector.nextDouble();
                                useractual.aggSaldo(monto);
                                System.out.println("====================================================");
                                System.out.println("           ¡DEPOSITO REALIZADO CON EXITO!");
                                System.out.println("====================================================");
                                System.out.println(useractual.consultaSaldo());
                                break;
                            case 3:
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2!=3);
                    break;
                case 5:
                    do {
                        System.out.println("==============INFORMACION DE LA CUENTA==============");
                        System.out.println("1- Mis servicios");
                        System.out.println("2- Datos personales");
                        System.out.println("3- Volver al menu principal");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        System.out.println("====================================================");
                        switch(op2) {
                            case 1:
                                do {
                                    System.out.println("===================MIS SERVICIOS====================");
                                    System.out.println("1- Servicios publicados");
                                    System.out.println("2- Servicios comprados");
                                    System.out.println("3- Reseñas");
                                    System.out.println("4- Volver");
                                    System.out.print("¿Que opcion desea elegir? ");
                                    op3=Lector.nextInt();
                                    System.out.println("====================================================");
                                    switch(op3) {
                                        case 1:
                                            System.out.println("===============SERVICIOS PUBLICADOS=================");
                                            System.out.println(useractual.viewPublicados());
                                            break;
                                        case 2:
                                            System.out.println("================SERVICIOS COMPRADOS=================");
                                            System.out.println(useractual.viewComprados());
                                            break;
                                        case 3:
                                            System.out.println("=====================RESEÑAS========================");
                                            System.out.println("1- Escribir reseñas");
                                            System.out.println("2- Mostrar mis reseñas escritas");
                                            System.out.print("¿Que opcion desea elegir? ");
                                            int op4=Lector.nextInt();
                                            System.out.println("====================================================");
                                            switch(op4) {
                                                case 1:
                                                    System.out.println("================SERVICIOS COMPRADOS=================");
                                                    System.out.println(useractual.viewComprados());
                                                    System.out.print("¿En que servicio desea escribir una reseña? ");
                                                    int op5=Lector.nextInt()-1;
                                                    Citas cita = useractual.getComprados().get(op5);
                                                    Servicios service = cita.getServicio();
                                                    usuarioR=useractual.nombrecompleto();
                                                    correoR=useractual.getCorreo();
                                                    System.out.print("Calificacion: ");
                                                    calificacion = Lector.nextDouble();
                                                    Lector.nextLine();
                                                    System.out.print("Escribe tu reseña: ");
                                                    comentarios=Lector.nextLine();
                                                    DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy HH:mm", new Locale("es", "ES"));
                                                    fechareseña = LocalDateTime.now().format(formato);
                                                    Reseñas nuevas = new Reseñas(usuarioR, correoR, comentarios, calificacion, fechareseña);
                                                    servicioactual.getReseñas().add(nuevas);
                                                    useractual.aggReseña(nuevas);
                                                    System.out.println("====================================================");
                                                    System.out.println("                ¡RESEÑA PUBLICADA!");
                                                    break;
                                                case 2:
                                                    System.out.println("===============MIS RESEÑAS ESCRITAS=================");
                                                    System.out.println(useractual.viewReseñas());
                                                    break;
                                                default:
                                                    System.out.println("Opcion invalida");
                                                    break;
                                            }
                                            break;
                                        case 4:
                                            break;
                                        default:
                                            System.out.println("Opcion invalida");
                                            break;
                                    }
                                } while (op3!=4);
                                break;
                            case 2:
                                do {
                                    System.out.println("==================DATOS PERSONALES==================");
                                    System.out.println("1- Informacion actual");
                                    System.out.println("2- Editar informacion");
                                    System.out.println("3- Volver ");
                                    System.out.print("¿Que opcion desea elegir? ");
                                    op3=Lector.nextInt();
                                    System.out.println("====================================================");
                                    switch(op3) {
                                        case 1:
                                            Usuario.getUsuarios();
                                            Usuario obj5 = Usuario.getUsuarios().get(i);
                                            System.out.println(obj5.InfoAllUsuario());  
                                            break;
                                        case 2:
                                            int op0;
                                            String contra;
                                            System.out.print("Nombre: ");
                                            nombre=Lector.next();
                                            System.out.print("Apellido paterno: ");
                                            app=Lector.next();
                                            System.out.print("Apellido materno: ");
                                            apm=Lector.next();
                                            System.out.print("Telefono de contacto: ");
                                            telefono=Lector.next();
                                            System.out.print("Calle: ");
                                            calle=Lector.next();
                                            System.out.print("Numero exterior: ");
                                            numero=Lector.next();
                                            System.out.print("Ciudad: ");
                                            ciudad=Lector.next();
                                            System.out.print("Estado: ");
                                            estado=Lector.next();
                                            System.out.print("Codigo postal: ");
                                            cp=Lector.next();
                                            System.out.println("=================CAMBIAR CONTRASEÑA=================");
                                            System.out.println("1- Si    2- No");
                                            System.out.print("¿Desea cambiar la contraseña? ");
                                            op0=Lector.nextInt();
                                            switch (op0) {
                                                case 1:
                                                    do {
                                                        System.out.print("Ingrese la contraseña actual: ");
                                                        contra=Lector.next();
                                                        if (!Usuario.getUsuarios().get(i).getContraseña().equals(contra)) {
                                                            System.out.println("Contraseña incorrecta");
                                                        }
                                                    } while (!Usuario.getUsuarios().get(i).getContraseña().equals(contra));
                                                    System.out.print("Ingrese la nueva contraseña: ");
                                                    contraseña=Lector.next();
                                                    break;
                                                case 2:
                                                    break;
                                                default:
                                                    System.out.println("Opcion invalida");
                                                    break;
                                            }
                                            Usuario obj10 = Usuario.getUsuarios().get(i);
                                            obj10.InfoUser(nombre, app, apm, telefono, contraseña, calle, numero, ciudad, estado, cp);
                                            System.out.println("====================================================");
                                            System.out.println(obj10.InfoAllUsuario());
                                            break;
                                        case 3:
                                            break;
                                        default:
                                            System.out.println("Opcion invalida");
                                            break;
                                    }
                                } while (op3!=3);
                                break;
                            case 3:
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2!=3);
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Opcion invalida");
                    break;
            }
        } while (true);
    }
    
    //MENU ADMINISTRADOR
    public static void menuAdmin() {
        int op, op2, op3, op4, op5;
        do {
            System.out.println("========================MENU========================");
            System.out.println("1- Administrar servicios");
            System.out.println("2- Administrar usuarios");
            System.out.println("3- Administrar reportes");
            System.out.println("4- Informacion de la cuenta");
            System.out.println("5- Monedero electronico");
            System.out.println("6- Cerrar sesion");
            System.out.print("¿Que opcion desea elejir? ");
            op=Lector.nextInt();
            System.out.println("====================================================");
            switch(op) {
                case 1:
                    do {
                        System.out.println("=============ADMINISTRACION DE SERVICIOS============");
                        System.out.println("1- Alta de servicios");
                        System.out.println("2- Baja de servicios");
                        System.out.println("3- Edicion de servicios");
                        System.out.println("4- Consulta de servicios");
                        System.out.println("5- Volver al menu principal");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        System.out.println("====================================================");
                        switch(op2){
                            case 1:
                                publicarservicio();
                                break;
                            case 2:
                                do {
                                    System.out.println("===============BUSQUEDA DE SERVICIOS================");
                                    System.out.println("1- Mostrar todos los servicios disponibles");
                                    System.out.println("2- Mostrar los servicios por categoria");
                                    System.out.print("¿Que opcion desea elejir? ");
                                    op3=Lector.nextInt();
                                    switch(op3) {
                                        case 1:
                                            System.out.println(Servicios.viewServicios());
                                            if (Servicios.viewServicios().contains("No hay servicios registrados")) {
                                                System.out.println("====================================================");
                                                System.out.println("No hay servicios para eliminar");
                                            }
                                            else {
                                                System.out.print("¿Que servicio desea eliminar? ");
                                                op4=Lector.nextInt();
                                                Servicios deleted = Servicios.getServiciosGenerales().get(op4-1);
                                                Servicios.deleteservice(deleted);
                                                System.out.println("====================================================");
                                                System.out.println("¡Servicio eliminado con exito!");
                                            }
                                            break;
                                        case 2:
                                            do {
                                                System.out.println("===============CATEGORIAS DISPONIBLES===============");
                                                System.out.println("1- Belleza            5- Eventos");
                                                System.out.println("2- Deportes           6- Mantenimiento y reparacion");
                                                System.out.println("3- Educativo          7- Produccion y creativos");
                                                System.out.println("4- Entretenimiento    8- Salud y bienestar");
                                                System.out.print("¿Que categoria de servicios desea ver? ");
                                                op4=Lector.nextInt();
                                                System.out.println("===============SERVICIOS DISPONIBLES================");
                                                switch(op4){
                                                    case 1:
                                                        System.out.println(Belleza.viewBelleza());
                                                        if (Belleza.viewBelleza().contains("No hay servicios registrados")) {
                                                            System.out.println("====================================================");
                                                            System.out.println("No hay servicios para eliminar");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            Belleza deleted = Belleza.getBellezas().get(op5-1);
                                                            Belleza.deleteservice(deleted);
                                                            System.out.println("====================================================");
                                                            System.out.println("¡Servicio eliminado con exito!");
                                                        }
                                                        break;
                                                    case 2:
                                                        System.out.println(Deportes.viewDeporte());
                                                        if (Deportes.viewDeporte().contains("No hay servicios registrados")) {
                                                            System.out.println("====================================================");
                                                            System.out.println("No hay servicios para eliminar");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            Deportes deleted = Deportes.getDeportes().get(op5-1);
                                                            Deportes.deleteservice(deleted);
                                                            System.out.println("====================================================");
                                                            System.out.println("¡Servicio eliminado con exito!");
                                                        }
                                                        break;
                                                    case 3:
                                                        System.out.println(Educativo.viewEducativo());
                                                        if (Educativo.viewEducativo().contains("No hay servicios registrados")) {
                                                            System.out.println("====================================================");
                                                            System.out.println("No hay servicios para eliminar");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            Educativo deleted = Educativo.getEducativos().get(op5-1);
                                                            Educativo.deleteservice(deleted);
                                                            System.out.println("====================================================");
                                                            System.out.println("¡Servicio eliminado con exito!");
                                                        }
                                                        break;
                                                    case 4:
                                                        System.out.println(Entretenimiento.viewShows());
                                                        if (Entretenimiento.viewShows().contains("No hay servicios registrados")) {
                                                            System.out.println("====================================================");
                                                            System.out.println("No hay servicios para eliminar");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            Entretenimiento deleted = Entretenimiento.getShows().get(op5-1);
                                                            Entretenimiento.deleteservice(deleted);
                                                            System.out.println("====================================================");
                                                            System.out.println("¡Servicio eliminado con exito!");
                                                        }
                                                        break;
                                                    case 5:
                                                        System.out.println(Eventos.viewEventos());
                                                        if (Eventos.viewEventos().contains("No hay servicios registrados")) {
                                                            System.out.println("====================================================");
                                                            System.out.println("No hay servicios para eliminar");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            Eventos deleted = Eventos.getEventos().get(op5-1);
                                                            Eventos.deleteservice(deleted);
                                                            System.out.println("====================================================");
                                                            System.out.println("¡Servicio eliminado con exito!");
                                                        }
                                                        break;
                                                    case 6:
                                                        System.out.println(MYR.viewMYR());
                                                        if (MYR.viewMYR().contains("No hay servicios registrados")) {
                                                            System.out.println("====================================================");
                                                            System.out.println("No hay servicios para eliminar");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            MYR deleted = MYR.getMyr().get(op5-1);
                                                            MYR.deleteservice(deleted);
                                                            System.out.println("====================================================");
                                                            System.out.println("¡Servicio eliminado con exito!");
                                                        }
                                                        break;
                                                    case 7:
                                                        System.out.println(Produccion.viewProdu());
                                                        if (Produccion.viewProdu().contains("No hay servicios registrados")) {
                                                            System.out.println("====================================================");
                                                            System.out.println("No hay servicios para eliminar");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            Produccion deleted = Produccion.getProducciones().get(op5-1);
                                                            Produccion.deleteservice(deleted);
                                                            System.out.println("====================================================");
                                                            System.out.println("¡Servicio eliminado con exito!");
                                                        }
                                                        break;
                                                    case 8:
                                                        System.out.println(Salud.viewSalud());
                                                        if (Salud.viewSalud().contains("No hay servicios registrados")) {
                                                            System.out.println("====================================================");
                                                            System.out.println("No hay servicios para eliminar");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea eliminar? ");
                                                            op5=Lector.nextInt();
                                                            Salud deleted = Salud.getSalud().get(op5-1);
                                                            Salud.deleteservice(deleted);
                                                            System.out.println("====================================================");
                                                            System.out.println("¡Servicio eliminado con exito!");
                                                        }
                                                        break;
                                                    default:
                                                        System.out.println("Opcion invalida");
                                                        break;
                                                }
                                            } while (op4<1||op4>8);
                                            break;
                                        default:
                                            System.out.println("Opcion invalida");
                                            break;
                                    }
                                } while (op3<1&&op3>2);
                                break;
                            case 3://MODIFICAR SERVICIOS
                                do {
                                    System.out.println("===============BUSQUEDA DE SERVICIOS================");
                                    System.out.println("1- Mostrar todos los servicios disponibles");
                                    System.out.println("2- Mostrar los servicios por categoria");
                                    System.out.print("¿Que opcion desea elejir? ");
                                    op3=Lector.nextInt();
                                    System.out.println("====================================================");
                                    switch(op3){
                                        case 1:
                                            System.out.println(Servicios.viewServicios());
                                            if (Servicios.viewServicios().contains("No hay servicios registrados")) {
                                                System.out.println("====================================================");
                                            }
                                            else {
                                                System.out.print("¿Que servicio desea elejir? ");
                                                op4=Lector.nextInt()-1;
                                                do {
                                                    System.out.println("========ADMINISTRAR INFORMACION DEL SERVICIO========");
                                                    System.out.println("1- Mostrar informacion actual");
                                                    System.out.println("2- Editar informacion");
                                                    System.out.print("¿Que opcion desea elejir? ");
                                                    op5=Lector.nextInt();
                                                    switch (op5) {
                                                        case 1:
                                                            System.out.println(Servicios.getServiciosGenerales().get(op4).InfoAll());
                                                            break;
                                                        case 2://MODIFICAR SERVICIOS
                                                            servicioactual=Servicios.getServiciosGenerales().get(op4);
                                                            modificar(servicioactual);
                                                            categorias(servicioactual);
                                                            System.out.println(servicioactual.InfoAll());
                                                            break;
                                                        default:
                                                            System.out.println("Opcion invalida");
                                                            break;
                                                    }
                                                } while (op5<1||op5>2);
                                            }
                                            break;
                                        case 2:
                                             do {
                                                System.out.println("===============CATEGORIAS DISPONIBLES===============");
                                                System.out.println("1- Belleza            5- Eventos");
                                                System.out.println("2- Deportes           6- Mantenimiento y reparacion");
                                                System.out.println("3- Educativo          7- Produccion y creativos");
                                                System.out.println("4- Entretenimiento    8- Salud y bienestar");
                                                System.out.print("¿Que categoria de servicios desea ver? ");
                                                op2=Lector.nextInt();
                                                System.out.println("===============SERVICIOS DISPONIBLES================");
                                                switch(op2){
                                                    case 1:
                                                        System.out.println(Belleza.viewBelleza());
                                                        if (Belleza.viewBelleza().contains("No hay servicios registrados")) {
                                                        System.out.println("====================================================");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea elejir? ");
                                                            op4=Lector.nextInt()-1;
                                                            do {
                                                                System.out.println("========ADMINISTRAR INFORMACION DEL SERVICIO========");
                                                                System.out.println("1- Mostrar informacion actual");
                                                                System.out.println("2- Editar informacion");
                                                                System.out.print("¿Que opcion desea elejir? ");
                                                                op5=Lector.nextInt();
                                                                switch (op5) {
                                                                    case 1:
                                                                        System.out.println(Belleza.getBellezas().get(op4).InfoBelleza());
                                                                        break;
                                                                    case 2://MODIFICAR SERVICIOS
                                                                        servicioactual=Belleza.getBellezas().get(op4);
                                                                        modificar(servicioactual);
                                                                        categorias(servicioactual);
                                                                        System.out.println(Belleza.getBellezas().get(op4).InfoBelleza());
                                                                        break;
                                                                    default:
                                                                        System.out.println("Opcion invalida");
                                                                        break;
                                                                }
                                                            } while (op5<1||op5>2);
                                                        }
                                                        break;
                                                    case 2:
                                                        System.out.println(Deportes.viewDeporte());
                                                        if (Deportes.viewDeporte().contains("No hay servicios registrados")) {
                                                        System.out.println("====================================================");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea elejir? ");
                                                            op4=Lector.nextInt()-1;
                                                            do {
                                                                System.out.println("========ADMINISTRAR INFORMACION DEL SERVICIO========");
                                                                System.out.println("1- Mostrar informacion actual");
                                                                System.out.println("2- Editar informacion");
                                                                System.out.print("¿Que opcion desea elejir? ");
                                                                op5=Lector.nextInt();
                                                                switch (op5) {
                                                                    case 1:
                                                                        System.out.println(Deportes.getDeportes().get(op4).InfoDeportes());
                                                                        break;
                                                                    case 2://MODIFICAR SERVICIOS
                                                                        servicioactual=Deportes.getDeportes().get(op4);
                                                                        modificar(servicioactual);
                                                                        categorias(servicioactual);
                                                                        System.out.println(Deportes.getDeportes().get(op4).InfoDeportes());
                                                                        break;
                                                                    default:
                                                                        System.out.println("Opcion invalida");
                                                                        break;
                                                                }
                                                            } while (op5<1||op5>2);
                                                        }
                                                        break;
                                                    case 3:
                                                        System.out.println(Educativo.viewEducativo());
                                                        if (Educativo.viewEducativo().contains("No hay servicios registrados")) {
                                                        System.out.println("====================================================");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea elejir? ");
                                                            op4=Lector.nextInt()-1;
                                                            do {
                                                                System.out.println("========ADMINISTRAR INFORMACION DEL SERVICIO========");
                                                                System.out.println("1- Mostrar informacion actual");
                                                                System.out.println("2- Editar informacion");
                                                                System.out.print("¿Que opcion desea elejir? ");
                                                                op5=Lector.nextInt();
                                                                switch (op5) {
                                                                    case 1:
                                                                        System.out.println(Educativo.getEducativos().get(op4).InfoEducacion());
                                                                        break;
                                                                    case 2://MODIFICAR SERVICIOS
                                                                        servicioactual=Educativo.getEducativos().get(op4);
                                                                        modificar(servicioactual);
                                                                        categorias(servicioactual);
                                                                        System.out.println(Educativo.getEducativos().get(op4).InfoEducacion());
                                                                        break;
                                                                    default:
                                                                        System.out.println("Opcion invalida");
                                                                        break;
                                                                }
                                                            } while (op5<1||op5>2);
                                                        }
                                                        break;
                                                    case 4:
                                                        System.out.println(Entretenimiento.viewShows());
                                                        if (Entretenimiento.viewShows().contains("No hay servicios registrados")) {
                                                        System.out.println("====================================================");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea elejir? ");
                                                            op4=Lector.nextInt()-1;
                                                            do {
                                                                System.out.println("========ADMINISTRAR INFORMACION DEL SERVICIO========");
                                                                System.out.println("1- Mostrar informacion actual");
                                                                System.out.println("2- Editar informacion");
                                                                System.out.print("¿Que opcion desea elejir? ");
                                                                op5=Lector.nextInt();
                                                                switch (op5) {
                                                                    case 1:
                                                                        System.out.println(Entretenimiento.getShows().get(op4).InfoShows());
                                                                        break;
                                                                    case 2://MODIFICAR SERVICIOS
                                                                        servicioactual=Entretenimiento.getShows().get(op4);
                                                                        modificar(servicioactual);
                                                                        categorias(servicioactual);
                                                                        System.out.println(Entretenimiento.getShows().get(op4).InfoShows());
                                                                        break;
                                                                    default:
                                                                        System.out.println("Opcion invalida");
                                                                        break;
                                                                }
                                                            } while (op5<1||op5>2);
                                                        }
                                                        break;
                                                    case 5:
                                                        System.out.println(Eventos.viewEventos());
                                                        if (Eventos.viewEventos().contains("No hay servicios registrados")) {
                                                        System.out.println("====================================================");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea elejir? ");
                                                            op4=Lector.nextInt()-1;
                                                            do {
                                                                System.out.println("========ADMINISTRAR INFORMACION DEL SERVICIO========");
                                                                System.out.println("1- Mostrar informacion actual");
                                                                System.out.println("2- Editar informacion");
                                                                System.out.print("¿Que opcion desea elejir? ");
                                                                op5=Lector.nextInt();
                                                                switch (op5) {
                                                                    case 1:
                                                                        System.out.println(Eventos.getEventos().get(op4).InfoEventos());
                                                                        break;
                                                                    case 2://MODIFICAR SERVICIOS
                                                                        servicioactual=Eventos.getEventos().get(op4);
                                                                        modificar(servicioactual);
                                                                        categorias(servicioactual);
                                                                        System.out.println(Eventos.getEventos().get(op4).InfoEventos());
                                                                        break;
                                                                    default:
                                                                        System.out.println("Opcion invalida");
                                                                        break;
                                                                }
                                                            } while (op5<1||op5>2);
                                                        }
                                                        break;
                                                    case 6:
                                                        System.out.println(MYR.viewMYR());
                                                        if (MYR.viewMYR().contains("No hay servicios registrados")) {
                                                        System.out.println("====================================================");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea elejir? ");
                                                            op4=Lector.nextInt()-1;
                                                            do {
                                                                System.out.println("========ADMINISTRAR INFORMACION DEL SERVICIO========");
                                                                System.out.println("1- Mostrar informacion actual");
                                                                System.out.println("2- Editar informacion");
                                                                System.out.print("¿Que opcion desea elejir? ");
                                                                op5=Lector.nextInt();
                                                                switch (op5) {
                                                                    case 1:
                                                                        System.out.println(MYR.getMyr().get(op4).InfoMYR());
                                                                        break;
                                                                    case 2://MODIFICAR SERVICIOS
                                                                        servicioactual=MYR.getMyr().get(op4);
                                                                        modificar(servicioactual);
                                                                        categorias(servicioactual);
                                                                        System.out.println(MYR.getMyr().get(op4).InfoMYR());
                                                                        break;
                                                                    default:
                                                                        System.out.println("Opcion invalida");
                                                                        break;
                                                                }
                                                            } while (op5<1||op5>2);
                                                        }
                                                        break;
                                                    case 7:
                                                        System.out.println(Produccion.viewProdu());
                                                        if (Produccion.viewProdu().contains("No hay servicios registrados")) {
                                                        System.out.println("====================================================");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea elejir? ");
                                                            op4=Lector.nextInt()-1;
                                                            do {
                                                                System.out.println("========ADMINISTRAR INFORMACION DEL SERVICIO========");
                                                                System.out.println("1- Mostrar informacion actual");
                                                                System.out.println("2- Editar informacion");
                                                                System.out.print("¿Que opcion desea elejir? ");
                                                                op5=Lector.nextInt();
                                                                switch (op5) {
                                                                    case 1:
                                                                        System.out.println(Produccion.getProducciones().get(op4).InfoProduccion());
                                                                        break;
                                                                    case 2://MODIFICAR SERVICIOS
                                                                        servicioactual=Produccion.getProducciones().get(op4);
                                                                        modificar(servicioactual);
                                                                        categorias(servicioactual);
                                                                        System.out.println(Produccion.getProducciones().get(op4).InfoProduccion());
                                                                        break;
                                                                    default:
                                                                        System.out.println("Opcion invalida");
                                                                        break;
                                                                }
                                                            } while (op5<1||op5>2);
                                                        }
                                                        break;
                                                    case 8:
                                                        System.out.println(Salud.viewSalud());
                                                        if (Salud.viewSalud().contains("No hay servicios registrados")) {
                                                        System.out.println("====================================================");
                                                        }
                                                        else {
                                                            System.out.print("¿Que servicio desea elejir? ");
                                                            op4=Lector.nextInt()-1;
                                                            do {
                                                                System.out.println("========ADMINISTRAR INFORMACION DEL SERVICIO========");
                                                                System.out.println("1- Mostrar informacion actual");
                                                                System.out.println("2- Editar informacion");
                                                                System.out.print("¿Que opcion desea elejir? ");
                                                                op5=Lector.nextInt();
                                                                switch (op5) {
                                                                    case 1:
                                                                        System.out.println(Salud.getSalud().get(op4).InfoSalud());
                                                                        break;
                                                                    case 2://MODIFICAR SERVICIOS
                                                                        servicioactual=Salud.getSalud().get(op4);
                                                                        modificar(servicioactual);
                                                                        categorias(servicioactual);
                                                                        System.out.println(Salud.getSalud().get(op4).InfoSalud());
                                                                        break;
                                                                    default:
                                                                        System.out.println("Opcion invalida");
                                                                        break;
                                                                }
                                                            } while (op5<1||op5>2);
                                                        }
                                                        break;
                                                    default:
                                                        System.out.println("Opcion invalida");
                                                        break;
                                                }
                                            } while (op2<1||op2>8);
                                            break;
                                        default:
                                            System.out.println("Opcion invalida");
                                            break;
                                    }
                                } while (op3<1||op3>2);
                                break;
                            case 4:
                                consultadeservicios();
                                break;
                            case 5:
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2!=5);
                    break;
                case 2:
                    do {
                        System.out.println("=============ADMINISTRACION DE USUARIOS=============");
                        System.out.println("1- Consulta de usuarios");
                        System.out.println("2- Alta de usuarios");
                        System.out.println("3- Baja de usuarios");
                        System.out.println("4- Volver al menu principal");
                        System.out.print("¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        System.out.println("====================================================");
                        switch (op2) {
                            case 1:
                                System.out.println("============LISTAS DE USUARIOS REGISTRADOS==========");
                                System.out.println("1- Usuarios");
                                System.out.println("2- Administradores");
                                System.out.print("¿Que tipo de usuario quiere consultar? ");
                                op3=Lector.nextInt();
                                System.out.println("====================================================");
                                switch(op3){
                                    case 1:
                                        System.out.println(Usuario.ListaUsuarios());
                                        break;
                                    case 2:
                                        System.out.println(Administrador.ListaAdmins());
                                        break;
                                    default:
                                        System.out.println("Opcion invalida");
                                        break;
                                }
                                break;
                            case 2:
                                System.out.println("==================ALTA DE USUARIOS==================");
                                System.out.println("1- Usuario");
                                System.out.println("2- Administrador");
                                System.out.print("¿Que tipo de usuario quiere registrar? ");
                                op3=Lector.nextInt();
                                System.out.println("====================================================");
                                switch(op3) {
                                    case 1:
                                        tipoUser="Usuario";
                                        registro();
                                        break;
                                    case 2:
                                        tipoUser="Administrador";
                                        registro();
                                        break;
                                    default:
                                        System.out.println("Opcion invalida");
                                        break;
                                }
                                break;
                            case 3:
                                System.out.println("==================BAJA DE USUARIOS==================");
                                System.out.println("1- Usuario");
                                System.out.println("2- Administrador");
                                System.out.print("¿Que tipo de usuario quiere eliminar? ");
                                op3=Lector.nextInt();
                                System.out.println("====================================================");
                                switch(op3) {
                                    case 1:
                                        System.out.println(Usuario.ListaUsuarios());
                                        System.out.print("¿Que usuario desea eliminar? ");
                                        op4=Lector.nextInt()-1;
                                        if (op4>=0&&op4<Usuario.getUsuarios().size()) {
                                            Usuario.getUsuarios().remove(op4);
                                            System.out.println("====================================================");
                                            System.out.println("            ¡USUARIO ELIMINADO CON EXITO!");
                                        }
                                        else {
                                            System.out.println("Opcion invalida");
                                        }
                                        break;
                                    case 2:
                                        System.out.println(Administrador.ListaAdmins());
                                        System.out.print("¿Que administrador desea eliminar? ");
                                        op4=Lector.nextInt()-1;
                                        if (op4>=0&&op4<Administrador.getAdministradores().size()) {
                                            Administrador.getAdministradores().remove(op4);
                                            System.out.println("====================================================");
                                            System.out.println("         ¡ADMINISTRADOR ELIMINADO CON EXITO!");
                                        }
                                        else {
                                            System.out.println("Opcion invalida");
                                        }
                                        break;
                                    default:
                                        System.out.println("Opcion invalida");
                                        break;
                                }
                                break;
                            case 4:
                                break;
                            default:
                            System.out.println("Opcion invalida");
                            break;
                        }
                    } while (op2!=4);
                    break;
                case 3:
                    do {
                        System.out.println("=============ADMINISTRACION DE REPORTES=============");
                        System.out.println("1- Generar reporte");
                        System.out.println("2- Consulta de reportes");
                        System.out.println("3- Volver al menu principal");
                        System.out.print("¿Que opcion desea elegir? ");
                        op2=Lector.nextInt();
                        System.out.println("====================================================");
                        switch (op2) {
                            case 1:
                                //metodo que permitira generar los reportes dependiendo de:
                                //tipo, precio, ciudad, calificacion, servicios mejor y peor calificados, usuarios mejor y peor calificados y servicios relacionados
                                break;
                            case 2:
                                //metodo para ver todos los reportes generados hasta ahora en una lista de reportes (un vector)
                                break;
                            case 3:
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2!=3);
                    break;
                case 4:
                    do {
                        System.out.println("==================DATOS PERSONALES==================");
                        System.out.println("1- Informacion actual");
                        System.out.println("2- Editar informacion");
                        System.out.println("3- Volver al menu principal");
                        System.out.print("¿Que opcion desea elegir? ");
                        op3=Lector.nextInt();
                        System.out.println("====================================================");
                        switch(op3) {
                            case 1:
                                Administrador.predeterminadosA();
                                Administrador obj6 = Administrador.getAdministradores().get(i);
                                System.out.println(obj6.InfoAllUsuario());
                                System.out.println("====================================================");
                                break;
                            case 2:
                                int op0;
                                String contra;
                                System.out.print("Nombre: ");
                                nombre=Lector.next();
                                System.out.print("Apellido paterno: ");
                                app=Lector.next();
                                System.out.print("Apellido materno: ");
                                apm=Lector.next();
                                System.out.print("Telefono de contacto: ");
                                telefono=Lector.next();
                                System.out.print("Correo electronico: ");
                                correo=Lector.next();
                                System.out.print("Usuario: ");
                                usuario=Lector.next();
                                System.out.print("Calle: ");
                                calle=Lector.next();
                                System.out.print("Numero exterior: ");
                                numero=Lector.next();
                                System.out.print("Ciudad: ");
                                ciudad=Lector.next();
                                System.out.print("Estado: ");
                                estado=Lector.next();
                                System.out.print("Codigo postal: ");
                                cp=Lector.next();
                                System.out.println("=================CAMBIAR CONTRASEÑA=================");
                                System.out.println("1- Si    2- No");
                                System.out.print("¿Desea cambiar la contraseña? ");
                                op0=Lector.nextInt();
                                switch (op0) {
                                    case 1:
                                        do {
                                            System.out.print("Ingrese la contraseña actual: ");
                                            contra=Lector.next();
                                            if (!Administrador.getAdministradores().get(i).getContraseña().equals(contra)) {
                                                System.out.println("Contraseña incorrecta");
                                            }
                                        } while (!Administrador.getAdministradores().get(i).getContraseña().equals(contra));
                                        System.out.print("Ingrese la nueva contraseña: ");
                                        contraseña=Lector.next();
                                        break;
                                    case 2:
                                        break;
                                    default:
                                        System.out.println("Opcion invalida");
                                        break;
                                }
                                Administrador obj11 = Administrador.getAdministradores().get(i);
                                obj11.infoAdmin(nombre, app, apm, usuario, telefono, correo, contraseña, calle, numero, ciudad, estado, cp);
                                System.out.println("====================================================");
                                System.out.println(obj11.InfoAllUsuario());
                                break;
                            case 3:
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op3!=3);
                    break;
                case 5:
                    do {
                        System.out.println("================MONEDERO ELECTRONICO================");
                        System.out.println("1- Consultar saldo");
                        System.out.println("2- Agregar saldo");
                        System.out.println("3- Volver al menu principal");
                        System.out.print("¿Que opcion desea elejir? ");
                        op2=Lector.nextInt();
                        System.out.println("====================================================");
                        switch (op2) {
                            case 1:
                                System.out.println(useractual.consultaSaldo());
                                break;
                            case 2:
                                System.out.print("¿Cuanto desea agregar? ");
                                monto=Lector.nextDouble();
                                useractual.aggSaldo(monto);
                                System.out.println("====================================================");
                                System.out.println("           ¡DEPOSITO REALIZADO CON EXITO!");
                                System.out.println("====================================================");
                                System.out.println(useractual.consultaSaldo());
                                break;
                            case 3:
                                break;
                            default:
                                System.out.println("Opcion invalida");
                                break;
                        }
                    } while (op2!=3);
                    break;
                case 6:
                    return;
                default:
                    System.out.println("Opcion invalida");
                    break;
            }
        } while (true);
    }
    
    //METODO ACCESO
    public static void acceso() {
        System.out.println("===================INICIAR SESION===================");
        System.out.print("Correo electronico: ");
        correo=Lector.next();
        System.out.print("Contraseña: ");
        contraseña=Lector.next();
        for (int i = 0; i < Administrador.getAdministradores().size(); i++) {
            Administrador admin = Administrador.getAdministradores().get(i);
            if (admin.getCorreo().equals(correo)&&admin.getContraseña().equals(contraseña)) {
                useractual=admin;
                System.out.println("====================================================");
                System.out.println("      ¡BIENVENIDO, "+admin.nombrecompleto()+"!");
                menuAdmin();
                return;
            }
        }
        for (int i = 0; i < Usuario.getUsuarios().size(); i++) {
            Usuario user = Usuario.getUsuarios().get(i);
            if (user.getCorreo().equals(correo)&&user.getContraseña().equals(contraseña)) {
                useractual=user;
                System.out.println("====================================================");
                System.out.println("      ¡BIENVENIDO, "+user.nombrecompleto()+"!");
                menuUsuario();
                return;
            }
        }
        System.out.println("Correo o contraseña incorrectos");
    }
    
    //METODO REGISTRO
    public static void registro() {
        System.out.print("Nombre: ");
        nombre=Lector.next();
        Lector.nextLine();
        System.out.print("Apellido paterno: ");
        app=Lector.next();
        System.out.print("Apellido materno: ");
        apm=Lector.next();
        do {
            System.out.print("Crear usuario: ");
            usuario=Lector.next();
            existe=true;
            for (int i = 0; i < Usuario.getUsuarios().size(); i++) {
                if (Usuario.getUsuarios().get(i).getUsuario().equals(usuario)) {
                    existe=false;
                }
            }
            for (int i = 0; i < Administrador.getAdministradores().size(); i++) {
                if (Administrador.getAdministradores().get(i).getUsuario().equals(usuario)) {
                    existe=false;
                }
            }
            if (existe==false) {
                System.out.println("El usuario ya esta en uso, elija otro");
            }
        } while (existe==false);   
        System.out.print("Identificacion: ");
        identificacion=Lector.next();
        System.out.print("Telefono: ");
        telefono=Lector.next();
        Lector.nextLine();
        do {
            System.out.print("Correo electronico: ");
            correo=Lector.next();
            existe=true;
            for (int i = 0; i < Usuario.getUsuarios().size(); i++) {
                if (Usuario.getUsuarios().get(i).getCorreo().equals(correo)) {
                    existe=false;
                }
            }
            for (int i = 0; i < Administrador.getAdministradores().size(); i++) {
                if (Administrador.getAdministradores().get(i).getCorreo().equals(correo)) {
                    existe=false;
                }
            }
            if (existe==false) {
                System.out.println("El correo ya esta en uso, elija otro");
            }
        } while (existe==false);
        System.out.print("Crear contraseña: ");
        contraseña=Lector.next();
        System.out.print("Calle: ");
        calle=Lector.next();
        System.out.print("Numero exterior: ");
        numero=Lector.next();
        System.out.print("Codigo postal: ");
        cp=Lector.next();
        System.out.print("Ciudad de residencia: ");
        ciudad=Lector.next();
        System.out.print("Estado: ");
        estado=Lector.next();
        if (tipoUser.equals("Usuario")) {
            Usuario obj1 = new Usuario(usuario, contraseña, nombre, app, apm, calle, numero, ciudad, estado, cp, telefono, correo, identificacion, tipoUser);
            Usuario.aggUsuario(obj1);
        }
        else if (tipoUser.equals("Administrador")) {
            Administrador obj2 = new Administrador(usuario, contraseña, nombre, app, apm, calle, numero, ciudad, estado, cp, telefono, correo, identificacion, tipoUser);
            Administrador.aggAdmin(obj2);
        }
        System.out.println("¡EL REGISTRO HA SIDO EXITOSO!");
    }
    
    //MAIN
    public static void main(String[] args) {
        Scanner Lector = new Scanner (System.in);
        Administrador.predeterminadosA();
        Belleza.predeterminados();
        Usuario.predeterminadosU();
        Deportes.predeterminados();
        Educativo.predeterminados();
        Entretenimiento.predeterminados();
        int op;
        do {
            System.out.println("===============SISTEMA DE INTERCAMBIO===============");
            System.out.println("1- Iniciar sesion");
            System.out.println("2- Registrarse");
            System.out.println("3- Salir");
            System.out.print("¿Que opcion desea elejir? ");
            op=Lector.nextInt();
            System.out.println("====================================================");
            switch (op) {
                case 1:
                    acceso();
                    break;
                case 2:
                    System.out.println("====================CREAR CUENTA====================");
                    tipoUser="Usuario";
                    registro();
                    acceso();
                    break;
                case 3:
                    System.out.println("         ¡GRACIAS POR USAR NUESTRO SISTEMA!");
                    System.out.println("====================================================");
                    return;
                default:
                    System.out.println("Opcion invalida");
                    break;   
            }
        } while (true);
    }   
}
