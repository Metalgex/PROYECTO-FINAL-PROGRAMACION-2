package sistemadeintercambio;
import java.time.LocalDateTime;
public class Reporte {
    private String tipo;
    private LocalDateTime fecha;
    private String contenido;

    public Reporte(String tipo, LocalDateTime fecha, String contenido) {
        this.tipo = tipo;
        this.fecha = fecha;
        this.contenido = contenido;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
}
