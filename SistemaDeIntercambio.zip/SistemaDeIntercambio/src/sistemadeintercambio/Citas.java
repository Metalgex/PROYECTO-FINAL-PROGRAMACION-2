package sistemadeintercambio;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
public class Citas {
    private Servicios servicio;
    private LocalDateTime fechahora;
    private int horas;
    private LocalDateTime fechacompra;

    public Citas(Servicios servicio, LocalDateTime fechahora, int horas) {
        this.servicio = servicio;
        this.fechahora = fechahora;
        this.horas = horas;
        this.fechacompra = LocalDateTime.now();
    }

    public LocalDateTime getFechacompra() {
        return fechacompra;
    }

    public void setFechacompra(LocalDateTime fechacompra) {
        this.fechacompra = fechacompra;
    }

    public Servicios getServicio() {
        return servicio;
    }

    public void setServicio(Servicios servicio) {
        this.servicio = servicio;
    }

    public LocalDateTime getFechahora() {
        return fechahora;
    }

    public void setFechahora(LocalDateTime fechahora) {
        this.fechahora = fechahora;
    }

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }
    
    public double getSubtotal() {
        double subtotal;
        subtotal=servicio.getPrecio()*horas;
        return subtotal;
    }
    
    public String InfoAll() {
        String cadena="";
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
        String fecha2 = fechahora.format(formato);
        String fecha3 = fechacompra.format(formato);
        cadena+="                                    𝗥𝗘𝗦𝗨𝗠𝗘𝗡 𝗗𝗘 𝗧𝗨 𝗖𝗢𝗠𝗣𝗥𝗔\n";
        cadena+="-----------------------------------------------------------------------------------------------\n";
        cadena+="𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: "+servicio.getNombreServicio().toUpperCase()+" 𝗣𝗢𝗥 "+horas+" 𝗛𝗢𝗥𝗔𝗦\n";
        cadena+="𝗖𝗢𝗠𝗣𝗥𝗔𝗗𝗢 𝗘𝗟: "+fecha3+"\n";
        cadena+="𝗥𝗘𝗦𝗘𝗥𝗩𝗔𝗖𝗜𝗢𝗡 𝗣𝗔𝗥𝗔: "+fecha2+"\n";
        cadena+="𝗧𝗢𝗧𝗔𝗟 𝗔 𝗣𝗔𝗚𝗔𝗥: $"+getSubtotal();
        cadena+="\n===============================================================================================";
        return cadena;
    }
    
    public String InfoComprados() {
        String cadena="";
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
        String fecha3 = fechacompra.format(formato);
        cadena+="𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: "+servicio.getNombreServicio().toUpperCase()+" $"+getSubtotal()+"\n";
        cadena+="𝗖𝗢𝗠𝗣𝗥𝗔𝗗𝗢 𝗘𝗟: "+fecha3+"\n";
        return cadena;
    }
    
    public String InfoCarrito() {
        String cadena="";
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
        String fecha2 = fechahora.format(formato);
        cadena+="𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: "+servicio.getNombreServicio().toUpperCase()+" 𝗣𝗢𝗥 "+horas+" 𝗛𝗢𝗥𝗔𝗦\n";
        cadena+="𝗥𝗘𝗦𝗘𝗥𝗩𝗔𝗖𝗜𝗢𝗡 𝗣𝗔𝗥𝗔: "+fecha2+"\n";
        cadena+="𝗦𝗨𝗕𝗧𝗢𝗧𝗔𝗟: $"+getSubtotal()+"\n";
        cadena+="-----------------------------------------------------------------------------------------------";
        return cadena;
    }
}
