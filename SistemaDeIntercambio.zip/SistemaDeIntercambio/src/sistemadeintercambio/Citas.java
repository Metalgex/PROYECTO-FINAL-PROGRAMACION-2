package sistemadeintercambio;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
public class Citas {
    private Servicios servicio;
    private LocalDateTime fechahora;
    private int horas;

    public Citas(Servicios servicio, LocalDateTime fechahora, int horas) {
        this.servicio = servicio;
        this.fechahora = fechahora;
        this.horas = horas;
    }

    public Servicios getServicio() {
        return servicio;
    }

    public void setServicio(Servicios servicio) {
        this.servicio = servicio;
    }

    public LocalDateTime getFechahora() {
        return fechahora;
    }

    public void setFechahora(LocalDateTime fechahora) {
        this.fechahora = fechahora;
    }

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }
    
    public double getSubtotal() {
        double subtotal;
        subtotal=servicio.getPrecio()*horas;
        return subtotal;
    }
    
    public String InfoAll() {
        String cadena="";
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy 'a las' HH:mm", new Locale("es", "ES"));
        String fecha2 = fechahora.format(formato);
        cadena=servicio.getNombreServicio()+" $"+servicio.getPrecio()+" por "+horas+" horas= "+getSubtotal()
                +"\nReservacion: "+fecha2;
        return cadena;
    }
}
