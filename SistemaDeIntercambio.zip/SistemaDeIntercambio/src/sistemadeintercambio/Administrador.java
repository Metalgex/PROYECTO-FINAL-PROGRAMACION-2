package sistemadeintercambio;
import java.util.*;
public class Administrador extends Usuario{
    private static Vector<Administrador> administradores = new Vector<>();
    
    public Administrador(String usuario, String contraseña, String nombre, String app, String apm, String calle, String numero, String ciudad, String estado, String cp, String telefono, String correo, String identificacion, String tipoUser) {
        super(usuario, contraseña, nombre, app, apm, calle, numero, ciudad, estado, cp, telefono, correo, identificacion, tipoUser);       
    }
    
    public static void aggAdmin(Administrador i) {
        administradores.add(i);
    }
    
    public static Vector<Administrador> getAdministradores() {
        return administradores;
    }
    
    public static void predeterminadosA() {
        administradores.add(new Administrador("sfacundo", "fac12", "Santiago", "Facundo", "Juarez", "Hipodromo", "504", "Frontera", "Coahuila", "25680", "8661728970", "sfacundo@uadec.edu.mx", "21043503", "Administrador"));
        administradores.add(new Administrador("gmartinez", "gadiel456", "Gadiel", "Martinez", "Limon", "Irapuato", "606", "Frontera", "Coahuila", "25640", "8661540331", "gadielm@uadec.edu.mx", "30456783", "Administrador"));
        administradores.add(new Administrador("sherlynA", "sher789", "Sherlyn", "Garcia", "Lucero", "Quiñones", "1729", "Monclova", "Coahuila", "27690", "8662345972", "sherly@uadec.edu.mx", "60678900", "Administrador"));
    }
    
    public static String ListaAdmins() {
        String cadena="";
        cadena+="==================ADMINISTRADORES===================\n";
        if (administradores.isEmpty()) {
            cadena="No hay administradores registrados";
        }
        for (int i = 0; i < administradores.size(); i++) {
            Administrador user = administradores.get(i);
            cadena+=(i+1)+"- "+user.nombrecompleto()+", "+user.getCorreo()+"\n";
        }
        return cadena;
    }
}
