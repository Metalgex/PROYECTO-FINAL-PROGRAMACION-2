package sistemadeintercambio;
import java.util.*;
import sistemadeintercambio.Carrito;
public class Usuario {
    private static Vector<Usuario> usuarios = new Vector<>();
    private static Vector<Citas> comprados = new Vector<>();
    private static Vector<Servicios> publicados = new Vector<>();
    private static Vector<Reseñas> reseñas = new Vector<>();
    private String usuario;
    private String contraseña;
    private String nombre;
    private String app;
    private String apm;
    private String calle;
    private String numero;
    private String ciudad;
    private String estado;
    private String cp;
    private String telefono;
    private String correo;
    private String identificacion;
    private String tipoUser;
    private double saldo;
    private Carrito carritos = new Carrito();

    public Usuario(String usuario, String contraseña, String nombre, String app, String apm, String calle, String numero, String ciudad, String estado, String cp, String telefono, String correo, String identificacion, String tipoUser) {
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.nombre = nombre;
        this.app = app;
        this.apm = apm;
        this.calle = calle;
        this.numero = numero;
        this.ciudad = ciudad;
        this.estado = estado;
        this.cp = cp;
        this.telefono = telefono;
        this.correo = correo;
        this.identificacion = identificacion;
        this.tipoUser = tipoUser;
    }
    
    public void InfoUser(String nombre, String app, String apm, String telefono, String contraseña, String calle, String numero, String ciudad, String estado, String cp) {
        this.nombre = nombre;
        this.app = app;
        this.apm = apm;
        this.telefono = telefono;
        this.contraseña = contraseña;
        this.calle = calle;
        this.numero = numero;
        this.ciudad = ciudad;
        this.estado = estado;
        this.cp = cp;
    }
    
    public void infoAdmin(String nombre, String app, String apm, String usuario, String telefono, String correo, String contraseña, String calle, String numero, String ciudad, String estado, String cp) {
        this.nombre = nombre;
        this.app = app;
        this.apm = apm;
        this.usuario = usuario;
        this.telefono = telefono;
        this.correo = correo;
        this.contraseña = contraseña;
        this.calle = calle;
        this.numero = numero;
        this.ciudad = ciudad;
        this.estado = estado;
        this.cp = cp;
    }

    public static Vector<Servicios> getPublicados() {
        return publicados;
    }

    public static void setPublicados(Vector<Servicios> publicados) {
        Usuario.publicados = publicados;
    }
    
    public static Vector<Citas> getComprados() {
        return comprados;
    }

    public static void setComprados(Vector<Citas> comprados) {
        Usuario.comprados = comprados;
    }

    public Carrito getCarritos() {
        return carritos;
    }

    public void setCarritos(Carrito carritos) {
        this.carritos = carritos;
    }
    
    public static void predeterminadosU() {
        usuarios.add(new Usuario("metalgex", "santi123", "Santiago", "Facundo", "Juarez", "Hipodromo", "504", "Frontera", "Coahuila", "25680", "8661728970", "metalgex@gmail.com", "21043503", "Usuario"));
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public String getTipoUser() {
        return tipoUser;
    }
    public void getTipoUser(String tipoUser) {
        this.tipoUser = tipoUser;
    }
    
    public static void aggUsuario(Usuario i) {
        usuarios.add(i);
    }
    
    public static Vector<Usuario> getUsuarios() {
        return usuarios;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public String getApm() {
        return apm;
    }

    public void setApm(String apm) {
        this.apm = apm;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCp() {
        return cp;
    }

    public void setCp(String cp) {
        this.cp = cp;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }
    
    public String nombrecompleto() {
        String cadena="";
        cadena=getNombre().toUpperCase()+" "+getApp().toUpperCase()+" "+getApm().toUpperCase();
        return cadena;
    }
    
    public String consultaSaldo() {
        String cadena="";
        cadena="Tu saldo actual es: $"+getSaldo();
        return cadena;
    }
    
    public void aggSaldo(double monto) {
        saldo+=monto;
    }
    
    public String comprar(double monto, Citas cita) {
        String cadena="";
        if (saldo<monto) {
            cadena="               ¡SALDO INSUFICIENTE!";
            return cadena;
        }
        saldo-=monto;
        cadena="                  ¡COMPRA EXITOSA!"
                + "\n===================================================="
                + "\n"+cita.InfoAll();
        return cadena;
    }

    public static Vector<Reseñas> getReseñas() {
        return reseñas;
    }

    public static void setReseñas(Vector<Reseñas> reseñas) {
        Usuario.reseñas = reseñas;
    }
    public void aggReseña(Reseñas i) {
        reseñas.add(i);
    }
    
    public String InfoAllUsuario() {
        String cadena="";
        cadena="=================INFORMACION BASICA=================\n"
                + getNombre().toUpperCase()+" "+getApp().toUpperCase()+" "+getApm().toUpperCase()+" "+getUsuario()
                + "\nContacto: "+getCorreo()+" "+getTelefono()
                + "\nFecha de alta: "
                + "\n=====================DIRECCION======================"
                + "\n"+getCalle()+" #"+getNumero()+" C.P."+getCp()
                + "\n"+getCiudad()+" "+getEstado();
        return cadena;
    }
    
    public static String ListaUsuarios() {
        String cadena="";
        cadena+="======================USUARIOS======================\n";
        if (usuarios.isEmpty()) {
            cadena="No hay usuarios registrados";
        }
        for (int i = 0; i < usuarios.size(); i++) {
            Usuario user = usuarios.get(i);
            cadena+=(i+1)+"- "+user.nombrecompleto()+", "+user.getCorreo()+"\n";
        }
        return cadena;
    }
    
    public String viewComprados() {
        String cadena="";
        if (comprados.isEmpty()) {
            cadena="No has comprado ningun servicio aun";
        } else {
            for (int i = 0; i < comprados.size(); i++) {
                cadena+=(i+1)+"- "+comprados.get(i).InfoAll()+"\n";
            }
        }
        return cadena;
    }
    
    public String viewPublicados() {
        String cadena="";
        if (publicados.isEmpty()) {
            cadena="No has publicados ningun servicio";
        } else {
            for (int i = 0; i < publicados.size(); i++) {
                cadena+=(i+1)+"- "+publicados.get(i).viewServicioAlone(i)+"\n";
            }
        }
        return cadena;
    }
    
    public String viewReseñas() {
        String cadena="";
        if (reseñas.isEmpty()) {
            cadena="No has escrito ninguna reseña";
        } else {
            for (int i = 0; i < reseñas.size(); i++) {
                cadena+=(i+1)+"- "+reseñas.get(i).getFechaReseña()+"\n"
                        +reseñas.get(i).getCalificacion()+"\n"
                        + reseñas.get(i).getComentario();
            }
        }
        return cadena;
    }
}
