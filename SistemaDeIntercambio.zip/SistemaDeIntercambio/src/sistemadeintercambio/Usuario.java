package sistemadeintercambio;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import sistemadeintercambio.Carrito;
public class Usuario {
    private static Vector<Usuario> usuarios = new Vector<>();
    private static Vector<Citas> comprados = new Vector<>();
    private static Vector<Servicios> publicados = new Vector<>();
    private static Vector<Reseñas> reseñas = new Vector<>();
    private String usuario;
    private String contraseña;
    private String nombre;
    private String app;
    private String apm;
    private String calle;
    private String numero;
    private String ciudad;
    private String estado;
    private String cp;
    private String telefono;
    private String correo;
    private String identificacion;
    private String tipoUser;
    private double saldo;
    private Carrito carritos = new Carrito();
    private LocalDate fechaAlta;

    public Usuario(String usuario, String contraseña, String nombre, String app, String apm, String calle, String numero, String ciudad, String estado, String cp, String telefono, String correo, String identificacion, String tipoUser) {
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.nombre = nombre;
        this.app = app;
        this.apm = apm;
        this.calle = calle;
        this.numero = numero;
        this.ciudad = ciudad;
        this.estado = estado;
        this.cp = cp;
        this.telefono = telefono;
        this.correo = correo;
        this.identificacion = identificacion;
        this.tipoUser = tipoUser;
        this.fechaAlta = LocalDate.now();
    }
    
    public void InfoUser(String nombre, String app, String apm, String telefono, String contraseña, String calle, String numero, String ciudad, String estado, String cp) {
        this.nombre = nombre;
        this.app = app;
        this.apm = apm;
        this.telefono = telefono;
        this.contraseña = contraseña;
        this.calle = calle;
        this.numero = numero;
        this.ciudad = ciudad;
        this.estado = estado;
        this.cp = cp;
    }
    
    public void infoAdmin(String nombre, String app, String apm, String usuario, String telefono, String correo, String contraseña, String calle, String numero, String ciudad, String estado, String cp) {
        this.nombre = nombre;
        this.app = app;
        this.apm = apm;
        this.usuario = usuario;
        this.telefono = telefono;
        this.correo = correo;
        this.contraseña = contraseña;
        this.calle = calle;
        this.numero = numero;
        this.ciudad = ciudad;
        this.estado = estado;
        this.cp = cp;
    }

    public LocalDate getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(LocalDate fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public static Vector<Servicios> getPublicados() {
        return publicados;
    }

    public static void setPublicados(Vector<Servicios> publicados) {
        Usuario.publicados = publicados;
    }
    
    public static Vector<Citas> getComprados() {
        return comprados;
    }

    public static void setComprados(Vector<Citas> comprados) {
        Usuario.comprados = comprados;
    }

    public Carrito getCarritos() {
        return carritos;
    }

    public void setCarritos(Carrito carritos) {
        this.carritos = carritos;
    }
    
    public static void predeterminadosU() {
        usuarios.add(new Usuario("metalgex", "santi123", "Santiago", "Facundo", "Juarez", "Hipodromo", "504", "Frontera", "Coahuila", "25680", "8661728970", "metalgex@gmail.com", "21043503", "Usuario"));
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public String getTipoUser() {
        return tipoUser;
    }
    public void getTipoUser(String tipoUser) {
        this.tipoUser = tipoUser;
    }
    
    public static void aggUsuario(Usuario i) {
        usuarios.add(i);
    }
    
    public static Vector<Usuario> getUsuarios() {
        return usuarios;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public String getApm() {
        return apm;
    }

    public void setApm(String apm) {
        this.apm = apm;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCp() {
        return cp;
    }

    public void setCp(String cp) {
        this.cp = cp;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }
    
    public String nombrecompleto() {
        String cadena="";
        cadena=getNombre().toUpperCase()+" "+getApp().toUpperCase()+" "+getApm().toUpperCase();
        return cadena;
    }
    
    public String consultaSaldo() {
        String cadena="";
        cadena="𝗧𝗨 𝗦𝗔𝗟𝗗𝗢 𝗔𝗖𝗧𝗨𝗔𝗟 𝗘𝗦: $"+getSaldo();
        return cadena;
    }
    
    public void aggSaldo(double monto) {
        saldo+=monto;
    }
    
    public String comprar(double monto, Citas cita) {
        String cadena="";
        if (saldo<monto) {
        cadena=   "                                     ¡SALDO INSUFICIENTE!";
        cadena+=  "\n===============================================================================================";
            return cadena;
        }
        saldo-=monto;
        cadena=   "                                       ¡COMPRA EXITOSA!"
                + "\n==============================================================================================="
                + "\n"+cita.InfoAll();
        return cadena;
    }

    public static Vector<Reseñas> getReseñas() {
        return reseñas;
    }

    public static void setReseñas(Vector<Reseñas> reseñas) {
        Usuario.reseñas = reseñas;
    }
    public void aggReseña(Reseñas i) {
        reseñas.add(i);
    }
    
    public String InfoAllUsuario() {
        String cadena="";
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy", new Locale("es", "ES"));
        
        cadena="===============================================================================================\n"
                + "                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗗𝗘𝗟 𝗨𝗦𝗨𝗔𝗥𝗜𝗢"
                + "\n-----------------------------------------------------------------------------------------------\n"
                + "𝗡𝗢𝗠𝗕𝗥𝗘: "+getNombre().toUpperCase()+" "+getApp().toUpperCase()+" "+getApm().toUpperCase()+" 𝗨𝗦𝗨𝗔𝗥𝗜𝗢: "+getUsuario()
                + "\n𝗖𝗢𝗡𝗧𝗔𝗖𝗧𝗢: "+getCorreo()+" "+getTelefono()
                + "\n𝗙𝗘𝗖𝗛𝗔 𝗗𝗘 𝗔𝗟𝗧𝗔: "+fechaAlta.format(formato)
                + "\n==============================================================================================="
                + "\n                                           𝗗𝗜𝗥𝗘𝗖𝗖𝗜𝗢𝗡"
                + "\n-----------------------------------------------------------------------------------------------"
                + "\n"+getCalle()+" #"+getNumero()+" 𝗖.𝗣."+getCp()
                + "\n"+getCiudad()+" "+getEstado()
                + "\n===============================================================================================";
        return cadena;
    }
    
    public static String ListaUsuarios() {
        String cadena="";
        cadena+="===============================================================================================\n";
        cadena+="                                      𝗨𝗦𝗨𝗔𝗥𝗜𝗢𝗦 𝗥𝗘𝗚𝗜𝗦𝗧𝗥𝗔𝗗𝗢𝗦\n";
        cadena+="-----------------------------------------------------------------------------------------------\n";
        if (usuarios.isEmpty()) {
            cadena+="No hay usuarios registrados";
        }
        for (int i = 0; i < usuarios.size(); i++) {
            Usuario user = usuarios.get(i);
            cadena+=(i+1)+"- "+user.nombrecompleto()+", "+user.getCorreo()+"\n";
        }
        cadena+="===============================================================================================";
        return cadena;
    }
    
    public String viewComprados() {
        String cadena="";
        if (comprados.isEmpty()) {
            cadena= "                               No has comprado ningun servicio aun";
            cadena+="\n-----------------------------------------------------------------------------------------------";
        } else {
            for (int i = 0; i < comprados.size(); i++) {
                cadena+="-----------------------------------------------------------------------------------------------\n";
                cadena+=(i+1)+"- "+comprados.get(i).InfoComprados();
            }
            cadena+="\n===============================================================================================";
        }
        return cadena;
    }
    
    public String viewPublicados() {
        String cadena="";
        if (publicados.isEmpty()) {
            cadena= "                              No has publicados ningun servicio";
            cadena+="\n-----------------------------------------------------------------------------------------------";
        } else {
            for (int i = 0; i < publicados.size(); i++) {
                cadena+="-----------------------------------------------------------------------------------------------\n";
                cadena+=(i+1)+"- "+publicados.get(i).viewServicioAlone()+"\n";
            }
            cadena+="\n===============================================================================================";
        }
        return cadena;
    }
    
    public String viewReseñas() {
        String cadena="";
        if (reseñas.isEmpty()) {
            cadena= "                                  No has escrito ninguna reseña";
            cadena+="\n-----------------------------------------------------------------------------------------------";
        } else {
            for (int i = 0; i < reseñas.size(); i++) {
                cadena+="-----------------------------------------------------------------------------------------------\n";
                cadena+=(i+1)+"- "+reseñas.get(i).getFechaReseña()+"\n"
                        +reseñas.get(i).getCalificacion()+"\n"
                        + reseñas.get(i).getComentario()+"\n";
            }
            cadena+="===============================================================================================";
        }
        return cadena;
    }
}
