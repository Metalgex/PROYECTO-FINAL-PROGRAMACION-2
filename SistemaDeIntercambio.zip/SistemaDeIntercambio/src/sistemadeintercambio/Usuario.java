package sistemadeintercambio;
import Servicios.Belleza;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import sistemadeintercambio.Carrito;
public class Usuario {
    private static Vector<Usuario> usuarios = new Vector<>();
    private Vector<Citas> comprados = new Vector<>();
    private Vector<Servicios> publicados = new Vector<>();
    private Vector<Reseñas> reseñas = new Vector<>();
    private Vector<Mensajes> mensajes = new Vector<>();
    private Vector<String> movimientos = new Vector<>();
    
    private String usuario;
    private String contraseña;
    private String nombre;
    private String app;
    private String apm;
    private String calle;
    private String numero;
    private String ciudad;
    private String estado;
    private String cp;
    private String telefono;
    private String correo;
    private String identificacion;
    private String tipoUser;
    private double saldo;
    private Carrito carritos = new Carrito();
    private LocalDate fechaAlta;

    public Usuario(String usuario, String contraseña, String nombre, String app, String apm, String calle, String numero, String ciudad, String estado, String cp, String telefono, String correo, String identificacion, String tipoUser) {
        this.usuario = usuario;
        this.contraseña = contraseña;
        this.nombre = nombre;
        this.app = app;
        this.apm = apm;
        this.calle = calle;
        this.numero = numero;
        this.ciudad = ciudad;
        this.estado = estado;
        this.cp = cp;
        this.telefono = telefono;
        this.correo = correo;
        this.identificacion = identificacion;
        this.tipoUser = tipoUser;
        this.fechaAlta = LocalDate.now();
    }
    
    public void InfoUser(String nombre, String app, String apm, String telefono, String contraseña, String calle, String numero, String ciudad, String estado, String cp) {
        this.nombre = nombre;
        this.app = app;
        this.apm = apm;
        this.telefono = telefono;
        this.contraseña = contraseña;
        this.calle = calle;
        this.numero = numero;
        this.ciudad = ciudad;
        this.estado = estado;
        this.cp = cp;
    }
    
    public void infoAdmin(String nombre, String app, String apm, String usuario, String telefono, String correo, String contraseña, String calle, String numero, String ciudad, String estado, String cp) {
        this.nombre = nombre;
        this.app = app;
        this.apm = apm;
        this.usuario = usuario;
        this.telefono = telefono;
        this.correo = correo;
        this.contraseña = contraseña;
        this.calle = calle;
        this.numero = numero;
        this.ciudad = ciudad;
        this.estado = estado;
        this.cp = cp;
    }
    
    public Vector<Double> getCalificaciones() {
        Vector<Double> calificaciones = new Vector<>();
        for (int i = 0; i < reseñas.size(); i++) {
            calificaciones.add(reseñas.get(i).getCalificacion());
        }
        return calificaciones;
    }

    public LocalDate getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(LocalDate fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public Vector<Servicios> getPublicados() {
        return publicados;
    }

    public void setPublicados(Vector<Servicios> publicados) {
        this.publicados = publicados;
    }
    
    public Vector<Citas> getComprados() {
        return comprados;
    }

    public void setComprados(Vector<Citas> comprados) {
        comprados = comprados;
    }

    public Carrito getCarritos() {
        return carritos;
    }

    public void setCarritos(Carrito carritos) {
        this.carritos = carritos;
    }
    
    public static void predeterminadosU() {
        usuarios.add(new Usuario("metalgex", "santi123", "Santiago", "Facundo", "Juarez", "Hipodromo", "504", "Frontera", "Coahuila", "25680", "8661728970", "metalgex@gmail.com", "21043503", "Usuario"));
        usuarios.add(new Usuario("AgateAura", "vortex2006", "Edgar", "Medrano", "Jared", "Morelos", "9302", "Frontera", "Coahuila", "34632", "8662389087", "ejared@gmail.com", "30302314", "Usuario"));
        usuarios.add(new Usuario("LaFuria", "codyrhodes", "Sebastian", "Ibarra", "Garcia", "Xochimilco", "93221", "Monclova", "Coahuila", "324234", "8664056789", "sebasib@gmail.com", "3034567", "Usuario"));
        usuarios.add(new Usuario("anaas", "bidiba", "Ana", "Ibarra", "Garcia", "Gonzales", "72832", "Monclova", "Coahuila", "45323", "8663035678", "anas@gmail.com", "32522353", "Usuario"));
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public String getTipoUser() {
        return tipoUser;
    }
    public void getTipoUser(String tipoUser) {
        this.tipoUser = tipoUser;
    }
    
    public static void aggUsuario(Usuario i) {
        usuarios.add(i);
    }
    
    public static Vector<Usuario> getUsuarios() {
        return usuarios;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApp() {
        return app;
    }

    public void setApp(String app) {
        this.app = app;
    }

    public String getApm() {
        return apm;
    }

    public void setApm(String apm) {
        this.apm = apm;
    }

    public String getCalle() {
        return calle;
    }

    public void setCalle(String calle) {
        this.calle = calle;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getCp() {
        return cp;
    }

    public void setCp(String cp) {
        this.cp = cp;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        this.identificacion = identificacion;
    }
    
    public String nombrecompleto() {
        String cadena="";
        cadena=getNombre().toUpperCase()+" "+getApp().toUpperCase()+" "+getApm().toUpperCase();
        return cadena;
    }
    
    public String consultaSaldo() {
        String cadena="";
        cadena="𝗧𝗨 𝗦𝗔𝗟𝗗𝗢 𝗔𝗖𝗧𝗨𝗔𝗟 𝗘𝗦: $"+getSaldo();
        return cadena;
    }
    
    public void movimientos(double monto) {
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd'/'MMMM'/'yyyy", new Locale("es", "ES"));
        LocalDate fecha=LocalDate.now();
        String fecha2 = fecha.format(formato);
        movimientos.add(fecha2+" - Se realizo una compra del carrito de $"+monto);
    }
    
    public String viewmovimientos() {
        String cadena="";
        if (movimientos.isEmpty()) {
            cadena+=  "                                   No hay movimientos aun";
        } else {
            for (int i = 0; i < movimientos.size(); i++) {
                cadena+=movimientos.get(i)+"\n";
                cadena+="-----------------------------------------------------------------------------------------------\n";
            }
        }
        return cadena;
    }
    
    public void aggSaldo(double monto) {
        saldo+=monto;
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd'/'MMMM'/'yyyy", new Locale("es", "ES"));
        LocalDate fecha=LocalDate.now();
        String fecha2 = fecha.format(formato);
        movimientos.add(fecha2+" - Se realizo un deposito de $"+monto);
    }
    
    public String comprar(double monto, Citas cita) {
        String cadena="";
        if (saldo<monto) {
        cadena=   "                                     ¡SALDO INSUFICIENTE!";
        cadena+=  "\n===============================================================================================";
            return cadena;
        }
        saldo-=monto;
        cadena=   "                                       ¡COMPRA EXITOSA!"
                + "\n==============================================================================================="
                + "\n"+cita.InfoAll();
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd'/'MMMM'/'yyyy", new Locale("es", "ES"));
        LocalDate fecha=LocalDate.now();
        String fecha2 = fecha.format(formato);
        movimientos.add(fecha2+" - Se realizo una compra de $"+monto);
        return cadena;
    }

    public Vector<Reseñas> getReseñas() {
        return reseñas;
    }

    public void setReseñas(Vector<Reseñas> reseñas) {
        reseñas = reseñas;
    }
    public void aggReseña(Reseñas i) {
        reseñas.add(i);
    }
    
    public String InfoAllUsuario() {
        String cadena="";
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy", new Locale("es", "ES"));
        
        cadena="===============================================================================================\n"
                + "                                    𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗗𝗘𝗟 𝗨𝗦𝗨𝗔𝗥𝗜𝗢"
                + "\n-----------------------------------------------------------------------------------------------\n"
                + "𝗡𝗢𝗠𝗕𝗥𝗘: "+getNombre().toUpperCase()+" "+getApp().toUpperCase()+" "+getApm().toUpperCase()+" 𝗨𝗦𝗨𝗔𝗥𝗜𝗢: "+getUsuario()
                + "\n𝗖𝗢𝗡𝗧𝗔𝗖𝗧𝗢: "+getCorreo()+" "+getTelefono()
                + "\n𝗙𝗘𝗖𝗛𝗔 𝗗𝗘 𝗔𝗟𝗧𝗔: "+fechaAlta.format(formato)
                + "\n==============================================================================================="
                + "\n                                           𝗗𝗜𝗥𝗘𝗖𝗖𝗜𝗢𝗡"
                + "\n-----------------------------------------------------------------------------------------------"
                + "\n"+getCalle()+" #"+getNumero()+" 𝗖.𝗣."+getCp()
                + "\n"+getCiudad()+" "+getEstado()
                + "\n===============================================================================================";
        return cadena;
    }
    
    public static String ListaUsuarios() {
        String cadena="";
        cadena+="===============================================================================================\n";
        cadena+="                                      𝗨𝗦𝗨𝗔𝗥𝗜𝗢𝗦 𝗥𝗘𝗚𝗜𝗦𝗧𝗥𝗔𝗗𝗢𝗦\n";
        cadena+="-----------------------------------------------------------------------------------------------\n";
        if (usuarios.isEmpty()) {
            cadena+="No hay usuarios registrados";
        }
        for (int i = 0; i < usuarios.size(); i++) {
            Usuario user = usuarios.get(i);
            cadena+=(i+1)+"- "+user.nombrecompleto()+", "+user.getCorreo()+"\n";
        }
        cadena+="===============================================================================================";
        return cadena;
    }
    
    public String viewComprados() {
        String cadena="";
        if (comprados.isEmpty()) {
            cadena= "                               No has comprado ningun servicio aun";
            cadena+="\n-----------------------------------------------------------------------------------------------";
        } else {
            for (int i = 0; i < comprados.size(); i++) {
                cadena+="-----------------------------------------------------------------------------------------------\n";
                cadena+=(i+1)+"- "+comprados.get(i).InfoComprados();
            }
            cadena+="\n===============================================================================================";
        }
        return cadena;
    }
    
    public String viewPublicados() {
        String cadena="";
        if (publicados.isEmpty()) {
            cadena+="-----------------------------------------------------------------------------------------------\n";
            cadena+= "                              No has publicados ningun servicio";
            cadena+="\n-----------------------------------------------------------------------------------------------";
        } else {
            for (int i = 0; i < publicados.size(); i++) {
                cadena+="-----------------------------------------------------------------------------------------------\n";
                cadena+=(i+1)+"- "+publicados.get(i).viewServicioAlone()+"\n";
            }
            cadena+="\n===============================================================================================";
        }
        return cadena;
    }
    
    public String viewReseñas() {
        String cadena="";
        if (reseñas.isEmpty()) {
            cadena= "                                  No has escrito ninguna reseña";
            cadena+="\n-----------------------------------------------------------------------------------------------";
        } else {
            for (int i = 0; i < reseñas.size(); i++) {
                cadena+="-----------------------------------------------------------------------------------------------\n";
                cadena+=(i+1)+"- "+reseñas.get(i).getFechaReseña()+"\n"
                        +reseñas.get(i).getCalificacion()+"\n"
                        + reseñas.get(i).getComentario()+"\n";
            }
            cadena+="===============================================================================================";
        }
        return cadena;
    }
    
    public double promedio() {
        double suma=0, promedio=0;
        if (reseñas.isEmpty()) {
            promedio=0;
        } else {
            for (int i = 0; i < reseñas.size(); i++) {
                suma+=reseñas.get(i).getCalificacion();
            }
            promedio=suma/reseñas.size();
        }
        return promedio;
    }
    
    public static Usuario getnombreuser(String user) {
        for (int i = 0; i < usuarios.size(); i++) {
            Usuario user1 = usuarios.get(i);
            if (user1.getUsuario().equals(user)) {
                return user1;
            }
        }
        return null;
    }
    
    public void publicar(Servicios servie) {
        publicados.add(servie);
    }
    
    public void recibirmsg(String contenido) {
        String fecha = LocalDateTime.now().toString();
        mensajes.add(new Mensajes(fecha, contenido));
    }

    public Vector<Mensajes> getMensajes() {
        return mensajes;
    }
    
    public static void aggreseñas() {
        Usuario user1 = Usuario.usuarios.get(0);
        Usuario user2 = Usuario.usuarios.get(1);
        Usuario user3 = Usuario.usuarios.get(2);
        
        Servicios servicio1 = Servicios.generales.get(0);
        Servicios servicio2 = Servicios.generales.get(1);
        Servicios servicio3 = Servicios.generales.get(2);
        
        Citas cita1 = new Citas(Servicios.generales.get(0), LocalDateTime.now(), 2);
        user1.getComprados().add(cita1);
        
        Citas cita2 = new Citas(Servicios.generales.get(1), LocalDateTime.now(), 3);
        user2.getComprados().add(cita2);
        user1.getComprados().add(cita2);
        
        Citas cita3 = new Citas(Servicios.generales.get(2), LocalDateTime.now(), 2);
        user3.getComprados().add(cita3);
        
        Reseñas nueva = new Reseñas("metalgex", "metalgex@gmail.com", "Muy buen servicio!!", 9, "22 de mayo del 2025");
        user1.aggReseña(nueva);
        servicio1.aggReseña(nueva);
        
        Reseñas nueva2 = new Reseñas("AgateAura", "ejared@gmail.com", "Buen servicio, totalmente recomendado", 10, "22 de mayo del 2025");
        user2.aggReseña(nueva2);
        servicio2.aggReseña(nueva2);
        
        Reseñas nueva3 = new Reseñas("metalgex", "metalgex@gmail.com", "Buen servicio pero falta de atencion al cliente", 7, "22 de mayo del 2025");
        user1.aggReseña(nueva3);
        servicio2.aggReseña(nueva3);
        
        Reseñas nueva4 = new Reseñas("LaFuria", "sebasib@gmail.com", "Me gusto mucho y el entrenador es muy bueno", 9.8, "24 de mayo del 2025");
        user3.aggReseña(nueva4);
        servicio3.aggReseña(nueva4);
    }
}
