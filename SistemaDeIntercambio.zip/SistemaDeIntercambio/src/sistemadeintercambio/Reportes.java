package sistemadeintercambio;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
public class Reportes {
    private static Vector<Reporte> historial = new Vector<>();
    
    public static String serviciostipo(Vector<Servicios> servicios) {
        String cadena="";
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy HH:mm", new Locale("es", "ES"));
        LocalDateTime fecha = LocalDateTime.now();
        String fecha2 = fecha.format(formato);
        cadena+="𝗙𝗘𝗖𝗛𝗔: "+fecha2+"\n";
        Vector<String> tipos = new Vector<>();
        tipos.add("Belleza");
        tipos.add("Deportes");
        tipos.add("Educativo");
        tipos.add("Entretenimiento");
        tipos.add("Eventos");
        tipos.add("Mantenimiento y reparacion");
        tipos.add("Produccion y creativos");
        tipos.add("Salud y bienestar");
        for (int i = 0; i < tipos.size(); i++) {
            String tipo = tipos.get(i);
            cadena+="-----------------------------------------------------------------------------------------------\n";
            cadena+=tipo.toUpperCase()+"\n";
            int contador=1;
            for (int j = 0; j < servicios.size(); j++) {
                Servicios actual = servicios.get(j);
                if (actual.getTipo().equalsIgnoreCase(tipo)) {
                    cadena+=contador+"- "+actual.getNombreServicio()+" $"+actual.getPrecio()+"\n";
                    contador++;
                }
            };
        }
        cadena+="-----------------------------------------------------------------------------------------------\n";
        cadena+="                                  ¡𝗥𝗘𝗣𝗢𝗥𝗧𝗘 𝗚𝗘𝗡𝗘𝗥𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!";
        historial.add(new Reporte("Por tipo", fecha, cadena));
        return cadena;
    }
    
    public static String serviciosprecio(Vector<Servicios> servicios) {
        String cadena="";
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy HH:mm", new Locale("es", "ES"));
        LocalDateTime fecha = LocalDateTime.now();
        String fecha2 = fecha.format(formato);
        cadena+="𝗙𝗘𝗖𝗛𝗔: "+fecha2+"\n";
        Vector<Servicios> copia = new Vector<>();
        for (int i = 0; i < servicios.size(); i++) {
            copia.add(servicios.get(i));
        }
        for (int i = 0; i < copia.size()-1; i++) {
            for (int j = 0; j < copia.size()-1-i; j++) {
                if (copia.get(j).getPrecio()>copia.get(j+1).getPrecio()) {
                    Servicios paso = copia.get(j);
                    copia.set(j, copia.get(j+1));
                    copia.set(j+1, paso);
                }
            }
        }
        for (int i = 0; i < copia.size(); i++) {
            Servicios actual = copia.get(i);
            cadena+="-----------------------------------------------------------------------------------------------\n";
            cadena+=(i+1)+"- "+actual.getNombreServicio()+" $"+actual.getPrecio()+" "+actual.getTipo().toUpperCase()+"\n";
        }
        cadena+="-----------------------------------------------------------------------------------------------\n";
        cadena+="                                  ¡𝗥𝗘𝗣𝗢𝗥𝗧𝗘 𝗚𝗘𝗡𝗘𝗥𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!";
        historial.add(new Reporte("Por Precio, Menor a Mayor", fecha, cadena));
        return cadena;
    }
    
    public static String serviciosprecio2(Vector<Servicios> servicios) {
        String cadena="";
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy HH:mm", new Locale("es", "ES"));
        LocalDateTime fecha = LocalDateTime.now();
        String fecha2 = fecha.format(formato);
        cadena+="𝗙𝗘𝗖𝗛𝗔: "+fecha2+"\n";
        Vector<Servicios> copia = new Vector<>();
        for (int i = 0; i < servicios.size(); i++) {
            copia.add(servicios.get(i));
        }
        for (int i = 0; i < copia.size()-1; i++) {
            for (int j = 0; j < copia.size()-1-i; j++) {
                if (copia.get(j).getPrecio()<copia.get(j+1).getPrecio()) {
                    Servicios paso = copia.get(j);
                    copia.set(j, copia.get(j+1));
                    copia.set(j+1, paso);
                }
            }
        }
        for (int i = 0; i < copia.size(); i++) {
            Servicios actual = copia.get(i);
            cadena+="-----------------------------------------------------------------------------------------------\n";
            cadena+=(i+1)+"- "+actual.getNombreServicio()+" $"+actual.getPrecio()+" "+actual.getTipo().toUpperCase()+"\n";
        }
        cadena+="-----------------------------------------------------------------------------------------------\n";
        cadena+="                                  ¡𝗥𝗘𝗣𝗢𝗥𝗧𝗘 𝗚𝗘𝗡𝗘𝗥𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!";
        historial.add(new Reporte(" Por Precio, Mayor a Menor", fecha, cadena));
        return cadena;
    }
    
    public static String serviciosciudad(Vector<Servicios> servicios) {
        String cadena="";
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy HH:mm", new Locale("es", "ES"));
        LocalDateTime fecha = LocalDateTime.now();
        String fecha2 = fecha.format(formato);
        cadena+="𝗙𝗘𝗖𝗛𝗔: "+fecha2+"\n";
        Vector<Servicios> copia = new Vector<>();
        for (int i = 0; i < servicios.size(); i++) {
            copia.add(servicios.get(i));
        }
        for (int i = 0; i < copia.size()-1; i++) {
            for (int j = 0; j < copia.size()-1-i; j++) {
                String ciudad1 = copia.get(j).getCiudadServicio();
                String ciudad2 = copia.get(j+1).getCiudadServicio();
                if (ciudad1.compareToIgnoreCase(ciudad2)>0) {
                    Servicios actual = copia.get(j);
                    copia.set(j, copia.get(j+1));
                    copia.set(j+1, actual);
                }
            }
        }
        String ciudadactual="";
        int contador=0;
        for (int i = 0; i < copia.size(); i++) {
            Servicios actual = copia.get(i);
            if (!actual.getCiudadServicio().equalsIgnoreCase(ciudadactual)) {
                ciudadactual=actual.getCiudadServicio();
                cadena+="-----------------------------------------------------------------------------------------------\n";
                cadena+=ciudadactual.toUpperCase()+"\n";
                contador=1;
            }
            cadena+=contador+"- "+actual.getNombreServicio()+" $"+actual.getPrecio()+" "+actual.getTipo().toUpperCase()+"\n";
            contador++;
        }
        cadena+="-----------------------------------------------------------------------------------------------\n";
        cadena+="                                  ¡𝗥𝗘𝗣𝗢𝗥𝗧𝗘 𝗚𝗘𝗡𝗘𝗥𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!";
        historial.add(new Reporte("Por Ciudad", fecha, cadena));
        return cadena;
    }
    
    public static String servicioscalificacion(Vector<Servicios> servicios) {
        String cadena="";
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy HH:mm", new Locale("es", "ES"));
        LocalDateTime fecha = LocalDateTime.now();
        String fecha2 = fecha.format(formato);
        cadena+="𝗙𝗘𝗖𝗛𝗔: "+fecha2+"\n";
        Vector<Servicios> copia = new Vector<>();
        for (int i = 0; i < servicios.size(); i++) {
            copia.add(servicios.get(i));
        }
        for (int i = 0; i < copia.size()-1; i++) {
            for (int j = 0; j < copia.size()-1-i; j++) {
                double prom1=copia.get(j).promedioservicio();
                double prom2=copia.get(j+1).promedioservicio();
                if (prom1<prom2) {
                    Servicios paso = copia.get(j);
                    copia.set(j, copia.get(j+1));
                    copia.set(j+1, paso);
                }
            }
        }
        for (int i = 0; i < copia.size(); i++) {
            Servicios actual = copia.get(i);
            double promedio = actual.promedioservicio();
            cadena+="-----------------------------------------------------------------------------------------------\n";
            cadena+=(i+1)+"- "+actual.getNombreServicio()+" "+actual.promedioservicio()+" "+actual.getTipo().toUpperCase()+"\n";
        }
        cadena+="-----------------------------------------------------------------------------------------------\n";
        cadena+="                                  ¡𝗥𝗘𝗣𝗢𝗥𝗧𝗘 𝗚𝗘𝗡𝗘𝗥𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!";
        historial.add(new Reporte("Por Calificacion, Mayor a Menor", fecha, cadena));
        return cadena;
    }
    
    public static String serviciocalificacion2(Vector<Servicios> servicios) {
        String cadena="";
        DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd 'de' MMMM 'de' yyyy HH:mm", new Locale("es", "ES"));
        LocalDateTime fecha = LocalDateTime.now();
        String fecha2 = fecha.format(formato);
        cadena+="𝗙𝗘𝗖𝗛𝗔: "+fecha2+"\n";
        Vector<Servicios> copia = new Vector<>();
        for (int i = 0; i < servicios.size(); i++) {
            copia.add(servicios.get(i));
        }
        for (int i = 0; i < copia.size()-1; i++) {
            for (int j = 0; j < copia.size()-1-i; j++) {
                double prom1=copia.get(j).promedioservicio();
                double prom2=copia.get(j+1).promedioservicio();
                if (prom1>prom2) {
                    Servicios paso = copia.get(j);
                    copia.set(j, copia.get(j+1));
                    copia.set(j+1, paso);
                }
            }
        }
        for (int i = 0; i < copia.size(); i++) {
            Servicios actual = copia.get(i);
            double promedio = actual.promedioservicio();
            cadena+="-----------------------------------------------------------------------------------------------\n";
            cadena+=(i+1)+"- "+actual.getNombreServicio()+" "+actual.promedioservicio()+" "+actual.getTipo().toUpperCase()+"\n";
        }
        cadena+="-----------------------------------------------------------------------------------------------\n";
        cadena+="                                  ¡𝗥𝗘𝗣𝗢𝗥𝗧𝗘 𝗚𝗘𝗡𝗘𝗥𝗔𝗗𝗢 𝗖𝗢𝗡 𝗘𝗫𝗜𝗧𝗢!";
        historial.add(new Reporte("Por Calificacion, Menor a Mayor", fecha, cadena));
        return cadena;
    }
    
    public static String viewhistorial() {
        String cadena="";
        if (historial.isEmpty()) {
            cadena="No hay reportes generados";
        } else {
            cadena+="===============================================================================================\n"
                    + "                                     𝗛𝗜𝗦𝗧𝗢𝗥𝗜𝗔𝗟 𝗗𝗘 𝗥𝗘𝗣𝗢𝗥𝗧𝗘𝗦\n"
                    + "===============================================================================================\n";
            DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
            for (int i = 0; i < historial.size(); i++) {
                Reporte actual = historial.get(i);
                cadena+=(i+1)+"- "+actual.getTipo()+" "+actual.getFecha().format(formato)+"\n";
            }
        }
        cadena+="-----------------------------------------------------------------------------------------------";
        return cadena;
    }
    
    public static String viewreporte(int i) {
        String cadena="";
        if (i>=0 && i<historial.size()) {
            cadena=historial.get(i).getContenido();
        } else {
            cadena="Opcion invalida";
        }
        return cadena;
    }
}