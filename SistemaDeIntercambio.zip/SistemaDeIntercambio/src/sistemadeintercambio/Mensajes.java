package sistemadeintercambio;
import java.util.*;
public class Mensajes {
    private String fecha;
    private String contenido;

    public Mensajes(String fecha, String contenido) {
        this.fecha = fecha;
        this.contenido = contenido;
    }
    
    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getContenido() {
        return contenido;
    }

    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
    
    public String viewmsg() {
        String cadena="";
        cadena+=getContenido();
        return cadena;
    }  
}
