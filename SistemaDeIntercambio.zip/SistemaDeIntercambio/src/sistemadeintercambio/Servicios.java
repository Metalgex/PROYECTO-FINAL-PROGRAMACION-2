package sistemadeintercambio;
import java.util.*;
import Servicios.Belleza;
import Servicios.Deportes;
import Servicios.Educativo;
import Servicios.Entretenimiento;
import Servicios.Eventos;
import Servicios.MYR;
import Servicios.Produccion;
import Servicios.Salud;
public class Servicios {
    public static Vector<Servicios> generales = new Vector<>();
    protected Vector<Reseñas> reseñas = new Vector<>();
    //Basico
    private String nombreServicio;
    private String descripcion;
    private double precio;
    private String tipo;
    //Ubicacion
    private String calleServicio;
    private String ciudadServicio;
    private String estadoServicio;
    private String numeroServicio;
    private String cpServicio;
    private String coordenadas;
    //Adicional
    private String recomendaciones;
    private String horario;
    private String edad;

    public Servicios(String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad) {
        this.nombreServicio = nombreServicio;
        this.descripcion = descripcion;
        this.precio = precio;
        this.tipo = tipo;
        this.calleServicio = calleServicio;
        this.ciudadServicio = ciudadServicio;
        this.estadoServicio = estadoServicio;
        this.numeroServicio = numeroServicio;
        this.cpServicio = cpServicio;
        this.coordenadas = coordenadas;
        this.recomendaciones = recomendaciones;
        this.horario = horario;
        this.edad = edad;
    }
    
    
    public void modificacion(String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad) {
        this.nombreServicio = nombreServicio;
        this.descripcion = descripcion;
        this.precio = precio;
        this.tipo = tipo;
        this.calleServicio = calleServicio;
        this.ciudadServicio = ciudadServicio;
        this.estadoServicio = estadoServicio;
        this.numeroServicio = numeroServicio;
        this.cpServicio = cpServicio;
        this.coordenadas = coordenadas;
        this.recomendaciones = recomendaciones;
        this.horario = horario;
        this.edad = edad;
    }
    
    
    public static void aggServicios(Servicios i) {
        generales.add(i);
    }
    
    public static Vector<Servicios> getServiciosGenerales() {
        return generales;
    }
    
    public void aggReseña(Reseñas i) {
        reseñas.add(i);
    }
    
    public Vector<Reseñas> getReseñas() {
        return reseñas;
    }

    public String getNombreServicio() {
        return nombreServicio;
    }

    public void setNombreServicio(String nombreServicio) {
        this.nombreServicio = nombreServicio;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCalleServicio() {
        return calleServicio;
    }

    public void setCalleServicio(String calleServicio) {
        this.calleServicio = calleServicio;
    }

    public String getCiudadServicio() {
        return ciudadServicio;
    }

    public void setCiudadServicio(String ciudadServicio) {
        this.ciudadServicio = ciudadServicio;
    }

    public String getEstadoServicio() {
        return estadoServicio;
    }

    public void setEstadoServicio(String estadoServicio) {
        this.estadoServicio = estadoServicio;
    }

    public String getNumeroServicio() {
        return numeroServicio;
    }

    public void setNumeroServicio(String numeroServicio) {
        this.numeroServicio = numeroServicio;
    }

    public String getCpServicio() {
        return cpServicio;
    }

    public void setCpServicio(String cpServicio) {
        this.cpServicio = cpServicio;
    }

    public String getCoordenadas() {
        return coordenadas;
    }

    public void setCoordenadas(String coordenadas) {
        this.coordenadas = coordenadas;
    }

    public String getRecomendaciones() {
        return recomendaciones;
    }

    public void setRecomendaciones(String recomendaciones) {
        this.recomendaciones = recomendaciones;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getEdad() {
        return edad;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }
    
    public static void deleteservice(Servicios deleted) {
        Servicios.getServiciosGenerales().remove(deleted);
        if (deleted instanceof Belleza) {
            Belleza.getBellezas().remove(deleted);
        }
        else if (deleted instanceof Deportes) {
            Deportes.getDeportes().remove(deleted);
        }
        else if (deleted instanceof Educativo) {
            Educativo.getEducativos().remove(deleted);
        }
        else if (deleted instanceof Entretenimiento) {
            Entretenimiento.getShows().remove(deleted);
        }
        else if (deleted instanceof Eventos) {
            Eventos.getEventos().remove(deleted);
        }
        else if (deleted instanceof MYR) {
            MYR.getMyr().remove(deleted);
        }
        else if (deleted instanceof Produccion) {
            Produccion.getProducciones().remove(deleted);
        }
        else if (deleted instanceof Salud) {
            Salud.getSalud().remove(deleted);
        }
    }
    
    public String InfoReseñas() {
        String cadena="";
        cadena="===============================================================================================\n";
        cadena+="                                     𝗢𝗣𝗜𝗡𝗜𝗢𝗡𝗘𝗦 𝗗𝗘 𝗟𝗢𝗦 𝗖𝗟𝗜𝗘𝗡𝗧𝗘𝗦\n";
        cadena+="-----------------------------------------------------------------------------------------------\n";
        if (reseñas.isEmpty()) {
            cadena+="Aun no hay reseñas";
        } else {
            for (int i = 0; i < reseñas.size(); i++) {
                Reseñas review = reseñas.get(i);
                cadena+=review.getUsuarioR().toUpperCase()+" - "+review.getCorreoR()
                        + "\n"+review.getFechaReseña()
                        + "\n𝗖𝗔𝗟𝗜𝗙𝗜𝗖𝗔𝗖𝗜𝗢𝗡: "+review.getCalificacion()
                        + "\n"+review.getComentario();
            }
        }
        return cadena;
    }
    
    public String InfoAll() {
        String cadena="";
        cadena="==============================================================================================="
                + "\n                                      𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗕𝗔𝗦𝗜𝗖𝗔"
                + "\n-----------------------------------------------------------------------------------------------"
                + "\n"+getNombreServicio().toUpperCase()
                + "\n"+getDescripcion()
                + "\n𝗣𝗥𝗘𝗖𝗜𝗢 𝗣𝗢𝗥 𝗛𝗢𝗥𝗔: "+getPrecio()
                + "\n𝗖𝗔𝗧𝗘𝗚𝗢𝗥𝗜𝗔: "+getTipo()
                + "\n==============================================================================================="
                + "\n                                          𝗨𝗕𝗜𝗖𝗔𝗖𝗜𝗢𝗡"
                + "\n-----------------------------------------------------------------------------------------------"
                + "\n"+getCalleServicio()+" #"+getNumeroServicio()
                + "\n"+getCiudadServicio()+" "+getEstadoServicio()
                + "\n𝗖.𝗣."+getCpServicio()+" 𝗖𝗢𝗢𝗥𝗗𝗘𝗡𝗔𝗗𝗔𝗦: "+getCoordenadas()
                + "\n==============================================================================================="
                + "\n                                       𝗥𝗘𝗖𝗢𝗠𝗘𝗡𝗗𝗔𝗖𝗜𝗢𝗡𝗘𝗦"
                + "\n-----------------------------------------------------------------------------------------------"
                + "\n"+getRecomendaciones()
                + "\n𝗘𝗗𝗔𝗗 𝗥𝗘𝗖𝗢𝗠𝗘𝗡𝗗𝗔𝗗𝗔: "+getEdad()
                + "\n𝗛𝗢𝗥𝗔𝗥𝗜𝗢 𝗥𝗘𝗖𝗢𝗠𝗘𝗡𝗗𝗔𝗗𝗢: "+getHorario();
        return cadena;
    }
    
    public static String viewServicios() {
        String cadena="";
        cadena+="===============================================================================================\n";
        cadena+="                                    𝗧𝗢𝗗𝗢𝗦 𝗟𝗢𝗦 𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢𝗦\n";
        cadena+="-----------------------------------------------------------------------------------------------\n";
        if (generales.isEmpty()) {
            cadena+="No hay servicios registrados";
        } else {
            for (int i = 0; i < generales.size(); i++) {
                Servicios service = generales.get(i);
                cadena+=(i+1)+"- "+service.getNombreServicio()+" $"+service.getPrecio()+" "+service.getTipo()+"\n";
            }
            cadena+="===============================================================================================";
        }
        return cadena;
    }
    
    public String viewServicioAlone() {
        String cadena="";
        cadena=getNombreServicio().toUpperCase()+" $"+getPrecio();
        return cadena;
    }
    
    public double promedioservicio() {
        double suma=0, promedio=0;
        if (reseñas.size()==0) {
            promedio=0;
        }
        for (int i = 0; i < reseñas.size(); i++) {
            suma+=reseñas.get(i).getCalificacion();
            promedio=suma/reseñas.size();
        }
        return promedio;
    }
}
