package sistemadeintercambio;
public class Reseñas {
    private String usuarioR;
    private String correoR;
    private String comentario;
    private double calificacion;
    private String fechaReseña;

    public Reseñas(String usuarioR, String correoR, String comentario, double calificacion, String fechaReseña) {
        this.usuarioR = usuarioR;
        this.correoR = correoR;
        this.comentario = comentario;
        this.calificacion = calificacion;
        this.fechaReseña = fechaReseña;
    }

    public String getUsuarioR() {
        return usuarioR;
    }

    public void setUsuarioR(String usuarioR) {
        this.usuarioR = usuarioR;
    }

    public String getCorreoR() {
        return correoR;
    }

    public void setCorreoR(String correoR) {
        this.correoR = correoR;
    }

    public String getComentario() {
        return comentario;
    }

    public void setComentario(String comentario) {
        this.comentario = comentario;
    }

    public double getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(double calificacion) {
        this.calificacion = calificacion;
    }

    public String getFechaReseña() {
        return fechaReseña;
    }

    public void setFechaReseña(String fechaReseña) {
        this.fechaReseña = fechaReseña;
    }
}
