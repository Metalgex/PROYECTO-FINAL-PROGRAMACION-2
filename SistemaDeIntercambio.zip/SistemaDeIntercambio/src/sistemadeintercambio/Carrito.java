package sistemadeintercambio;
import java.util.*;
import java.time.LocalDateTime;
public class Carrito {
    private Vector<Citas> carrito = new Vector<>();
    private double total;

    public Carrito() {
    }

    public Vector<Citas> getCarrito() {
        return carrito;
    }

    public void setCarrito(Vector<Citas> carrito) {
        this.carrito = carrito;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }
    
    public void aggcita(Citas cita) {
        carrito.add(cita);
        total+=cita.getSubtotal();
    }
    
    public String viewcarrito() {
        String cadena="";
        if (carrito.isEmpty()) {
            cadena="             ¡EL CARRITO ESTA VACIO!";
        } else {
            total=0;
            for (int i = 0; i < carrito.size(); i++) {
                Citas cita = carrito.get(i);
                cadena+=(i+1)+"- "+cita.InfoAll()+"\n";
                total+=cita.getSubtotal();
            }
            cadena+="\nTotal a pagar: "+total;
        }
        return cadena;
    }
    
    public void vaciarcarrito() {
        carrito.clear();
        total=0;
    } 
    
    public String pagarcarrito(Usuario user) {
        String cadena="";
        if (carrito.isEmpty()) {
            cadena="             ¡EL CARRITO ESTA VACIO!";
        } else {
            double totalfinal=0;
            for (int i = 0; i < carrito.size(); i++) {
                Citas cita = carrito.get(i);
                totalfinal+=cita.getServicio().getPrecio()*cita.getHoras();
            }
            if (user.getSaldo()<totalfinal) {
                cadena+="               ¡SALDO INSUFICIENTE!";
            }
            else {
                user.setSaldo(user.getSaldo()-totalfinal);
                for (int i = 0; i < carrito.size(); i++) {
                    user.getComprados().add(carrito.get(i));
                }
                cadena+="                 ¡COMPRA EXITOSA!";
                for (int i = 0; i < carrito.size(); i++) {
                    Citas cita =carrito.get(i);
                    cadena+="\n"+cita.InfoAll();
                }
                vaciarcarrito();
            }
        }
        return cadena;
    }
}
