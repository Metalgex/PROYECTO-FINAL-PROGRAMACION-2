package Servicios;
import java.util.*;
import sistemadeintercambio.Servicios;
public class MYR extends Servicios {
    private static Vector<MYR> myr = new Vector<>();
    
    private String tipomyr;
    private String garantia;
    private String materialmyr;

    public MYR(String tipomyr, String garantia, String materialmyr, String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad) {
        super(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
        this.tipomyr = tipomyr;
        this.garantia = garantia;
        this.materialmyr = materialmyr;
    }
    
    public void modificacionMYR(String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad, String tipomyr, String garantia, String materialmyr) {
        this.setNombreServicio(nombreServicio);
        this.setDescripcion(descripcion);
        this.setPrecio(precio);
        this.setTipo(tipo);
        this.setCalleServicio(calleServicio);
        this.setCiudadServicio(ciudadServicio);
        this.setEstadoServicio(estadoServicio);
        this.setNumeroServicio(numeroServicio);
        this.setCpServicio(cpServicio);
        this.setCoordenadas(coordenadas);
        this.setRecomendaciones(recomendaciones);
        this.setHorario(horario);
        this.setEdad(edad);
        this.tipomyr = tipomyr;
        this.garantia = garantia;
        this.materialmyr = materialmyr;
    }
    
    public static void Predeterminados() {
        MYR s1 = new MYR("Plomero", "3 meses", "Herramientas necesarios", "Servicio de plomeria", "Tienes fugas de agua o problemas con tus tuberias, contrata ya!", 80, "Mantenimiento y reparacion", "Jalisco", "Monclova", "Coahuila", "3252", "23523", "436434.346.346", "Tener en cuenta la duracion aproximada de la reparacion al comprar las horas", "Tarde", "21-30");
        MYR s2 = new MYR("Carpintero", "6 meses", "Mueble a reparar", "Servicio de carpinteria", "Tienes muebles rotos y no sabes que hacer, nosotros los reparamos", 90, "Mantenimiento y reparacion", "Sinaloa", "Frontera", "Coahuila", "5476", "78956", "3263.3463.235", "Tener en cuenta que el costo es aprocimadamente 1 hora", "Mañana", "21-30");
        myr.add(s2);
        myr.add(s1);
        Servicios.generales.add(s2);
        Servicios.generales.add(s1);
    }

    public static Vector<MYR> getMyr() {
        return myr;
    }

    public static void aggMyr(MYR i) {
        myr.add(i);
    }

    public String getTipomyr() {
        return tipomyr;
    }

    public void setTipomyr(String tipomyr) {
        this.tipomyr = tipomyr;
    }

    public String getGarantia() {
        return garantia;
    }

    public void setGarantia(String garantia) {
        this.garantia = garantia;
    }

    public String getMaterialmyr() {
        return materialmyr;
    }

    public void setMaterialmyr(String materialmyr) {
        this.materialmyr = materialmyr;
    }
    
    public String InfoMYR() {
        String cadena="";
        cadena+=InfoAll()
                + "\n==============================================================================================="
                + "\n                                   𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟"
                + "\n-----------------------------------------------------------------------------------------------"
                + "\n𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: "+getTipomyr()
                + "\n𝗚𝗔𝗥𝗔𝗡𝗧𝗜𝗔: "+getGarantia()
                + "\n𝗠𝗔𝗧𝗘𝗥𝗜𝗔𝗟 "+getMaterialmyr();
        return cadena;
    }
    
    public static String viewMYR() {
        String cadena="";
        if (myr.isEmpty()) {
            cadena="No hay servicios registrados";
        } else {
            for (int i = 0; i < myr.size(); i++) {
            MYR service = myr.get(i);
            cadena+=(i+1)+"- "+service.getNombreServicio()+" $"+service.getPrecio()+"\n";
        }
            cadena+="===============================================================================================";
        }
        return cadena;
    }
}
