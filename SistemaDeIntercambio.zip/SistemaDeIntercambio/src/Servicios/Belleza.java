package Servicios;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.*;
import sistemadeintercambio.Reseñas;
import sistemadeintercambio.Servicios;
import sistemadeintercambio.Usuario;
public class Belleza extends Servicios {
    private static Vector<Belleza> belleza = new Vector<>();
    
    private String tipoBelleza;
    private String materialBelleza;
    private String lugarBelleza;

    public Belleza(String tipoBelleza, String materialBelleza, String lugarBelleza, String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad, Usuario user) {
        super(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, user);
        this.tipoBelleza = tipoBelleza;
        this.materialBelleza = materialBelleza;
        this.lugarBelleza = lugarBelleza;
    }
    
    public static void predeterminados() {
        Usuario user1 = Usuario.getnombreuser("LaFuria");
        Usuario user2 = Usuario.getnombreuser("anaas");
        Belleza s1= (new Belleza("Uñas", "Referencias y uñas limpias", "Domicilio", "Uñas acrilicas", "Hermosas uñas acrilicas del diseño que gustes a domicilio!!", 70, "Belleza", "Hipodromo", "Frontera", "Coahuila", "19223", "256732", "4235.345.3245", "Tener las uñas limpias al momento de la cita", "Tarde", "21-30", user1));
        Belleza s2= (new Belleza("Cabello", "Referencias y cabello lavado", "Domicilio", "Tintes de pelo", "Se hacen todo tipo de tintes incluyendo decoloraciones", 70, "Belleza", "Irapuato", "Monclova", "Coahuila", "132423", "234213", "234.2341.234", "Estar 10 minutos antes de la cita", "Mañana", "21-30", user2));
        belleza.add(s1);
        belleza.add(s2);
        Servicios.generales.add(s1);
        Servicios.generales.add(s2);
        user1.publicar(s1);
        user2.publicar(s2);
    }
    
    public void modificacionBelleza(String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad, String tipoBelleza, String materialBelleza, String lugarBelleza) {
        this.setNombreServicio(nombreServicio);
        this.setDescripcion(descripcion);
        this.setPrecio(precio);
        this.setTipo(tipo);
        this.setCalleServicio(calleServicio);
        this.setCiudadServicio(ciudadServicio);
        this.setEstadoServicio(estadoServicio);
        this.setNumeroServicio(numeroServicio);
        this.setCpServicio(cpServicio);
        this.setCoordenadas(coordenadas);
        this.setRecomendaciones(recomendaciones);
        this.setHorario(horario);
        this.setEdad(edad);
        this.tipoBelleza = tipoBelleza;
        this.materialBelleza = materialBelleza;
        this.lugarBelleza = lugarBelleza;
    }
    
    public static Vector<Belleza> getBellezas() {
        return belleza;
    }

    public static void aggBelleza(Belleza i) {
        belleza.add(i);
    }

    public String getTipoBelleza() {
        return tipoBelleza;
    }

    public void setTipoBelleza(String tipoBelleza) {
        this.tipoBelleza = tipoBelleza;
    }

    public String getMaterialBelleza() {
        return materialBelleza;
    }

    public void setMaterialBelleza(String materialBelleza) {
        this.materialBelleza = materialBelleza;
    }

    public String getLugarBelleza() {
        return lugarBelleza;
    }

    public void setLugarBelleza(String lugarBelleza) {
        this.lugarBelleza = lugarBelleza;
    }
    
    public String InfoBelleza() {
        String cadena="";
        cadena+=InfoAll()
                + "\n==============================================================================================="
                + "\n                                   𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟"
                + "\n-----------------------------------------------------------------------------------------------"
                + "\n𝗦𝗘𝗥𝗩𝗜𝗖𝗜𝗢: "+getTipoBelleza()
                + "\n𝗠𝗔𝗧𝗘𝗥𝗜𝗔𝗟: "+getMaterialBelleza()
                + "\n𝗟𝗢𝗖𝗔𝗖𝗜𝗢𝗡: "+getLugarBelleza();
        return cadena;
    }
    
    public static String viewBelleza() {
        String cadena="";
        if (belleza.isEmpty()) {
            cadena="No hay servicios registrados";
        }
        else {
           for (int i = 0; i < belleza.size(); i++) {
                Belleza servicio = belleza.get(i);
                cadena+=(i+1)+"- "+servicio.getNombreServicio()+" $"+servicio.getPrecio()+"\n";
            } 
           cadena+="===============================================================================================";
        }
        return cadena;
    }
    public String InfoReseñas() {
        String cadena="";
        cadena="===============================================================================================\n";
        cadena+="                                   𝗢𝗣𝗜𝗡𝗜𝗢𝗡𝗘𝗦 𝗗𝗘 𝗟𝗢𝗦 𝗖𝗟𝗜𝗘𝗡𝗧𝗘𝗦\n";
        cadena+="-----------------------------------------------------------------------------------------------\n";
        if (reseñas.isEmpty()) {
            cadena+="Aun no hay reseñas";
        } else {
            for (int i = 0; i < reseñas.size(); i++) {
                Reseñas review = reseñas.get(i);
                cadena+=review.getUsuarioR().toUpperCase()+" - "+review.getCorreoR()
                        + "\n"+review.getFechaReseña()
                        + "\n𝗖𝗔𝗟𝗜𝗙𝗜𝗖𝗔𝗖𝗜𝗢𝗡: "+review.getCalificacion()
                        + "\n"+review.getComentario();
                cadena+="\n-----------------------------------------------------------------------------------------------\n";
            }
        }
        return cadena;
    }
}
