package Servicios;
import java.time.LocalDate;
import java.util.*;
import sistemadeintercambio.Servicios;
import sistemadeintercambio.Usuario;
public class Deportes extends Servicios {
    private static Vector<Deportes> deportes = new Vector<>();
    
    private String tipoDeporte;
    private String materialDeporte;
    private String nivelDeporte;
    private String lugarDeporte;

    public Deportes(String tipoDeporte, String materialDeporte, String nivelDeporte, String lugarDeporte, String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad, Usuario user) {
        super(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, user);
        this.tipoDeporte = tipoDeporte;
        this.materialDeporte = materialDeporte;
        this.nivelDeporte = nivelDeporte;
        this.lugarDeporte = lugarDeporte;
    }
    
    public void modificacionDeportes(String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad, String tipoDeporte, String materialDeporte, String nivelDeporte, String lugarDeporte) {
        this.setNombreServicio(nombreServicio);
        this.setDescripcion(descripcion);
        this.setPrecio(precio);
        this.setTipo(tipo);
        this.setCalleServicio(calleServicio);
        this.setCiudadServicio(ciudadServicio);
        this.setEstadoServicio(estadoServicio);
        this.setNumeroServicio(numeroServicio);
        this.setCpServicio(cpServicio);
        this.setCoordenadas(coordenadas);
        this.setRecomendaciones(recomendaciones);
        this.setHorario(horario);
        this.setEdad(edad);
        this.tipoDeporte = tipoDeporte;
        this.materialDeporte = materialDeporte;
        this.nivelDeporte = nivelDeporte;
        this.lugarDeporte = lugarDeporte;
    }
    
    public static void predeterminados() {
        Usuario user1 = Usuario.getnombreuser("AgateAura");
        Usuario user2 = Usuario.getnombreuser("metalgex");
        Deportes s1 = (new Deportes("Yoga", "Mat para yoga y agua", "Principiante", "Local YOGAMAT", "Clases de yoga", "Unete a las clases de yoga grupales", 100, "Deportes", "Sinerelo", "Frontera", "Coahuila", "32422", "23958", "34563.235467.453", "Traer ropa comoda", "Mañana", "21-30", user1));
        Deportes s2 = (new Deportes("Basketball", "Tenis para basketball", "Principiante", "Gimnasio Adolfo", "Clases de basketball", "Unete a las clases de basketball para niños", 80, "Deportes", "Americas", "Monclova", "Coahuila", "43623", "457634", "54834.4348953.4353", "Estar puntual a las clases", "Tarde", "11-20", user2));
        deportes.add(s1);
        deportes.add(s2);
        Servicios.generales.add(s2);
        Servicios.generales.add(s1);
        user1.publicar(s1);
        user2.publicar(s2);
    }

    public static Vector<Deportes> getDeportes() {
        return deportes;
    }

    public static void aggDeportes(Deportes i) {
        deportes.add(i);
    }

    public String getTipoDeporte() {
        return tipoDeporte;
    }

    public void setTipoDeporte(String tipoDeporte) {
        this.tipoDeporte = tipoDeporte;
    }

    public String getMaterialDeporte() {
        return materialDeporte;
    }

    public void setMaterialDeporte(String materialDeporte) {
        this.materialDeporte = materialDeporte;
    }

    public String getNivelDeporte() {
        return nivelDeporte;
    }

    public void setNivelDeporte(String nivelDeporte) {
        this.nivelDeporte = nivelDeporte;
    }

    public String getLugarDeporte() {
        return lugarDeporte;
    }

    public void setLugarDeporte(String lugarDeporte) {
        this.lugarDeporte = lugarDeporte;
    }
    
    public String InfoDeportes() {
        String cadena="";
        cadena+=InfoAll()
                + "\n==============================================================================================="
                + "\n                                   𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟"
                + "\n-----------------------------------------------------------------------------------------------"
                + "\n𝗗𝗘𝗣𝗢𝗥𝗧𝗘: "+getTipoDeporte()
                + "\n𝗠𝗔𝗧𝗘𝗥𝗜𝗔𝗟: "+getMaterialDeporte()
                + "\n𝗗𝗜𝗙𝗜𝗖𝗨𝗟𝗧𝗔𝗗: "+getNivelDeporte()
                + "\n𝗟𝗢𝗖𝗔𝗖𝗜𝗢𝗡: "+getLugarDeporte();
        return cadena;
    }
    
    public static String viewDeporte() {
        String cadena="";
        if (deportes.isEmpty()) {
            cadena="No hay servicios registrados";
        } else {
            for (int i = 0; i < deportes.size(); i++) {
            Deportes service = deportes.get(i);
            cadena+=(i+1)+"- "+service.getNombreServicio()+" $"+service.getPrecio()+"\n";
        }
            cadena+="===============================================================================================";
        }
        return cadena;
    }
}
