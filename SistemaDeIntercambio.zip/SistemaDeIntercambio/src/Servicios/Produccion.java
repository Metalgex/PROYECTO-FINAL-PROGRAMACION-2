package Servicios;
import java.util.*;
import sistemadeintercambio.Servicios;
public class Produccion extends Servicios {
    private static Vector<Produccion> producciones = new Vector<>();
    
    private String Proyecto;
    private String formato;
    private String requisitosProdu;
    private String usocomercial;
    private String Copyright;

    public Produccion(String Proyecto, String formato, String requisitosProdu, String usocomercial, String Copyright, String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad) {
        super(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
        this.Proyecto = Proyecto;
        this.formato = formato;
        this.requisitosProdu = requisitosProdu;
        this.usocomercial = usocomercial;
        this.Copyright = Copyright;
    }
    
    public void modificacionProdu(String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad, String Proyecto, String formato, String requisitosProdu, String usocomercial, String Copyright) {
        this.setNombreServicio(nombreServicio);
        this.setDescripcion(descripcion);
        this.setPrecio(precio);
        this.setTipo(tipo);
        this.setCalleServicio(calleServicio);
        this.setCiudadServicio(ciudadServicio);
        this.setEstadoServicio(estadoServicio);
        this.setNumeroServicio(numeroServicio);
        this.setCpServicio(cpServicio);
        this.setCoordenadas(coordenadas);
        this.setRecomendaciones(recomendaciones);
        this.setHorario(horario);
        this.setEdad(edad);
        this.Proyecto = Proyecto;
        this.formato = formato;
        this.requisitosProdu = requisitosProdu;
        this.usocomercial = usocomercial;
        this.Copyright = Copyright;
    }
    
    public static void Predeterminados() {
        Produccion s1 = new Produccion("Diseño grafico", "Jpg, Png, PDF", "Referencias y paleta de colores", "No", "Crative commons", "Diseño de logos para empresas", "¿Necesitas un logo para tu negocio o empresa? Nosotros te lo elaboramos", 80, "Produccion y creativos", "Lomas", "Frontera", "Coahuila", "4353", "23523", "5435.5643.356", "Tener en cuenta que la duracion aproximada es de 2 horas", "Mañana", "21-30");
        Produccion s2 = new Produccion("Diseño de marca", "Jpg, Png, PDF", "Referencias y paleta de colores de la marca", "Si", "Creative commons", "Diseño de marca para negocios", "Hacemos diseño de marcas a empresas o negocios personalizadas", 100, "Produccion y creativos", "Roma", "Monclova", "Coahuila", "45643", "54753", "8977.657.5463", "Tener en cuenta que la duracion aproximada es 24 horas debido a que se deb investigar el mercado", "Mañana", "31-40");
        producciones.add(s2);
        Servicios.generales.add(s2);
        producciones.add(s1);
        Servicios.generales.add(s1);
    }

    public static Vector<Produccion> getProducciones() {
        return producciones;
    }

    public static void aggProducciones(Produccion i) {
        producciones.add(i);
    }

    public String getProyecto() {
        return Proyecto;
    }

    public void setProyecto(String Proyecto) {
        this.Proyecto = Proyecto;
    }

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    public String getRequisitosProdu() {
        return requisitosProdu;
    }

    public void setRequisitosProdu(String requisitosProdu) {
        this.requisitosProdu = requisitosProdu;
    }

    public String getUsocomercial() {
        return usocomercial;
    }

    public void setUsocomercial(String usocomercial) {
        this.usocomercial = usocomercial;
    }

    public String getCopyright() {
        return Copyright;
    }

    public void setCopyright(String Copyright) {
        this.Copyright = Copyright;
    }
    
    public String InfoProduccion() {
        String cadena="";
        cadena+=InfoAll()
                + "\n===============INFORMACION ADICIONAL================"
                + "\nServicio: "+getProyecto()
                + "\nFormato de entrega: "+getFormato()
                + "\nRequisitos: "+getRequisitosProdu()
                + "\nUso comercial: "+getUsocomercial()
                + "\nLicecncia de derechos: "+getCopyright();
        return cadena;
    }
    
    public static String viewProdu() {
        String cadena="";
        cadena+="================PRODUCCION Y CREATIVOS==============\n";
        if (producciones.isEmpty()) {
            cadena="No hay servicios registrados";
        } else {
            for (int i = 0; i < producciones.size(); i++) {
            Produccion service = producciones.get(i);
            cadena+=(i+1)+"- "+service.getNombreServicio()+" $"+service.getPrecio()+"\n";
        }
        }
        return cadena;
    }
}
