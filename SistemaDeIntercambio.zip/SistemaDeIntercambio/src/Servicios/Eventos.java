package Servicios;
import java.util.*;
import sistemadeintercambio.Servicios;
public class Eventos extends Servicios {
    private static Vector<Eventos> eventos = new Vector<>();
    
    private String tipoEvento;
    private String capacidadEvento;
    private String lugarEvento;
    private String paquetesEvento;

    public Eventos(String tipoEvento, String capacidadEvento, String lugarEvento, String paquetesEvento, String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad) {
        super(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
        this.tipoEvento = tipoEvento;
        this.capacidadEvento = capacidadEvento;
        this.lugarEvento = lugarEvento;
        this.paquetesEvento = paquetesEvento;
    }
    
    public void modificacionEventos(String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad, String tipoEvento, String capacidadEvento, String lugarEvento, String paquetesEvento) {
        this.setNombreServicio(nombreServicio);
        this.setDescripcion(descripcion);
        this.setPrecio(precio);
        this.setTipo(tipo);
        this.setCalleServicio(calleServicio);
        this.setCiudadServicio(ciudadServicio);
        this.setEstadoServicio(estadoServicio);
        this.setNumeroServicio(numeroServicio);
        this.setCpServicio(cpServicio);
        this.setCoordenadas(coordenadas);
        this.setRecomendaciones(recomendaciones);
        this.setHorario(horario);
        this.setEdad(edad);
        this.tipoEvento = tipoEvento;
        this.capacidadEvento = capacidadEvento;
        this.lugarEvento = lugarEvento;
        this.paquetesEvento = paquetesEvento;
    }

    public static Vector<Eventos> getEventos() {
        return eventos;
    }

    public static void aggEventos(Eventos i) {
        eventos.add(i);
    }

    public String getTipoEvento() {
        return tipoEvento;
    }

    public void setTipoEvento(String tipoEvento) {
        this.tipoEvento = tipoEvento;
    }

    public String getCapacidadEvento() {
        return capacidadEvento;
    }

    public void setCapacidadEvento(String capacidadEvento) {
        this.capacidadEvento = capacidadEvento;
    }

    public String getLugarEvento() {
        return lugarEvento;
    }

    public void setLugarEvento(String lugarEvento) {
        this.lugarEvento = lugarEvento;
    }

    public String getPaquetesEvento() {
        return paquetesEvento;
    }

    public void setPaquetesEvento(String paquetesEvento) {
        this.paquetesEvento = paquetesEvento;
    }
    
    public String InfoEventos() {
        String cadena="";
        cadena+=InfoAll()
                + "\n===============INFORMACION ADICIONAL================"
                + "\nEvento: "+getTipoEvento()
                + "\nCapacidad: "+getCapacidadEvento()
                + "\nLocacion: "+getLugarEvento()
                + "\nPaquetes: "+getPaquetesEvento();
        return cadena;
    }
    
    public static String viewEventos() {
        String cadena="";
        cadena+="======================EVENTOS=======================\n";
        if (eventos.isEmpty()) {
            cadena="No hay servicios resgistrados";
        } else {
            for (int i = 0; i < eventos.size(); i++) {
            Eventos service = eventos.get(i);
            cadena+=(i+1)+"- "+service.getNombreServicio()+" $"+service.getPrecio()+"\n";
        }
        }
        return cadena;
    }
}
