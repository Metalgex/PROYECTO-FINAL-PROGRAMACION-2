package Servicios;
import java.util.*;
import sistemadeintercambio.Servicios;
import sistemadeintercambio.Usuario;
public class Eventos extends Servicios {
    private static Vector<Eventos> eventos = new Vector<>();
    
    private String tipoEvento;
    private String capacidadEvento;
    private String lugarEvento;
    private String paquetesEvento;

    public Eventos(String tipoEvento, String capacidadEvento, String lugarEvento, String paquetesEvento, String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad, Usuario user) {
        super(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad, user);
        this.tipoEvento = tipoEvento;
        this.capacidadEvento = capacidadEvento;
        this.lugarEvento = lugarEvento;
        this.paquetesEvento = paquetesEvento;
    }
    
    public void modificacionEventos(String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad, String tipoEvento, String capacidadEvento, String lugarEvento, String paquetesEvento) {
        this.setNombreServicio(nombreServicio);
        this.setDescripcion(descripcion);
        this.setPrecio(precio);
        this.setTipo(tipo);
        this.setCalleServicio(calleServicio);
        this.setCiudadServicio(ciudadServicio);
        this.setEstadoServicio(estadoServicio);
        this.setNumeroServicio(numeroServicio);
        this.setCpServicio(cpServicio);
        this.setCoordenadas(coordenadas);
        this.setRecomendaciones(recomendaciones);
        this.setHorario(horario);
        this.setEdad(edad);
        this.tipoEvento = tipoEvento;
        this.capacidadEvento = capacidadEvento;
        this.lugarEvento = lugarEvento;
        this.paquetesEvento = paquetesEvento;
    }
    
    public static void Predeterinados() {
        Usuario user1 = Usuario.getnombreuser("anaas");
        Usuario user2 = Usuario.getnombreuser("LaFuria");
        Eventos s1 = (new Eventos("Salon para bodas", "100 personas", "Paris Eventos", "1- Solo salon, 2- Todo incluido", "Renta de salon para bodas", "Se renta salon para bodas y quinceañeras", 300, "Eventos", "Magnolia", "Castaños", "Coahuila", "3252", "32523", "435234.1234.2341", "Tener en cuenta el paquete que desea contratar no habra devoluciones", "Noche", "11-20", user1));
        Eventos s2 = (new Eventos("Salon para convenciones", "200 personas", "Seccion 288", "1- Sin expositores, 2- Con expositores", "Renta de seccion 288", "Se renta seccion 288 para todo tipo de convenciones", 200, "Eventos", "Acapulco", "Frontera", "Coahuila", "3252", "43522", "324.2342.234", "La seccion 288 no se hace responsable de accidentes dentro de los eventos", "Tarde", "21-30", user2));
        eventos.add(s2);
        Servicios.generales.add(s2);
        eventos.add(s1);
        Servicios.generales.add(s1);
        user1.publicar(s1);
        user2.publicar(s2);
    }

    public static Vector<Eventos> getEventos() {
        return eventos;
    }

    public static void aggEventos(Eventos i) {
        eventos.add(i);
    }

    public String getTipoEvento() {
        return tipoEvento;
    }

    public void setTipoEvento(String tipoEvento) {
        this.tipoEvento = tipoEvento;
    }

    public String getCapacidadEvento() {
        return capacidadEvento;
    }

    public void setCapacidadEvento(String capacidadEvento) {
        this.capacidadEvento = capacidadEvento;
    }

    public String getLugarEvento() {
        return lugarEvento;
    }

    public void setLugarEvento(String lugarEvento) {
        this.lugarEvento = lugarEvento;
    }

    public String getPaquetesEvento() {
        return paquetesEvento;
    }

    public void setPaquetesEvento(String paquetesEvento) {
        this.paquetesEvento = paquetesEvento;
    }
    
    public String InfoEventos() {
        String cadena="";
        cadena+=InfoAll()
                + "\n==============================================================================================="
                + "\n                                   𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗖𝗜𝗢𝗡 𝗔𝗗𝗜𝗖𝗜𝗢𝗡𝗔𝗟"
                + "\n-----------------------------------------------------------------------------------------------"
                + "\n𝗘𝗩𝗘𝗡𝗧𝗢: "+getTipoEvento()
                + "\n𝗖𝗔𝗣𝗔𝗖𝗜𝗗𝗔𝗗: "+getCapacidadEvento()
                + "\n𝗟𝗢𝗖𝗔𝗖𝗜𝗢𝗡: "+getLugarEvento()
                + "\n𝗣𝗔𝗤𝗨𝗘𝗧𝗘𝗦: "+getPaquetesEvento();
        return cadena;
    }
    
    public static String viewEventos() {
        String cadena="";
        if (eventos.isEmpty()) {
            cadena="No hay servicios resgistrados";
        } else {
            for (int i = 0; i < eventos.size(); i++) {
            Eventos service = eventos.get(i);
            cadena+=(i+1)+"- "+service.getNombreServicio()+" $"+service.getPrecio()+"\n";
        }
            cadena+="===============================================================================================";
        }
        return cadena;
    }
}
