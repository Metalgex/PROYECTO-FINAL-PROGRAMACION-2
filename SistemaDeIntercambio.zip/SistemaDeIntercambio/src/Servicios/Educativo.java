package Servicios;
import java.time.LocalDate;
import java.util.*;
import sistemadeintercambio.Servicios;
public class Educativo extends Servicios {
    private static Vector<Educativo> educativos = new Vector<>();
    
    private String materia;
    private String nivelEducativo;
    private String modalidad;
    private String materialEducativo;
    private String nivelAcademico;

    public Educativo(String materia, String nivelEducativo, String modalidad, String materialEducativo, String nivelAcademico, String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad) {
        super(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
        this.materia = materia;
        this.nivelEducativo = nivelEducativo;
        this.modalidad = modalidad;
        this.materialEducativo = materialEducativo;
        this.nivelAcademico = nivelAcademico;
    }
    
    public void modificacionEducativo(String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad, String materia, String nivelEducativo, String modalidad, String materialEducativo, String nivelAcademico) {
        this.setNombreServicio(nombreServicio);
        this.setDescripcion(descripcion);
        this.setPrecio(precio);
        this.setTipo(tipo);
        this.setCalleServicio(calleServicio);
        this.setCiudadServicio(ciudadServicio);
        this.setEstadoServicio(estadoServicio);
        this.setNumeroServicio(numeroServicio);
        this.setCpServicio(cpServicio);
        this.setCoordenadas(coordenadas);
        this.setRecomendaciones(recomendaciones);
        this.setHorario(horario);
        this.setEdad(edad);
        this.materia = materia;
        this.nivelEducativo = nivelEducativo;
        this.modalidad = modalidad;
        this.materialEducativo = materialEducativo;
        this.nivelAcademico = nivelAcademico;
    }
    
    public static void predeterminados() {
        Educativo s1 = (new Educativo("Programacion", "Intermedio", "Presencial", "Computador propio y disco duro", "Preparatoria", "Clases de programacion", "Unete a las clases de programacion en python", 100, "Educativo", "Saturnino", "Frontera", "Coahuila", "9883", "48389", "4352.35634.342543", "Favor de estar puntual a las clases iniciamos sin esperar a nadie", "Tarde", "21-30"));
        Educativo s2 = (new Educativo("Calculo diferencial", "Avanzado", "Presencial", "Imprimir el formulario", "Pregrado", "Clases de calculo diferencial", "Unete a las clases de calculo diferencial", 80, "Educativo", "Amapolas", "Monclova", "Coahuila", "38992", "34632", "2345.547.453.235", "Tener en cuenta que debes tener bases de precalculo", "Mañana", "11-20"));
        educativos.add(s1);
        educativos.add(s2);
        Servicios.generales.add(s2);
        Servicios.generales.add(s1);
    }

    public static Vector<Educativo> getEducativos() {
        return educativos;
    }

    public static void aggEducativos(Educativo i) {
        educativos.add(i);
    }

    public String getMateria() {
        return materia;
    }

    public void setMateria(String materia) {
        this.materia = materia;
    }

    public String getNivelEducativo() {
        return nivelEducativo;
    }

    public void setNivelEducativo(String nivelEducativo) {
        this.nivelEducativo = nivelEducativo;
    }

    public String getModalidad() {
        return modalidad;
    }

    public void setModalidad(String modalidad) {
        this.modalidad = modalidad;
    }

    public String getMaterialEducativo() {
        return materialEducativo;
    }

    public void setMaterialEducativo(String materialEducativo) {
        this.materialEducativo = materialEducativo;
    }

    public String getNivelAcademico() {
        return nivelAcademico;
    }

    public void setNivelAcademico(String nivelAcademico) {
        this.nivelAcademico = nivelAcademico;
    }
    
    public String InfoEducacion() {
        String cadena="";
        cadena+=InfoAll()
                + "\n===============INFORMACION ADICIONAL================"
                + "\nMateria: "+getMateria()
                + "\nDificultad: "+getNivelEducativo()
                + "\nMaterial: "+getMaterialEducativo()
                + "\nNivel Academico: "+getNivelAcademico()
                + "\nModalidad: "+getModalidad();
        return cadena;
    }
    
    public static String viewEducativo() {
        String cadena="";
        cadena+="=====================EDUCATIVOS=====================\n";
        if (educativos.isEmpty()) {
            cadena="No hay servicios registrados";
        } else {
            for (int i = 0; i < educativos.size(); i++) {
            Educativo service = educativos.get(i);
            cadena+=(i+1)+"- "+service.getNombreServicio()+" $"+service.getPrecio()+"\n";
        }
        }
        return cadena;
    }
}
