package Servicios;
import java.time.LocalDate;
import java.util.*;
import sistemadeintercambio.Servicios;
public class Entretenimiento extends Servicios{
    private static Vector<Entretenimiento> shows = new Vector<>();
    
    private String tipoShow;
    private String RequisitosShow;
    private String materialShow;

    public Entretenimiento(String tipoShow, String RequisitosShow, String materialShow, String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad) {
        super(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
        this.tipoShow = tipoShow;
        this.RequisitosShow = RequisitosShow;
        this.materialShow = materialShow;
    }
    
    public void modificacionShows(String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad, String tipoShow, String RequisitosShow, String materialShow) {
        this.setNombreServicio(nombreServicio);
        this.setDescripcion(descripcion);
        this.setPrecio(precio);
        this.setTipo(tipo);
        this.setCalleServicio(calleServicio);
        this.setCiudadServicio(ciudadServicio);
        this.setEstadoServicio(estadoServicio);
        this.setNumeroServicio(numeroServicio);
        this.setCpServicio(cpServicio);
        this.setCoordenadas(coordenadas);
        this.setRecomendaciones(recomendaciones);
        this.setHorario(horario);
        this.setEdad(edad);
        this.tipoShow = tipoShow;
        this.RequisitosShow = RequisitosShow;
        this.materialShow = materialShow;
    }
    
    public static void predeterminados() {
        Entretenimiento s1 =(new Entretenimiento("DJ", "Tener tomacorrientes en el lugar de servicio", "Tomacorrientes de 90v", "DJ para fiestas", "Disfruta de excelente musica en vivo por DJ", 150, "Entretenimiento", "Minerva", "Monclova", "Coahuila", "3928", "32523", "3463.43634.34534", "Tener en cuenta el gasto de luz de toda la decoracion e iluminacion", "Noche", "21-30"));
        shows.add(s1);
        Servicios.generales.add(s1);
    }

    public static Vector<Entretenimiento> getShows() {
        return shows;
    }

    public static void aggShows(Entretenimiento i) {
        shows.add(i);
    }

    public String getTipoShow() {
        return tipoShow;
    }

    public void setTipoShow(String tipoShow) {
        this.tipoShow = tipoShow;
    }

    public String getRequisitosShow() {
        return RequisitosShow;
    }

    public void setRequisitosShow(String RequisitosShow) {
        this.RequisitosShow = RequisitosShow;
    }

    public String getMaterialShow() {
        return materialShow;
    }

    public void setMaterialShow(String materialShow) {
        this.materialShow = materialShow;
    }
    
    public String InfoShows() {
        String cadena="";
        cadena+=InfoAll()
                + "\n===============INFORMACION ADICIONAL================"
                + "\nServicio: "+getTipoShow()
                + "\nRequisitos: "+getRequisitosShow()
                + "\nMaterial: "+getMaterialShow();
        return cadena;
    }
    
    public static String viewShows() {
        String cadena="";
        cadena+="===================ENTRETENIMIENTO==================\n";
        if (shows.isEmpty()) {
            cadena="No hay servicios registrados";
        } else {
            for (int i = 0; i < shows.size(); i++) {
            Entretenimiento service = shows.get(i);
            cadena+=(i+1)+"- "+service.getNombreServicio()+" $"+service.getPrecio()+"\n";
        }
        }
        return cadena;
    }
}
