package Servicios;
import java.util.*;
import sistemadeintercambio.Servicios;
public class Salud extends Servicios{
    private static Vector<Salud> salud = new Vector<>();
    
    private String tipoSalud;
    private String requisitosSalud;
    private String ubicacionSalud;

    public Salud(String tipoSalud, String requisitosSalud, String ubicacionSalud, String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad) {
        super(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
        this.tipoSalud = tipoSalud;
        this.requisitosSalud = requisitosSalud;
        this.ubicacionSalud = ubicacionSalud;
    }
    
    public void modificacionSalud(String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad, String tipoSalud, String requisitosSalud, String ubicacionSalud) {
        this.setNombreServicio(nombreServicio);
        this.setDescripcion(descripcion);
        this.setPrecio(precio);
        this.setTipo(tipo);
        this.setCalleServicio(calleServicio);
        this.setCiudadServicio(ciudadServicio);
        this.setEstadoServicio(estadoServicio);
        this.setNumeroServicio(numeroServicio);
        this.setCpServicio(cpServicio);
        this.setCoordenadas(coordenadas);
        this.setRecomendaciones(recomendaciones);
        this.setHorario(horario);
        this.setEdad(edad);
        this.tipoSalud = tipoSalud;
        this.requisitosSalud = requisitosSalud;
        this.ubicacionSalud = ubicacionSalud;
    }

    public static Vector<Salud> getSalud() {
        return salud;
    }

    public static void aggSalud(Salud i) {
        salud.add(i);
    }

    public String getTipoSalud() {
        return tipoSalud;
    }

    public void setTipoSalud(String tipoSalud) {
        this.tipoSalud = tipoSalud;
    }

    public String getRequisitosSalud() {
        return requisitosSalud;
    }

    public void setRequisitosSalud(String requisitosSalud) {
        this.requisitosSalud = requisitosSalud;
    }

    public String getUbicacionSalud() {
        return ubicacionSalud;
    }

    public void setUbicacionSalud(String ubicacionSalud) {
        this.ubicacionSalud = ubicacionSalud;
    }
    
    public String InfoSalud() {
        String cadena="";
        cadena+=InfoAll()
                + "\n===============INFORMACION ADICIONAL================"
                + "\nServicio: "+getTipoSalud()
                + "\nRequisitos: "+getRequisitosSalud()
                + "\nLocacion: "+getUbicacionSalud();
        return cadena;
    }
    
    public static String viewSalud() {
        String cadena="";
        cadena+="==================SALUD Y BIENESTAR=================\n";
        if (salud.isEmpty()) {
            cadena="No hay servicios registrados";
        } else {
            for (int i = 0; i < salud.size(); i++) {
            Salud service = salud.get(i);
            cadena+=(i+1)+"- "+service.getNombreServicio()+" $"+service.getPrecio()+"\n";
        }
        }
        return cadena;
    }
}
