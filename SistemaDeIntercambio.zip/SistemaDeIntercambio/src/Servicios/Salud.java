package Servicios;
import java.util.*;
import sistemadeintercambio.Servicios;
public class Salud extends Servicios{
    private static Vector<Salud> salud = new Vector<>();
    
    private String tipoSalud;
    private String requisitosSalud;
    private String ubicacionSalud;

    public Salud(String tipoSalud, String requisitosSalud, String ubicacionSalud, String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad) {
        super(nombreServicio, descripcion, precio, tipo, calleServicio, ciudadServicio, estadoServicio, numeroServicio, cpServicio, coordenadas, recomendaciones, horario, edad);
        this.tipoSalud = tipoSalud;
        this.requisitosSalud = requisitosSalud;
        this.ubicacionSalud = ubicacionSalud;
    }
    
    public void modificacionSalud(String nombreServicio, String descripcion, double precio, String tipo, String calleServicio, String ciudadServicio, String estadoServicio, String numeroServicio, String cpServicio, String coordenadas, String recomendaciones, String horario, String edad, String tipoSalud, String requisitosSalud, String ubicacionSalud) {
        this.setNombreServicio(nombreServicio);
        this.setDescripcion(descripcion);
        this.setPrecio(precio);
        this.setTipo(tipo);
        this.setCalleServicio(calleServicio);
        this.setCiudadServicio(ciudadServicio);
        this.setEstadoServicio(estadoServicio);
        this.setNumeroServicio(numeroServicio);
        this.setCpServicio(cpServicio);
        this.setCoordenadas(coordenadas);
        this.setRecomendaciones(recomendaciones);
        this.setHorario(horario);
        this.setEdad(edad);
        this.tipoSalud = tipoSalud;
        this.requisitosSalud = requisitosSalud;
        this.ubicacionSalud = ubicacionSalud;
    }
    
    public static void Predeterminados() {
        Salud s1 = new Salud("Enfermeria", "Expediente del paciente", "Domicilio", "Enfermera de cuidados", "Tienes pacientes en casa pero no puedes cuidarlos, nosotros te ayudamos", 70, "Salud y bienestar", "Juarez", "Reynosa", "Tamaulipas", "8248", "4298", "3453.234.678", "Tener el material previamente organizado para evitar accidentes", "Mañana", "71-80");
        Salud s2 = new Salud("Consulta medica", "Expediente del paciente", "Domicilio", "Consulta medica a domicilio", "Ofrezco servicio de consulta medica a domicilio, sin necesidad de seguro", 100, "Salud y bienestar", "Durango", "Monclova", "Coahuila", "91390", "490223", "019312.328919.32", "Tener en cuenta que la consulta durara lo que usted contrate", "Tarde", "31-40");
        salud.add(s2);
        salud.add(s1);
        Servicios.generales.add(s2);
        Servicios.generales.add(s1);
    }

    public static Vector<Salud> getSalud() {
        return salud;
    }

    public static void aggSalud(Salud i) {
        salud.add(i);
    }

    public String getTipoSalud() {
        return tipoSalud;
    }

    public void setTipoSalud(String tipoSalud) {
        this.tipoSalud = tipoSalud;
    }

    public String getRequisitosSalud() {
        return requisitosSalud;
    }

    public void setRequisitosSalud(String requisitosSalud) {
        this.requisitosSalud = requisitosSalud;
    }

    public String getUbicacionSalud() {
        return ubicacionSalud;
    }

    public void setUbicacionSalud(String ubicacionSalud) {
        this.ubicacionSalud = ubicacionSalud;
    }
    
    public String InfoSalud() {
        String cadena="";
        cadena+=InfoAll()
                + "\n===============INFORMACION ADICIONAL================"
                + "\nServicio: "+getTipoSalud()
                + "\nRequisitos: "+getRequisitosSalud()
                + "\nLocacion: "+getUbicacionSalud();
        return cadena;
    }
    
    public static String viewSalud() {
        String cadena="";
        cadena+="==================SALUD Y BIENESTAR=================\n";
        if (salud.isEmpty()) {
            cadena="No hay servicios registrados";
        } else {
            for (int i = 0; i < salud.size(); i++) {
            Salud service = salud.get(i);
            cadena+=(i+1)+"- "+service.getNombreServicio()+" $"+service.getPrecio()+"\n";
        }
        }
        return cadena;
    }
}
